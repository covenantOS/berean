---
title: "Deuteronomy 8 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "8"
description: "In this chapter: Exhortations and cautions, enforced by the Lord's former dealings with Israel, and his promises. (1–9). Exhortations and cautions further enforced. (10–20)."
weight: 8
---

# Deuteronomy 8 

## Chapter Outline

- Exhortations and cautions, enforced by the Lord's former dealings with Israel, and his promises. (1–9)
- Exhortations and cautions further enforced. (10–20)

## Verses 1–9

Obedience must be, 1. Careful, observe to do; 2. Universal, to do all the commandments; and 3. From a good principle, with a regard to God as the Lord, and their God, and with a holy fear of him. To engage them to this obedience. Moses directs them to look back. It is good to remember all the ways, both of God's providence and grace, by which he has led us through this wilderness, that we may cheerfully serve him and trust in him. They must remember the straits they were sometimes brought into, for mortifying their pride, and manifesting their perverseness; to prove them, that they and others might know all that was in their heart, and that all might see that God chose them, not for any thing in them which might recommend them to his favour. They must remember the miraculous supplies of food and raiment granted them. Let none of God's children distrust their Father, nor take any sinful course for the supply of their necessities. Some way or other, God will provide for them in the way of duty and honest diligence, and verily they shall be fed. It may be applied spiritually; the word of God is the food of the soul. Christ is the word of God; by him we live. They must also remember the rebukes they had been under, and not without need. This use we should make of all our afflictions; by them let us be quickened to our duty. Moses also directs them to look forward to Canaan. Look which way we will, both to look back and to look forward, to Canaan. Look which way we will, both to look back and to look forward will furnish us with arguments for obedience. Moses saw in that land a type of the better country. The gospel church is the New Testament Canaan, watered with the Spirit in his gifts and graces, planted with trees of righteousness, bearing fruits of righteousness. Heaven is the good land, in which nothing is wanting, and where is fulness of joy.

## Verses 10–20

Moses directs to the duty of a prosperous condition. Let them always remember their Benefactor. In everything we must give thanks. Moses arms them against the temptations of a prosperous condition. When men possess large estates, or are engaged in profitable business, they find the temptation to pride, forgetfulness of God, and carnal-mindedness, very strong; and they are anxious and troubled about many things. In this the believing poor have the advantage; they more easily perceive their supplies coming from the Lord in answer to the prayer of faith; and, strange as it may seem, they find less difficulty in simply trusting him for daily bread. They taste a sweetness therein, which is generally unknown to the rich, while they are also freed from many of their temptations. Forget not God's former dealings with thee. Here is the great secret of Divine Providence. Infinite wisdom and goodness are the source of all the changes and trials believers experience. Israel had many bitter trials, but it was “to do them good.” Pride is natural to the human heart. Would one suppose that such a people, after their slavery at the brick-kilns, should need the thorns of the wilderness to humble them? But such is man! And they were proved that they might be humbled. None of us live a single week without giving proofs of our weakness, folly, and depravity. To broken-hearted souls alone the Saviour is precious indeed. Nothing can render the most suitable outward and inward trials effectual, but the power of the Spirit of God. See here how God's giving and our getting are reconciled, and apply it to spiritual wealth. All God's gifts are in pursuance of his promises. Moses repeats the warning he had often given of the fatal consequences of forsaking God. Those who follow others in sin, will follow them to destruction. If we do as sinners do, we must expect to fare as sinners fare.

