---
title: "Deuteronomy 27 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "27"
description: "In this chapter: The law to be written on stones in the promised land. (1–10). The curses to be pronounced on mount Ebal. (11–26)."
weight: 27
---

# Deuteronomy 27 

## Chapter Outline

- The law to be written on stones in the promised land. (1–10)
- The curses to be pronounced on mount Ebal. (11–26)

## Verses 1–10

As soon as they were come into Canaan, they must set up a monument, on which they must write the words of this law. They must set up an altar. The word and prayer must go together. Though they might not, of their own heads, set up any altar besides that at the tabernacle; yet, by the appointment of God, they might, upon special occasion. This altar must be made of unhewn stones, such as they found upon the field. Christ, our Altar, is a stone cut out of the mountain without hands, refused by the builders, as having no form or comeliness, but accepted of God the Father, and made the Head of the corner. In the Old Testament the words of the law are written, with the curse annexed; which would overcome us with horror, if we had not, in the New Testament, an altar erected close by, which gives consolation. Blessed be God, the printed copies of the Scriptures among us, do away the necessity of such methods as were presented to Israel. The end of the gospel ministry is, and the end of preachers ought to be, to make the word of God as plain as possible. Yet, unless the Spirit of God prosper such labours with Divine power, we shall not, even by these means, be made wise unto salvation: for this blessing we should therefore daily and earnestly pray.

## Verses 11–26

The six tribes appointed for blessing, were all children of the free women, for to such the promise belongs, Ga 4:31. Levi is here among the rest. Ministers should apply to themselves the blessing and curse they preach to others, and by faith set their own Amen to it. And they must not only allure people to their duty with the promises of a blessing, but awe them with the threatenings of a curse, by declaring that a curse would be upon those who do such things. To each of the curses the people were to say, Amen. It professed their faith, that these, and the like curses, were real declarations of the wrath of God against the ungodliness and unrighteousness of men, not one jot of which shall fall to the ground. It was acknowledging the equity of these curses. Those who do such things deserve to fall, and lie under the curse. Lest those who were guilty of other sins, not here mentioned, should think themselves safe from the curse, the last reaches all. Not only those who do the evil which the law forbids, but those also who omit the good which the law requires. Without the atoning blood of Christ, sinners can neither have communion with a holy God, nor do any thing acceptable to him; his righteous law condemns every one who, at any time, or in any thing, transgresses it. Under its awful curse we remain as transgressors, until the redemption of Christ is applied to our hearts. Wherever the grace of God brings salvation, it teaches the believer to deny ungodliness and wordly lusts, to live soberly, righteously, and godly in this present world, consenting to, and delighting in the words of God's law, after the inward man. In this holy walk, true peace and solid joy are to be found.

