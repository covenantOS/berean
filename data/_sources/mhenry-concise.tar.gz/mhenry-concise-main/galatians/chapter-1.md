---
title: "Galatians 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: The apostle Paul asserts his apostolic character against such as lessened it. (1–5). He reproves the Galatians for revolting from the gospel of Christ under the influence of evil teachers. (6–9). He proves the Divine authority of his doctrine and mission; and declares what he was before his conversion and calling. (10–14). And how he proceeded after it. (15–24)."
weight: 1
---

# Galatians 1 

## Chapter Outline

- The apostle Paul asserts his apostolic character against such as lessened it. (1–5)
- He reproves the Galatians for revolting from the gospel of Christ under the influence of evil teachers. (6–9)
- He proves the Divine authority of his doctrine and mission; and declares what he was before his conversion and calling. (10–14)
- And how he proceeded after it. (15–24)

## Verses 1–5

St. Paul was an apostle of Jesus Christ; he was expressly appointed by him, consequently by God the Father, who is one with him in respect of his Divine nature, and who appointed Christ as Mediator. Grace, includes God's good-will towards us, and his good work upon us; and peace, all that inward comfort, or outward prosperity, which is really needful for us. They come from God the Father, as the Fountain, through Jesus Christ. But observe, first grace, and then peace; there can be no true peace without grace. Christ gave himself for our sins, to make atonement for us: this the justice of God required, and to this he freely submitted. Here is to be observed the infinite greatness of the price bestowed, and then it will appear plainly, that the power of sin is so great, that it could by no means be put away except the Son of God be given for it. He that considers these things well, understands that sin is a thing the most horrible that can be expressed; which ought to move us, and make us afraid indeed. Especially mark well the words, “for our sins.” For here our weak nature starts back, and would first be made worthy by her own works. It would bring him that is whole, and not him that has need of a physician. Not only to redeem us from the wrath of God, and the curse of the law; but also to recover us from wicked practices and customs, to which we are naturally enslaved. But it is in vain for those who are not delivered from this present evil world by the sanctification of the Spirit, to expect that they are freed from its condemnation by the blood of Jesus.

## Verses 6–9

Those who would establish any other way to heaven than what the gospel of Christ reveals, will find themselves wretchedly mistaken. The apostle presses upon the Galatians a due sense of their guilt in forsaking the gospel way of justification; yet he reproves with tenderness, and represents them as drawn into it by the arts of some that troubled them. In reproving others, we should be faithful, and yet endeavour to restore them in the spirit of meekness. Some would set up the works of the law in the place of Christ's righteousness, and thus they corrupted Christianity. The apostle solemnly denounces, as accursed, every one who attempts to lay so false a foundation. All other gospels than that of the grace of Christ, whether more flattering to self-righteous pride, or more favourable to worldly lusts, are devices of Satan. And while we declare that to reject the moral law as a rule of life, tends to dishonour Christ, and destroy true religion, we must also declare, that all dependence for justification on good works, whether real or supposed, is as fatal to those who persist in it. While we are zealous for good works, let us be careful not to put them in the place of Christ's righteousness, and not to advance any thing which may betray others into so dreadful a delusion.

## Verses 10–14

In preaching the gospel, the apostle sought to bring persons to the obedience, not of men, but of God. But Paul would not attempt to alter the doctrine of Christ, either to gain their favour, or to avoid their fury. In so important a matter we must not fear the frowns of men, nor seek their favour, by using words of men's wisdom. Concerning the manner wherein he received the gospel, he had it by revelation from Heaven. He was not led to Christianity, as many are, merely by education.

## Verses 15–24

St. Paul was wonderfully brought to the knowledge and faith of Christ. All who are savingly converted, are called by the grace of God; their conversion is wrought by his power and grace working in them. It will but little avail us to have Christ revealed to us, if he is not also revealed in us. He instantly prepared to obey, without hesitating as to his worldly interest, credit, ease, or life itself. And what matter of thanksgiving and joy is it to the churches of Christ, when they hear of such instances to the praise of the glory of his grace, whether they have ever seen them or not! They glorify God for his power and mercy in saving such persons, and for all the service to his people and cause that is done, and may be further expected from them.

