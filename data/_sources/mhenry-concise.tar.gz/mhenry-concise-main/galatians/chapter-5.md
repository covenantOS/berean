---
title: "Galatians 5 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "5"
description: "In this chapter: An earnest exhortation to stand fast in the liberty of the gospel. (1–12). To take heed of indulging a sinful temper. (13–15). And to walk in the Spirit, and not to fulfil the lusts of the flesh: the works of both are described. (16–26)."
weight: 5
---

# Galatians 5 

## Chapter Outline

- An earnest exhortation to stand fast in the liberty of the gospel. (1–12)
- To take heed of indulging a sinful temper. (13–15)
- And to walk in the Spirit, and not to fulfil the lusts of the flesh: the works of both are described. (16–26)

## Verses 1–6

Christ will not be the Saviour of any who will not own and rely upon him as their only Saviour. Let us take heed to the warnings and persuasions of the apostle to stedfastness in the doctrine and liberty of the gospel. All true Christians, being taught by the Holy Spirit, wait for eternal life, the reward of righteousness, and the object of their hope, as the gift of God by faith in Christ; and not for the sake of their own works. The Jewish convert might observe the ceremonies or assert his liberty, the Gentile might disregard them or might attend to them, provided he did not depend upon them. No outward privileges or profession will avail to acceptance with God, without sincere faith in our Lord Jesus. True faith is a working grace; it works by love to God, and to our brethren. May we be of the number of those who, through the Spirit, wait for the hope of righteousness by faith. The danger of old was not in things of no consequence in themselves, as many forms and observances now are. But without faith working by love, all else is worthless, and compared with it other things are of small value.

## Verses 7–12

The life of a Christian is a race, wherein he must run, and hold on, if he would obtain the prize. It is not enough that we profess Christianity, but we must run well, by living up to that profession. Many who set out fairly in religion, are hindered in their progress, or turn out of the way. It concerns those who begin to turn out of the way, or to tire in it, seriously to inquire what hinders them. The opinion or persuasion, verse 8, was, no doubt, that of mixing the works of the law with faith in Christ in justification. The apostle leaves them to judge whence it must arise, but sufficiently shows that it could be owing to none but Satan. It is dangerous for Christian churches to encourage those who follow, but especially who spread, destructive errors. And in reproving sin and error, we should always distinguish between the leaders and the led. The Jews were offended, because Christ was preached as the only salvation for sinners. If Paul and others would have admitted that the observance of the law of Moses was to be joined with faith in Christ, as necessary to salvation, then believers might have avoided many of the sufferings they underwent. The first beginnings of such leaven should be opposed. And assuredly those who persist in disturbing the church of Christ must bear their judgment.

## Verses 13–15

The gospel is a doctrine according to godliness, 1Ti 6:3, and is so far from giving the least countenance to sin, that it lays us under the strongest obligation to avoid and subdue it. The apostle urges that all the law is fulfilled in one word, even in this, Thou shalt love thy neighbour as thyself. If Christians, who should help one another, and rejoice one another, quarrel, what can be expected but that the God of love should deny his grace, that the Spirit of love should depart, and the evil spirit, who seeks their destruction, should prevail? Happy would it be, if Christians, instead of biting and devouring one another on account of different opinions, would set themselves against sin in themselves, and in the places where they live.

## Verses 16–26

If it be our care to act under the guidance and power of the blessed Spirit, though we may not be freed from the stirrings and oppositions of the corrupt nature which remains in us, it shall not have dominion over us. Believers are engaged in a conflict, in which they earnestly desire that grace may obtain full and speedy victory. And those who desire thus to give themselves up to be led by the Holy Spirit, are not under the law as a covenant of works, nor exposed to its awful curse. Their hatred of sin, and desires after holiness, show that they have a part in the salvation of the gospel. The works of the flesh are many and manifest. And these sins will shut men out of heaven. Yet what numbers, calling themselves Christians, live in these, and say they hope for heaven! The fruits of the Spirit, or of the renewed nature, which we are to do, are named. And as the apostle had chiefly named works of the flesh, not only hurtful to men themselves, but tending to make them so to one another, so here he chiefly notices the fruits of the Spirit, which tend to make Christians agreeable one to another, as well as to make them happy. The fruits of the Spirit plainly show, that such are led by the Spirit. By describing the works of the flesh and fruits of the Spirit, we are told what to avoid and oppose, and what we are to cherish and cultivate; and this is the sincere care and endeavour of all real Christians. Sin does not now reign in their mortal bodies, so that they obey it, Ro 6:12, for they seek to destroy it. Christ never will own those who yield themselves up to be the servants of sin. And it is not enough that we cease to do evil, but we must learn to do well. Our conversation will always be answerable to the principle which guides and governs us, Ro 8:5. We must set ourselves in earnest to mortify the deeds of the body, and to walk in newness of life. Not being desirous of vain-glory, or unduly wishing for the esteem and applause of men, not provoking or envying one another, but seeking to bring forth more abundantly those good fruits, which are, through Jesus Christ, to the praise and glory of God.

