---
title: "Galatians | Matthew Henry Concise Commentary"
linkTitle: "Galatians"
weight: 48
description: >
  Read commentary notes on Galatians from Matthew Henry's Concise Commentary on the Bible online.
layout: single-section
---

# Galatians

The churches in Galatia were formed partly of converted Jews, and partly of Gentile converts, as was generally the case. St. Paul asserts his apostolic character and the doctrines he taught, that he might confirm the Galatian churches in the faith of Christ, especially with respect to the important point of justification by faith alone. Thus the subject is mainly the same as that which is discussed in the epistle to the Romans, that is, justification by faith alone. In this epistle, however, attention is particularly directed to the point, that men are justified by faith without the works of the law of Moses. Of the importance of the doctrines prominently set forth in this epistle, Luther thus speaks: “We have to fear as the greatest and nearest danger, lest Satan take from us this doctrine of faith, and bring into the church again the doctrine of works and of men's traditions. Wherefore it is very necessary that this doctrine be kept in continual practice and public exercise, both of reading and hearing. If this doctrine be lost, then is also the doctrine of truth, life and salvation, lost and gone.”

{{< cards >}}
{{< card link="./chapter-1" title="Chapter 1" icon="book-open" >}}
{{< card link="./chapter-2" title="Chapter 2" icon="book-open" >}}
{{< card link="./chapter-3" title="Chapter 3" icon="book-open" >}}
{{< card link="./chapter-4" title="Chapter 4" icon="book-open" >}}
{{< card link="./chapter-5" title="Chapter 5" icon="book-open" >}}
{{< card link="./chapter-6" title="Chapter 6" icon="book-open" >}}
{{< /cards >}}
