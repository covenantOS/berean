---
title: "2 Thessalonians 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: The apostle blesses God for the growing state of the love and patience of the Thessalonians. (1–4). And encourages them to persevere under all their sufferings for Christ, considering his coming at the great day of account. (5–12)."
weight: 1
---

# 2 Thessalonians 1 

## Chapter Outline

- The apostle blesses God for the growing state of the love and patience of the Thessalonians. (1–4)
- And encourages them to persevere under all their sufferings for Christ, considering his coming at the great day of account. (5–12)

## Verses 1–4

Where there is the truth of grace, there will be an increase of it. The path of the just is as the shining light, which shines more and more unto the perfect day. And where there is the increase of grace, God must have all the glory. Where faith grows, love will abound, for faith works by love. It shows faith and patience, such as may be proposed as a pattern for others, when trials from God, and persecutions from men, quicken the exercise of those graces; for the patience and faith of which the apostle gloried, bore them up, and enabled them to endure all their tribulations.

## Verses 5–10

Religion, if worth anything, is worth every thing; and those have no religion, or none worth having, or know not how to value it, cannot find their hearts to suffer for it. We cannot by all our sufferings, any more than by our services, merit heaven; but by our patience under sufferings, we are prepared for the promised joy. Nothing more strongly marks a man for eternal ruin, than a spirit of persecution and enmity to the name and people of God. God will trouble those that trouble his people. And there is a rest for the people of God; a rest from sin and sorrow. The certainty of future recompence is proved by the righteousness of God. The thoughts of this should be terrible to wicked men, and support the righteous. Faith, looking to the great day, is enabled partly to understand the book of providence, which appears confused to unbelievers. The Lord Jesus will in that day appear from heaven. He will come in the glory and power of the upper world. His light will be piercing, and his power consuming, to all who in that day shall be found as chaff. This appearance will be terrible to those that know not God, especially to those who rebel against revelation, and obey not the gospel of our Lord Jesus Christ. This is the great crime of multitudes, the gospel is revealed, and they will not believe it; or if they pretend to believe, they will not obey it. Believing the truths of the gospel, is in order to our obeying the precepts of the gospel. Though sinners may be long spared, they will be punished at last. They did sin's work, and must receive sin's wages. Here God punishes sinners by creatures as instruments; but then, it will be destruction from the Almighty; and who knows the power of his anger? It will be a joyful day to some, to the saints, to those who believe and obey the gospel. In that bright and blessed day, Christ Jesus will be glorified and admired by his saints. And Christ will be glorified and admired in them. His grace and power will be shown, when it shall appear what he has purchased for, and wrought in, and bestowed upon those who believe in him. Lord, if the glory put upon thy saints shall be thus admired, how much more shalt thou be admired, as the Bestower of that glory! The glory of thy justice in the damnation of the wicked will be admired, but not as the glory of thy mercy in the salvation of believers. How will this strike the adoring angels with holy admiration, and transport thy admiring saints with eternal rapture! The meanest believer shall enjoy more than the most enlarged heart can imagine while we are here; Christ will be admired in all those that believe, the meanest believer not excepted.

## Verses 11, 12

Believing thoughts and expectations of the second coming of Christ should lead us to pray to God more, for ourselves and others. If there is any good in us, it is owing to the good pleasure of his goodness, and therefore it is called grace. There are many purposes of grace and good-will in God toward his people, and the apostle prays that God would complete in them the work of faith with power. This is to their doing every other good work. The power of God not only begins, but carries on the work of faith. And this is the great end and design of the grace of our God and Lord Jesus Christ, which is made known to us, and wrought in us.

