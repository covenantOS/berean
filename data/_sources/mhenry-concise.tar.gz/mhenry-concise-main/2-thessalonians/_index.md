---
title: "2 Thessalonians | Matthew Henry Concise Commentary"
linkTitle: "2 Thessalonians"
weight: 53
description: >
  Read commentary notes on 2 Thessalonians from Matthew Henry's Concise Commentary on the Bible online.
layout: single-section
---

# 2 Thessalonians

The second epistle to the Thessalonians was written soon after the first. The apostle was told that, from some expressions in his first letter, many expected the second coming of Christ was at hand, and that the day of judgment would arrive in their time. Some of these neglected their worldly duties. St. Paul wrote again to correct their error, which hindered the spread of the gospel. He had written agreeably to the words of the prophets of the Old Testament; and he tells them there were many counsels of the Most High yet to be fulfilled, before that day of the Lord should come, though, because it is sure, he had spoken of it as near. The subject led to a remarkable foretelling, of some of the future events which were to take place in the after-ages of the Christian church, and which show the prophetic spirit the apostle possessed.

{{< cards >}}
{{< card link="./chapter-1" title="Chapter 1" icon="book-open" >}}
{{< card link="./chapter-2" title="Chapter 2" icon="book-open" >}}
{{< card link="./chapter-3" title="Chapter 3" icon="book-open" >}}
{{< /cards >}}
