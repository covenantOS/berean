---
title: "Exodus 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: Moses is born, and exposed on the river. (1–4). He is found, and brought up by Pharaoh's daughter. (5–10). Moses slays an Egyptian, and flees to Midian. (11–15). Moses marries the daughter of Jethro. (16–22). God hears the Israelites. (23–25)."
weight: 2
---

# Exodus 2 

## Chapter Outline

- Moses is born, and exposed on the river. (1–4)
- He is found, and brought up by Pharaoh's daughter. (5–10)
- Moses slays an Egyptian, and flees to Midian. (11–15)
- Moses marries the daughter of Jethro. (16–22)
- God hears the Israelites. (23–25)

## Verses 1–4

Observe the order of Providence: just at the time when Pharaoh's cruelty rose to its height by ordering the Hebrew children to be drowned, the deliverer was born. When men are contriving the ruin of the church, God is preparing for its salvation. The parents of Moses saw he was a goodly child. A lively faith can take encouragement from the least hint of the Divine favour. It is said, Heb 11:23, that the parents of Moses hid him by faith; they had the promise that Israel should be preserved, which they relied upon. Faith in God's promise quickens to the use of lawful means for obtaining mercy. Duty is ours, events are God's. Faith in God will set us above the fear of man. At three months' end, when they could not hide the infant any longer, they put him in an ark of bulrushes by the river's brink, and set his sister to watch. And if the weak affection of a mother were thus careful, what shall we think of Him, whose love, whose compassion is, as himself, boundless. Moses never had a stronger protection about him, no, not when all the Israelites were round his tent in the wilderness, than now, when he lay alone, a helpless babe upon the waves. No water, no Egyptian can hurt him. When we seem most neglected and forlorn, God is most present with us.

## Verses 5–10

Come, see the place where that great man, Moses, lay, when he was a little child; it was in a bulrush basket by the river's side. Had he been left there long, he must have perished. But Providence brings Pharaoh's daughter to the place where this poor forlorn infant lay, and inclines her heart to pity it, which she dares do, when none else durst. God's care of us in our infancy ought to be often mentioned by us to his praise. Pharaoh cruelly sought to destroy Israel, but his own daughter had pity on a Hebrew child, and not only so, but, without knowing it, preserved Israel's deliverer, and provided Moses with a good nurse, even his own mother. That he should have a Hebrew nurse, the sister of Moses brought the mother into the place of a nurse. Moses was treated as the son of Pharoah's daughter. Many who, by their birth, are obscure and poor, by surprising events of Providence, are raised high in the world, to make men know that God rules.

## Verses 11–15

Moses boldly owned the cause of God's people. It is plain from Heb 11. that this was done in faith, with the full purpose of leaving the honours, wealth, and pleasures of his rank among the Egyptians. By the grace of God he was a partaker of faith in Christ, which overcomes the world. He was willing, not only to risk all, but to suffer for his sake; being assured that Israel were the people of God. By special warrant from Heaven, which makes no rule for other cases, Moses slew an Egyptian, and rescued an oppressed Israelites. Also, he tried to end a dispute between two Hebrews. The reproof Moses gave, may still be of use. May we not apply it to disputants, who, by their fierce debates, divide and weaken the Christian church? They forget that they are brethren. He that did wrong quarreled with Moses. It is a sign of guilt to be angry at reproof. Men know not what they do, nor what enemies they are to themselves, when they resist and despise faithful reproofs and reprovers. Moses might have said, if this be the spirit of the Hebrews, I will go to court again, and be the son of Pharaoh's daughter. But we must take heed of being set against the ways and people of God, by the follies and peevishness of some persons that profess religion. Moses was obliged to flee into the land of Midian. God ordered this for wise and holy ends.

## Verses 16–22

Moses found shelter in Midian. He was ready to help Reuel's daughters to water their flocks, although bred in learning and at court. Moses loved to be doing justice, and to act in defence of such as he saw injured, which every man ought to do, as far as it is in his power. He loved to be doing good; wherever the providence of God casts us, we should desire and try to be useful; and when we cannot do the good we would, we must be ready to do the good we can. Moses commended himself to the prince of Midian; who married one of his daughters to Moses, by whom he had a son, called Gershom, “a stranger there,” that he might keep in remembrance the land in which he had been a stranger.

## Verses 23–25

The Israelites' bondage in Egypt continued, though the murdering of their infants did not continue. Sometimes the Lord suffers the rod of the wicked to lie very long and very heavy on the lot of the righteous. At last they began to think of God under their troubles. It is a sign that the Lord is coming towards us with deliverance, when he inclines and enables us to cry to him for it. God heard their groaning; he made it to appear that he took notice of their complaints. He remembered his covenant, of which he is ever mindful. He considered this, and not any merit of theirs. He looked upon the children of Israel. Moses looked upon them, and pitied them; but now God looked upon them, and helped them. He had respect unto them. His eyes are now fixed upon Israel, to show himself in their behalf. God is ever thus, a very present help in trouble. Take courage then, ye who, conscious of guilt and thraldom, are looking to Him for deliverance. God in Christ Jesus is also looking upon you. A call of love is joined with a promise of the Redeemer. Come unto me, all ye that labour and are heavy laden, and I will give you rest, Mt 11:28.

