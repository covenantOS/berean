---
title: "Exodus 6 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "6"
description: "In this chapter: God renews his promise. (1–9). Moses and Aaron again sent to Pharaoh. (10–13). The parentage of Moses and Aaron. (14–30)."
weight: 6
---

# Exodus 6 

## Chapter Outline

- God renews his promise. (1–9)
- Moses and Aaron again sent to Pharaoh. (10–13)
- The parentage of Moses and Aaron. (14–30)

## Verses 1–9

We are most likely to prosper in attempts to glorify God, and to be useful to men, when we learn by experience that we can do nothing of ourselves; when our whole dependence is placed on him, and our only expectation is from him. Moses had been expecting what God would do; but now he shall see what he will do. God would now be known by his name Jehovah, that is, a God performing what he had promised, and finishing his own work. God intended their happiness: I will take you to me for a people, a peculiar people, and I will be to you a God. More than this we need not ask, we cannot have, to make us happy. He intended his own glory: Ye shall know that I am the Lord. These good words, and comfortable words, should have revived the drooping Israelites, and have made them forget their misery; but they were so taken up with their troubles, that they did not heed God's promises. By indulging discontent and fretfulness, we deprive ourselves of the comfort we might have, both from God's word and from his providence, and go comfortless.

## Verses 10–13

The faith of Moses was so feeble that he could scarcely be kept to his work. Ready obedience is always according to the strength of our faith. Though our weaknesses ought to humble us, yet they ought not to discourage us from doing our best in any service we have to do for God. When Moses repeats his baffled arguments, he is argued with no longer, but God gives him and Aaron a charge, both to the children of Israel, and to Pharaoh. God's authority is sufficient to answer all objections, and binds all to obey, without murmuring or disputing, Php 2:14.

## Verses 14–30

Moses and Aaron were Israelites; raised up unto them of their brethren, as Christ also should be, who was to be the Prophet and Priest, the Redeemer and Lawgiver of the people of Israel. Moses returns to his narrative, and repeats the charge God had given him to deliver his message to Pharaoh, and his objection against it. Those who have spoken unadvisedly with their lips ought to reflect upon it with regret, as Moses seems to do here. “Uncircumcised,” is used in Scripture to note the unsuitableness there may be in any thing to answer its proper purpose; as the carnal heart and depraved nature of fallen man are wholly unsuited to the services of God, and to the purposes of his glory. It is profitable to place no confidence in ourselves, all our sufficiency must be in the Lord. We never can trust ourselves too little, or our God too much. I can do nothing by myself, said the apostle, but I can do all things through Christ which strengtheneth me.

