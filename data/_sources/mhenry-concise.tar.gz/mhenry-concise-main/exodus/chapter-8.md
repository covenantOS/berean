---
title: "Exodus 8 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "8"
description: "In this chapter: The plague of frogs. (1–15). The plague of lice. (16–19). The plague of flies. (20–32)."
weight: 8
---

# Exodus 8 

## Chapter Outline

- The plague of frogs. (1–15)
- The plague of lice. (16–19)
- The plague of flies. (20–32)

## Verses 1–15

Pharaoh is plagued with frogs; their vast numbers made them sore plagues to the Egyptians. God could have plagued Egypt with lions, or bears, or wolves, or with birds of prey, but he chose to do it by these despicable creatures. God, when he pleases, can arm the smallest parts of the creation against us. He thereby humbled Pharaoh. They should neither eat, nor drink, nor sleep in quiet; but wherever they were, they should be troubled by the frogs. God's curse upon a man will pursue him wherever he goes, and lie heavy upon him whatever he does. Pharaoh gave way under this plague. He promises that he will let the people go. Those who bid defiance to God and prayer, first or last, will be made to see their need of both. But when Pharaoh saw there was respite, he hardened his heart. Till the heart is renewed by the grace of God, the thoughts made by affliction do not abide; the convictions wear off, and the promises that were given are forgotten. Till the state of the air is changed, what thaws in the sun will freeze again in the shade.

## Verses 16–19

These lice were produced out of the dust of the earth; out of any part of the creation God can fetch a scourge, with which to correct those who rebel against him. Even the dust of the earth obeys him. These lice were very troublesome, as well as disgraceful to the Egyptians, whose priests were obliged to take much pains that no vermin ever should be found about them. All the plagues inflicted on the Egyptians, had reference to their national crimes, or were rendered particularly severe by their customs. The magicians attempted to imitate it, but they could not. It forced them to confess, This is the finger of God! The check and restraint put upon us, must needs be from a Divine power. Sooner or later God will force even his enemies to acknowledge his own power. Pharaoh, notwithstanding this, was more and more obstinate.

## Verses 20–32

Pharaoh was early at his false devotions to the river; and shall we be for more sleep and more slumber, when any service to the Lord is to be done? The Egyptians and the Hebrews were to be marked in the plague of flies. The Lord knows them that are his, and will make it appear, perhaps in this world, certainly in the other, that he has set them apart for himself. Pharaoh unwillingly entered into a treaty with Moses and Aaron. He is content they should sacrifice to their God, provided they would do it in the land of Egypt. But it would be an abomination to God, should they offer the Egyptian sacrifices; and it would be an abomination to the Egyptians, should they offer to God the objects of the worship of the Egyptians, namely, their calves or oxen. Those who would offer acceptable sacrifice to God, must separate themselves from the wicked and profane. They must also retire from the world. Israel cannot keep the feast of the Lord, either among the brick-kilns or among the flesh-pots of Egypt. And they must sacrifice as God shall command, not otherwise. Though they were in slavery to Pharaoh, yet they must obey God's commands. Pharaoh consents for them to go into the wilderness, provided they do not go so far but that he might fetch them back again. Thus, some sinners, in a pang of conviction, part with their sins, yet are loth they should go very far away; for when the fright is over, they will turn to them again. Moses promised the removal of this plague. But let not Pharaoh deal deceitfully any more. Be not deceived; God is not mocked: if we think to cheat God by a sham repentance and a false surrender of ourselves to him, we shall put a fatal cheat upon our own souls. Pharaoh returned to his hardness. Reigning lusts break through the strongest bonds, and make men presume and go from their word. Many seem in earnest, but there is some reserve, some beloved, secret sin. They are unwilling to look upon themselves as in danger of everlasting misery. They will refrain from other sins; they do much, give much, and even punish themselves much. They will leave it off sometimes, and, as it were, let their sin depart a little way; but will not make up their minds to part with all and follow Christ, bearing the cross. Rather than that, they venture all. They are sorrowful, but depart from Christ, determined to keep the world at present, and they hope for some future season, when salvation may be had without such costly sacrifices; but, at length, the poor sinner is driven away in his wickedness, and left without hope to lament his folly.

