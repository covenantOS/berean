---
title: "Exodus 9 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "9"
description: "In this chapter: The murrain of beasts. (1–7). The plague of boils and blains. (8–12). The plague of hail threatened. (13–21). The plague of hail inflicted. (22–35)."
weight: 9
---

# Exodus 9 

## Chapter Outline

- The murrain of beasts. (1–7)
- The plague of boils and blains. (8–12)
- The plague of hail threatened. (13–21)
- The plague of hail inflicted. (22–35)

## Verses 1–7

God will have Israel released, Pharaoh opposes it, and the trial is, whose word shall stand. The hand of the Lord at once is upon the cattle, many of which, some of all kinds, die by a sort of murrain. This was greatly to the loss of the owners; they had made Israel poor, and now God would make them poor. The hand of God is to be seen, even in the sickness and death of cattle; for a sparrow falls not to the ground without our Father. None of the Israelites' cattle should die; the Lord shall sever. The cattle died. The Egyptians worshipped their cattle. What we make an idol of, it is just with God to remove from us. This proud tyrant and cruel oppressor deserved to be made an example by the just Judge of the universe. None who are punished according to what they deserve, can have any just cause to complain. Hardness of heart denotes that state of mind upon which neither threatenings nor promise, neither judgements nor mercies, make any abiding impression. The conscience being stupified, and the heart filled with pride and presumption, they persist in unbelief and disobedience. This state of mind is also called the stony heart. Very different is the heart of flesh, the broken and contrite heart. Sinners have none to blame but themselves, for that pride and ungodliness which abuse the bounty and patience of God. For, however the Lord hardens the hearts of men, it is always as a punishment of former sins.

## Verses 8–12

When the Egyptians were not wrought upon by the death of their cattle, God sent a plague that seized their own bodies. If lesser judgments do not work, God will send greater. Sometimes God shows men their sin in their punishment. They had oppressed Israel in the furnaces, and now the ashes of the furnace are made a terror to them. The plague itself was very grievous. The magicians themselves were struck with these boils. Their power was restrained before; but they continued to withstand Moses, and to confirm Pharaoh in his unbelief, till they were forced to give way. Pharaoh continued obstinate. He had hardened his own heart, and now God justly gave him up to his own heart's lusts, permitting Satan to blind and harden him. If men shut their eyes against the light, it is just with God to close their eyes. This is the sorest judgment a man can be under out of hell.

## Verses 13–21

Moses is here ordered to deliver a dreadful message to Pharaoh. Providence ordered it, that Moses should have a man of such a fierce and stubborn spirit as this Pharaoh to deal with; and every thing made it a most signal instance of the power of God has to humble and bring down the proudest of his enemies. When God's justice threatens ruin, his mercy at the same time shows a way of escape from it. God not only distinguished between Egyptians and Israelites, but between some Egyptians and others. If Pharaoh will not yield, and so prevent the judgment itself, yet those that will take warning, may take shelter. Some believed the things which were spoken, and they feared, and housed their servants and cattle, and it was their wisdom. Even among the servants of Pharaoh, some trembled at God's word; and shall not the sons of Israel dread it? But others believed not, and left their cattle in the field. Obstinate unbelief is deaf to the fairest warnings, and the wisest counsels, which leaves the blood of those that perish upon their own heads.

## Verses 22–35

Woful havoc this hail made: it killed both men and cattle; the corn above ground was destroyed, and that only preserved which as yet was not come up. The land of Goshen was preserved. God causes rain or hail on one city and not on another, either in mercy or in judgment. Pharaoh humbled himself to Moses. No man could have spoken better: he owns himself wrong; he owns that the Lord is righteous; and God must be justified when he speaks, though he speaks in thunder and lightning. Yet his heart was hardened all this while. Moses pleads with God: though he had reason to think Pharaoh would repent of his repentance, and he told him so, yet he promises to be his friend. Moses went out of the city, notwithstanding the hail and lightning which kept Pharaoh and his servants within doors. Peace with God makes men thunder-proof. Pharaoh was frightened by the tremendous judgment; but when that was over, his fair promises were forgotten. Those that are not bettered by judgments and mercies, commonly become worse.

