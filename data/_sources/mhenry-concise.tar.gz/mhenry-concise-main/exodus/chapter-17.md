---
title: "Exodus 17 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "17"
description: "In this chapter: The Israelites murmur for water at Rephidim, God sendeth it out of the rock. (1–7). Amalek overcome, The prayers of Moses. (8–16)."
weight: 17
---

# Exodus 17 

## Chapter Outline

- The Israelites murmur for water at Rephidim, God sendeth it out of the rock. (1–7)
- Amalek overcome, The prayers of Moses. (8–16)

## Verses 1–7

The children of Israel journeyed according to the commandment of the Lord, led by the pillar of cloud and fire, yet they came to a place where there was no water for them to drink. We may be in the way of duty, yet may meet with troubles, which Providence brings us into, for the trial of our faith, and that God may be glorified in our relief. They began to question whether God was with them or not. This is called their “tempting God,” which signifies distrust of him after they had received such proofs of his power and goodness. Moses mildly answered them. It is folly to answer passion with passion; that makes bad worse. God graciously appeared to help them. How wonderful the patience and forbearance of God toward provoking sinners! That he might show his power as well as his pity, and make it a miracle of mercy, he gave them water out of a rock. God can open fountains for us where we least expect them. Those who, in this wilderness, keep to God's way, may trust him to provide for them. Also, let this direct us to depend on Christ's grace. The apostle says, that Rock was Christ, 1Co 10:4, it was a type of him. While the curse of God might justly have been executed upon our guilty souls, behold the Son of God is smitten for us. Let us ask and receive. There was a constant, abundant supply of this water. Numerous as believers are, the supply of the Spirit of Christ is enough for all. The water flowed from the rock in streams to refresh the wilderness, and attended them on their way towards Canaan; and this water flows from Christ, through the ordinances, in the barren wilderness of this world, to refresh our souls, until we come to glory. A new name was given to the place, in remembrance, not of the mercy of their supply, but of the sin of their murmuring: “Massah,” Temptation, because they tempted God; “Meribah,” Strife, because they chid with Moses. Sin leaves a blot upon the name.

## Verses 8–16

Israel engaged with Amalek in their own necessary defence. God makes his people able, and calls them to various services for the good of his church. Joshua fights, Moses prays, both minister to Israel. The rod was held up, as the banner to encourage the soldiers. Also to God, by way of appeal to him. Moses was tired. The strongest arm will fail with being long held out; it is God only whose hand is stretched out still. We do not find that Joshua's hands were heavy in fighting, but Moses' hands were heavy in praying; the more spiritual any service is, the more apt we are to fail and flag in it. To convince Israel that the hand of Moses, whom they had been chiding, did more for their safety than their own hands, his rod than their sword, the success rises and falls as Moses lifts up or lets down his hands. The church's cause is more or less successful, as her friends are more or less strong in faith, and fervent in prayer. Moses, the man of God, is glad of help. We should not be shy, either of asking help from others, or of giving help to others. The hands of Moses being thus stayed, were steady till the going down of the sun. It was great encouragement to the people to see Joshua before them in the field of battle, and Moses above them on the hill. Christ is both to us; our Joshua, the Captain of our salvation, who fights our battles, and our Moses, who ever lives, making intercession above, that our faith fail not. Weapons formed against God's Israel cannot prosper long, and shall be broken at last. Moses must write what had been done, what Amalek had done against Israel; write their bitter hatred; write their cruel attempts; let them never be forgotten, nor what God had done for Israel in saving them from Amalek. Write what should be done; that in process of time Amalek should be totally ruined and rooted out. Amalek's destruction was typical of the destruction of all the enemies of Christ and his kingdom.

