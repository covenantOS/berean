---
title: "2 Peter | Matthew Henry Concise Commentary"
linkTitle: "2 Peter"
weight: 61
description: >
  Read commentary notes on 2 Peter from Matthew Henry's Concise Commentary on the Bible online.
layout: single-section
---

# 2 Peter

This epistle clearly is connected with the former epistle of Peter. The apostle having stated the blessings to which God has called Christians, exhorts those who had received these precious gifts, to endeavour to improve in graces and virtues. They are urged to this from the wickedness of false teachers. They are guarded against impostors and scoffers, by disproving their false assertions, ch. 3:1–7, and by showing why the great day of Christ's coming was delayed, with a description of its awful circumstances and consequences; and suitable exhortations to diligence and holiness are given.

{{< cards >}}
{{< card link="./chapter-1" title="Chapter 1" icon="book-open" >}}
{{< card link="./chapter-2" title="Chapter 2" icon="book-open" >}}
{{< card link="./chapter-3" title="Chapter 3" icon="book-open" >}}
{{< /cards >}}
