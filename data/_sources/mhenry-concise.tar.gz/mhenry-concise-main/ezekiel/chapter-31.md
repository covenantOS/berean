---
title: "Ezekiel 31 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "31"
description: "In this chapter: The glory of Assyria. (1-9). Its fall, and the like for Egypt. (10-18)."
weight: 31
---

# Ezekiel 31 

## Chapter Outline

- The glory of Assyria. (1-9)
- Its fall, and the like for Egypt. (10-18)

## Verses 1-9

The falls of others, both into sin and ruin, warn us not to be secure or high-minded. The prophet is to show an instance of one whom the king of Egypt resembled in greatness, the Assyrian, compared to a stately cedar. Those who excel others, make themselves the objects of envy; but the blessings of the heavenly paradise are not liable to such alloy. The utmost security that any creature can give, is but like the shadow of a tree, a scanty and slender protection. But let us flee to God for protection, there we shall be safe. His hand must be owned in the rising of the great men of the earth, and we must not envy them. Though worldly people may seem to have firm prosperity, yet it only seems so.

## Verses 10-18

The king of Egypt resembled the king of Assyria in his greatness: here we see he resembles him in his pride. And he shall resemble him in his fall. His own sin brings his ruin. None of our comforts are ever lost, but what have been a thousand times forfeited. When great men fall, many fall with them, as many have fallen before them. The fall of proud men is for warning to others, to keep them humble. See how low Pharaoh lies; and see what all his pomp and pride are come to. It is best to be a lowly tree of righteousness, yielding fruit to the glory of God, and to the good of men. The wicked man is often seen flourishing like the cedar, and spreading like the green bay tree, but he soon passes away, and his place is no more found. Let us then mark the perfect man, and behold the upright, for the end of that man is peace.


