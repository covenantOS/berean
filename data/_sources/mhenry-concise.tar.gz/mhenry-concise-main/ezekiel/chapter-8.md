---
title: "Ezekiel 8 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "8"
description: "In this chapter: The idolatries committed by the Jewish rulers. (1-6). The superstitions to which the Jews were then devoted, the Egyptian. (7-12). The Phoenician. (13,14). The Persian. (15,16) . The heinousness of their sin. (17,18)."
weight: 8
---

# Ezekiel 8 

## Chapter Outline

- The idolatries committed by the Jewish rulers. (1-6)
- The superstitions to which the Jews were then devoted, the Egyptian. (7-12)
- The Phoenician. (13,14)
- The Persian. (15,16) 
- The heinousness of their sin. (17,18)

## Verses 1-6

The glorious personage Ezekiel beheld in vision, seemed to take hold upon him, and he was conveyed in spirit to Jerusalem. There, in the inner court of the temple, was prepared a place for some base idol. The whole was presented in vision to the prophet. If it should please God to give any man a clear view of his glory and majesty, and of all the abominations committing in any one city, he would then admit the justice of the severest punishments God should inflict thereon.

## Verses 7-12

A secret place was, as it were, opened, where the prophet saw creatures painted on the walls, and a number of the elders of Israel worshipped before them. No superiority in worldly matters will preserve men from lust, or idolatries, when they are left to their own deceitful hearts; and those who are soon wearied in the service of God, often grudge no toil nor expense when following their superstitions. When hypocrites screen themselves behind the wall of an outward profession, there is some hole or other left in the wall, something that betrays them to those who look diligently. There is a great deal of secret wickedness in the world. They think themselves out of God's sight. But those are ripe indeed for ruin, who lay the blame of their sins upon the Lord.

## Verses 13-18

The yearly lamenting for Tammuz was attended with infamous practices; and the worshippers of the sun here described, are supposed to have been priests. The Lord appeals to the prophet concerning the heinousness of the crime; "and lo, they put the branch to their nose," denoting some custom used by idolaters in honour of the idols they served. The more we examine human nature and our own hearts, the more abominations we shall discover; and the longer the believer searches himself, the more he will humble himself before God, and the more will he value the fountain open for sin, and seek to wash therein.


