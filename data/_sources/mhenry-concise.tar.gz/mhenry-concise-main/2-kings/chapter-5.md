---
title: "2 Kings 5 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "5"
description: "In this chapter: Naaman's leprosy. (1–8). The cure of it. (9–14). Elisha refuses Naaman's gifts. (15–19). Gehazi's covetousness and falsehood. (20–27)."
weight: 5
---

# 2 Kings 5 

## Chapter Outline

- Naaman's leprosy. (1–8)
- The cure of it. (9–14)
- Elisha refuses Naaman's gifts. (15–19)
- Gehazi's covetousness and falsehood. (20–27)

## Verses 1–8

Though the Syrians were idolaters, and oppressed God's people, yet the deliverance of which Naaman had been the means, is here ascribed to the Lord. Such is the correct language of Scripture, while those who write common history, plainly show that God is not in all their thoughts. No man's greatness, or honour, can place him our of the reach of the sorest calamities of human life: there is many a sickly, crazy body under rich and gay clothing. Every man has some but or other, something that blemishes and diminishes him, some allay to his grandeur, some damp to his joy. This little maid, though only a girl, could give an account of the famous prophet the Israelites had among them. Children should be early told of the wondrous works of God, that, wherever they go, they may talk of them. As became a good servant, she desired the health and welfare of her master, though she was a captive, a servant by force; much more should servants by choice, seek their masters' good. Servants may be blessings to the families where they are, by telling what they know of the glory of God, and the honour of his prophets. Naaman did not despise what she told, because of her meanness. It would be well if men were as sensible of the burden of sin as they are of bodily disease. And when they seek the blessings which the Lord sends in answer to the prayers of his faithful people, they will find nothing can be had, except they come as beggars for a free gift, not as lords to demand or purchase.

## Verses 9–14

Elisha knew Naaman to be a proud man, and he would let him know, that before the great God all men stand upon the same level. All God's commands make trial of men's spirits, especially those which direct a sinner how to apply for the blessings of salvation. See in Naaman the folly of pride; a cure will not content him, unless he be cured with pomp and parade. He scorns to be healed, unless he be humoured. The way by which a sinner is received and made holy, through the blood, and by the Spirit of Christ, through faith alone in his name, does not sufficiently humour or employ self, to please the sinner's heart. Human wisdom thinks it can supply wiser and better methods of cleansing. Observe, masters should be willing to hear reason. As we should be deaf to the counsel of the ungodly, though given by great and respected names, so we are to have our ears open to good advice, though brought by those below us. Wouldst thou not do any thing? When diseased sinners are content to do any thing, to submit to any thing, to part with any thing, for a cure, then, and not till then, is there any hope of them. The methods for the healing of the leprosy of sin, are so plain, that we are without excuse if we do not observe them. It is but, Believe, and be saved; Repent, and be pardoned; Wash, and be clean. The believer applies for salvation, not neglecting, altering, or adding to the Saviour's directions; he is thus made clean from guilt, while others, who neglect them, live and die in the leprosy of sin.

## Verses 15–19

The mercy of the cure affected Naaman more than the miracle. Those are best able to speak of the power of Divine grace, who themselves experience it. He also shows himself grateful to Elisha the prophet. Elijah refused any recompence, not because he thought it unlawful, for he received presents from others, but to show this new convert that the servants of the God of Israel looked upon worldly wealth with a holy contempt. The whole work was from God, in such a manner, that the prophet would not give counsel when he had no directions from the Lord. It is not well violently to oppose the lesser mistakes which unite with men's first convictions; we cannot bring men forward any faster than the Lord prepares them to receive instruction. Yet as to us, if, in covenanting with God, we desire to reserve any known sin, to continue to indulge ourselves in it, that is a breach of his covenant. Those who truly hate evil, will make conscience of abstaining from all appearances of evil.

## Verses 20–27

Naaman, a Syrian, a courtier, a soldier, had many servants, and we read how wise and good they were. Elisha, a holy prophet, a man of God, has but one servant, and he proves a base liar. The love of money, that root of all evil, was at the bottom of Gehazi's sin. He thought to impose upon the prophet, but soon found that the Spirit of prophecy could not be deceived, and that it was in vain to lie to the Holy Ghost. It is folly to presume upon sin, in hopes of secrecy. When thou goest aside into any by-path, does not thy own conscience go with thee? Does not the eye of God go with thee? He that covers his sin, shall not prosper; particularly, a lying tongue is but for a moment. All the foolish hopes and contrivances of carnal worldlings are open before God. It is not a time to increase our wealth, when we can only do it in such ways as are dishonourable to God and religion, or injurious to others. Gehazi was punished. If he will have Naaman's money, he shall have his disease with it. What was Gehazi profited, though he gained two talents, when thereby he lost his health, his honour, his peace, his service, and, if repentance prevented not, his soul for ever? Let us beware of hypocrisy and covetousness, and dread the curse of spiritual leprosy remaining on our souls.

