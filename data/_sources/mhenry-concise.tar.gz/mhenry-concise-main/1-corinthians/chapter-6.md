---
title: "1 Corinthians 6 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "6"
description: "In this chapter: Cautions against going to law in heathen courts. (1–8). Sins which, if lived and died in, shut out from the kingdom of God. (9–11). Our bodies, which are the members of Christ, and temples of the Holy Ghost, must not be defiled. (12–20)."
weight: 6
---

# 1 Corinthians 6 

## Chapter Outline

- Cautions against going to law in heathen courts. (1–8)
- Sins which, if lived and died in, shut out from the kingdom of God. (9–11)
- Our bodies, which are the members of Christ, and temples of the Holy Ghost, must not be defiled. (12–20)

## Verses 1–8

Christians should not contend with one another, for they are brethren. This, if duly attended to, would prevent many law-suits, and end many quarrels and disputes. In matters of great damage to ourselves or families, we may use lawful means to right ourselves, but Christians should be of a forgiving temper. Refer the matters in dispute, rather than go to law about them. They are trifles, and may easily be settled, if you first conquer your own spirits. Bear and forbear, and the men of least skill among you may end your quarrels. It is a shame that little quarrels should grow to such a head among Christians, that they cannot be determined by the brethren. The peace of a man's own mind, and the calm of his neighbourhood, are worth more than victory. Lawsuits could not take place among brethren, unless there were faults among them.

## Verses 9–11

The Corinthians are warned against many great evils, of which they had formerly been guilty. There is much force in these inquiries, when we consider that they were addressed to a people puffed up with a fancy of their being above others in wisdom and knowledge. All unrighteousness is sin; all reigning sin, nay, every actual sin, committed with design, and not repented of, shuts out of the kingdom of heaven. Be not deceived. Men are very much inclined to flatter themselves that they may live in sin, yet die in Christ, and go to heaven. But we cannot hope to sow to the flesh, and reap everlasting life. They are reminded what a change the gospel and grace of God had made in them. The blood of Christ, and the washing of regeneration, can take away all guilt. Our justification is owing to the suffering and merit of Christ; our sanctification to the working of the Holy Spirit; but both go together. All who are made righteous in the sight of God, are made holy by the grace of God.

## Verses 12–20

Some among the Corinthians seem to have been ready to say, All things are lawful for me. This dangerous conceit St. Paul opposes. There is a liberty wherewith Christ has made us free, in which we must stand fast. But surely a Christian would never put himself into the power of any bodily appetite. The body is for the Lord; is to be an instrument of righteousness to holiness, therefore is never to be made an instrument of sin. It is an honour to the body, that Jesus Christ was raised from the dead; and it will be an honour to our bodies, that they will be raised. The hope of a resurrection to glory, should keep Christians from dishonouring their bodies by fleshly lusts. And if the soul be united to Christ by faith, the whole man is become a member of his spiritual body. Other vices may be conquered in fight; that here cautioned against, only by flight. And vast multitudes are cut off by this vice in its various forms and consequences. Its effects fall not only directly upon the body, but often upon the mind. Our bodies have been redeemed from deserved condemnation and hopeless slavery by the atoning sacrifice of Christ. We are to be clean, as vessels fitted for our Master's use. Being united to Christ as one spirit, and bought with a price of unspeakable value, the believer should consider himself as wholly the Lord's, by the strongest ties. May we make it our business, to the latest day and hour of our lives, to glorify God with our bodies, and with our spirits which are his.

