---
title: "1 Corinthians 10 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "10"
description: "In this chapter: The great privileges, and yet terrible overthrow of the Israelites in the wilderness. (1–5). Cautions against all idolatrous, and other sinful practices. (6–14). The partaking in idolatry cannot exist with having communion with Christ. (15–22). All we do to be to the glory of God, and without offence to the consciences of others. (23–33)."
weight: 10
---

# 1 Corinthians 10 

## Chapter Outline

- The great privileges, and yet terrible overthrow of the Israelites in the wilderness. (1–5)
- Cautions against all idolatrous, and other sinful practices. (6–14)
- The partaking in idolatry cannot exist with having communion with Christ. (15–22)
- All we do to be to the glory of God, and without offence to the consciences of others. (23–33)

## Verses 1–5

To dissuade the Corinthians from communion with idolaters, and security in any sinful course, the apostle sets before them the example of the Jewish nation of old. They were, by a miracle, led through the Red Sea, where the pursuing Egyptians were drowned. It was to them a typical baptism. The manna on which they fed was a type of Christ crucified, the Bread which came down from heaven, which whoso eateth shall live for ever. Christ is the Rock on which the Christian church is built; and of the streams that issue therefrom, all believers drink, and are refreshed. It typified the sacred influences of the Holy Spirit, as given to believers through Christ. But let none presume upon their great privileges, or profession of the truth; these will not secure heavenly happiness.

## Verses 6–14

Carnal desires gain strength by indulgence, therefore should be checked in their first rise. Let us fear the sins of Israel, if we would shun their plagues. And it is but just to fear, that such as tempt Christ, will be left by him in the power of the old serpent. Murmuring against God's disposals and commands, greatly provokes him. Nothing in Scripture is written in vain; and it is our wisdom and duty to learn from it. Others have fallen, and so may we. The Christian's security against sin is distrust of himself. God has not promised to keep us from falling, if we do not look to ourselves. To this word of caution, a word of comfort is added. Others have the like burdens, and the like temptations: what they bear up under, and break through, we may also. God is wise as well as faithful, and will make our burdens according to our strength. He knows what we can bear. He will make a way to escape; he will deliver either from the trial itself, or at least the mischief of it. We have full encouragement to flee from sin, and to be faithful to God. We cannot fall by temptation, if we cleave fast to him. Whether the world smiles or frowns, it is an enemy; but believers shall be strengthened to overcome it, with all its terrors and enticements. The fear of the Lord, put into their hearts, will be the great means of safety.

## Verses 15–22

Did not the joining in the Lord's supper show a profession of faith in Christ crucified, and of adoring gratitude to him for his salvation? Christians, by this ordinance, and the faith therein professed, were united as the grains of wheat in one loaf of bread, or as the members in the human body, seeing they were all united to Christ, and had fellowship with him and one another. This is confirmed from the Jewish worship and customs in sacrifice. The apostle applies this to feasting with idolaters. Eating food as part of a heathen sacrifice, was worshipping the idol to whom it was made, and having fellowship or communion with it; just as he who eats the Lord's supper, is accounted to partake in the Christian sacrifice, or as they who ate the Jewish sacrifices partook of what was offered on their altar. It was denying Christianity; for communion with Christ, and communion with devils, could never be had at once. If Christians venture into places, and join in sacrifices to the lust of the flesh, the lust of the eye, and the pride of life, they will provoke God.

## Verses 23–33

There were cases wherein Christians might eat what had been offered to idols, without sin. Such as when the flesh was sold in the market as common food, for the priest to whom it had been given. But a Christian must not merely consider what is lawful, but what is expedient, and to edify others. Christianity by no means forbids the common offices of kindness, or allows uncourteous behaviour to any, however they may differ from us in religious sentiments or practices. But this is not to be understood of religious festivals, partaking in idolatrous worship. According to this advice of the apostle, Christians should take care not to use their liberty to the hurt of others, or to their own reproach. In eating and drinking, and in all we do, we should aim at the glory of God, at pleasing and honouring him. This is the great end of all religion, and directs us where express rules are wanting. A holy, peaceable, and benevolent spirit, will disarm the greatest enemies.

