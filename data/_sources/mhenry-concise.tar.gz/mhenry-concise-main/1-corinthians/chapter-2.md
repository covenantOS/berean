---
title: "1 Corinthians 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: The plain manner in which the apostle preached Christ crucified. (1–5). The wisdom contained in this doctrine. (6–9). It cannot be duly known but by the Holy Spirit. (10–16)."
weight: 2
---

# 1 Corinthians 2 

## Chapter Outline

- The plain manner in which the apostle preached Christ crucified. (1–5)
- The wisdom contained in this doctrine. (6–9)
- It cannot be duly known but by the Holy Spirit. (10–16)

## Verses 1–5

Christ, in his person, and offices, and sufferings, is the sum and substance of the gospel, and ought to be the great subject of a gospel minister's preaching, but not so as to leave out other parts of God's revealed truth and will. Paul preached the whole counsel of God. Few know the fear and trembling of faithful ministers, from a deep sense of their own weakness They know how insufficient they are, and are fearful for themselves. When nothing but Christ crucified is plainly preached, the success must be entirely from Divine power accompanying the word, and thus men are brought to believe, to the salvation of their souls.

## Verses 6–9

Those who receive the doctrine of Christ as Divine, and, having been enlightened by the Holy Spirit, have looked well into it, see not only the plain history of Christ, and him crucified, but the deep and admirable designs of Divine wisdom therein. It is the mystery made manifest to the saints, Col 1:26, though formerly hid from the heathen world; it was only shown in dark types and distant prophecies, but now is revealed and made known by the Spirit of God. Jesus Christ is the Lord of glory; a title much too great for any creature. There are many things which people would not do, if they knew the wisdom of God in the great work of redemption. There are things God hath prepared for those that love him, and wait for him, which sense cannot discover, no teaching can convey to our ears, nor can it yet enter our hearts. We must take them as they stand in the Scriptures, as God hath been pleased to reveal them to us.

## Verses 10–16

God has revealed true wisdom to us by his Spirit. Here is a proof of the Divine authority of the Holy Scriptures, 2Pe 1:21. In proof of the Divinity of the Holy Ghost, observe, that he knows all things, and he searches all things, even the deep things of God. No one can know the things of God, but his Holy Spirit, who is one with the Father and the Son, and who makes known Divine mysteries to his church. This is most clear testimony, both to the real Godhead and the distinct person of the Holy Spirit. The apostles were not guided by worldly principles. They had the revelation of these things from the Spirit of God, and the saving impression of them from the same Spirit. These things they declared in plain, simple language, taught by the Holy Spirit, totally different from the affected oratory or enticing words of man's wisdom. The natural man, the wise man of the world, receives not the things of the Spirit of God. The pride of carnal reasoning is really as much opposed to spirituality, as the basest sensuality. The sanctified mind discerns the real beauties of holiness, but the power of discerning and judging about common and natural things is not lost. But the carnal man is a stranger to the principles, and pleasures, and actings of the Divine life. The spiritual man only, is the person to whom God gives the knowledge of his will. How little have any known of the mind of God by natural power! And the apostles were enabled by his Spirit to make known his mind. In the Holy Scriptures, the mind of Christ, and the mind of God in Christ, are fully made known to us. It is the great privilege of Christians, that they have the mind of Christ revealed to them by his Spirit. They experience his sanctifying power in their hearts, and bring forth good fruits in their lives.

