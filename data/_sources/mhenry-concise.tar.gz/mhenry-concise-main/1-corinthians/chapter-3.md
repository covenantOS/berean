---
title: "1 Corinthians 3 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "3"
description: "In this chapter: The Corinthians reproved for their contentions. (1–4). The true servants of Christ can do nothing without him. (5–9). He is the only foundation, and every one should take heed what he builds thereon. (10–15). The churches of Christ ought to be kept pure, and to be humble. (16, 17). And they should not glory in men, because ministers and all things else are theirs through Christ. (18–23)."
weight: 3
---

# 1 Corinthians 3 

## Chapter Outline

- The Corinthians reproved for their contentions. (1–4)
- The true servants of Christ can do nothing without him. (5–9)
- He is the only foundation, and every one should take heed what he builds thereon. (10–15)
- The churches of Christ ought to be kept pure, and to be humble. (16, 17)
- And they should not glory in men, because ministers and all things else are theirs through Christ. (18–23)

## Verses 1–4

The most simple truths of the gospel, as to man's sinfulness and God's mercy, repentance towards God, and faith in our Lord Jesus Christ, stated in the plainest language, suit the people better than deeper mysteries. Men may have much doctrinal knowledge, yet be mere beginners in the life of faith and experience. Contentions and quarrels about religion are sad evidences of carnality. True religion makes men peaceable, not contentious. But it is to be lamented, that many who should walk as Christians, live and act too much like other men. Many professors, and preachers also, show themselves to be yet carnal, by vain-glorious strife, eagerness for dispute, and readiness to despise and speak evil of others.

## Verses 5–9

The ministers about whom the Corinthians contended, were only instruments used by God. We should not put ministers into the place of God. He that planteth and he that watereth are one, employed by one Master, trusted with the same revelation, busied in one work, and engaged in one design. They have their different gifts from one and the same Spirit, for the very same purposes; and should carry on the same design heartily. Those who work hardest shall fare best. Those who are most faithful shall have the greatest reward. They work together with God, in promoting the purposes of his glory, and the salvation of precious souls; and He who knows their work, will take care they do not labour in vain. They are employed in his husbandry and building; and He will carefully look over them.

## Verses 10–15

The apostle was a wise master-builder; but the grace of God made him such. Spiritual pride is abominable; it is using the greatest favours of God, to feed our own vanity, and make idols of ourselves. But let every man take heed; there may be bad building on a good foundation. Nothing must be laid upon it, but what the foundation will bear, and what is of a piece with it. Let us not dare to join a merely human or a carnal life with a Divine faith, the corruption of sin with the profession of Christianity. Christ is a firm, abiding, and immovable Rock of ages, every way able to bear all the weight that God himself or the sinner can lay upon him; neither is there salvation in any other. Leave out the doctrine of his atonement, and there is no foundation for our hopes. But of those who rest on this foundation, there are two sorts. Some hold nothing but the truth as it is in Jesus, and preach nothing else. Others build on the good foundation what will not abide the test, when the day of trail comes. We may be mistaken in ourselves and others; but there is a day coming that will show our actions in the true light, without covering or disguise. Those who spread true and pure religion in all its branches, and whose work will abide in the great day, shall receive a reward. And how great! how much exceeding their deserts! There are others, whose corrupt opinions and doctrines, or vain inventions and usages in the worship of God, shall be made known, disowned, and rejected, in that day. This is plainly meant of a figurative fire, not of a real one; for what real fire can consume religious rites or doctrines? And it is to try every man's works, those of Paul and Apollos, as well as others. Let us consider the tendency of our undertakings, compare them with God's word, and judge ourselves, that we be not judged of the Lord.

## Verses 16, 17

From other parts of the epistle, it appears that the false teachers among the Corinthians taught unholy doctrines. Such teaching tended to corrupt, to pollute, and destroy the building, which should be kept pure and holy for God. Those who spread loose principles, which render the church of God unholy, bring destruction upon themselves. Christ by his Spirit dwells in all true believers. Christians are holy by profession, and should be pure and clean, both in heart and conversation. He is deceived who deems himself the temple of the Holy Ghost, yet is unconcerned about personal holiness, or the peace and purity of the church.

## Verses 18–23

To have a high opinion of our own wisdom, is but to flatter ourselves; and self-flattery is the next step to self-deceit. The wisdom that wordly men esteem, is foolishness with God. How justly does he despise, and how easily can he baffle and confound it! The thoughts of the wisest men in the world, have vanity, weakness, and folly in them. All this should teach us to be humble, and make us willing to be taught of God, so as not to be led away, by pretences to human wisdom and skill, from the simple truths revealed by Christ. Mankind are very apt to oppose the design of the mercies of God. Observe the spiritual riches of a true believer; “All are yours,” even ministers and ordinances. Nay, the world itself is yours. Saints have as much of it as Infinite Wisdom sees fit for them, and they have it with the Divine blessing. Life is yours, that you may have a season and opportunity to prepare for the life of heaven; and death is yours, that you may go to the possession of it. It is the kind messenger to take you from sin and sorrow, and to guide you to your Father's house. Things present are yours, for your support on the road; things to come are yours, to delight you for ever at your journey's end. If we belong to Christ, and are true to him, all good belongs to us, and is sure to us. Believers are the subjects of his kingdom. He is Lord over us, we must own his dominion, and cheerfully submit to his command. God in Christ, reconciling a sinful world to himself, and pouring the riches of his grace on a reconciled world, is the sum and substance of the gospel.

