---
title: "1 Chronicles 4 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "4"
description: "In this chapter: Genealogies. (1-43)."
weight: 4
---

# 1 Chronicles 4 

## Chapter Outline

- Genealogies. (1-43)

## Verses 1-43

In this chapter we have a further account of Judah, the most numerous and most famous of all the tribes; also an account of Simeon. The most remarkable person in this chapter is Jabez. We are not told upon what account Jabez was more honourable than his brethren; but we find that he was a praying man. The way to be truly great, is to seek to do God's will, and to pray earnestly. Here is the prayer he made. Jabez prayed to the living and true God, who alone can hear and answer prayer; and, in prayer he regarded him as a God in covenant with his people. He does not express his promise, but leaves it to be understood; he was afraid to promise in his own strength, and resolved to devote himself entirely to God. Lord, if thou wilt bless me and keep me, do what thou wilt with me; I will be at thy command and disposal for ever. As the text reads it, this was the language of a most ardent and affectionate desire, Oh that thou wouldest bless me! Four things Jabez prayed for. 1. That God would bless him indeed. Spiritual blessings are the best blessings: God's blessings are real things, and produce real effects. 2. That He would enlarge his coast. That God would enlarge our hearts, and so enlarge our portion in himself, and in the heavenly Canaan, ought to be our desire and prayer. 3. That God's hand might be with him. God's hand with us, to lead us, protect us, strengthen us, and to work all our works in us and for us, is a hand all-sufficient for us. 4. That he would keep him from evil, the evil of sin, the evil of trouble, all the evil designs of his enemies, that they might not hurt, nor make him a Jabez indeed, a man of sorrow. God granted that which he requested. God is ever ready to hear prayer: his ear is not now heavy.


