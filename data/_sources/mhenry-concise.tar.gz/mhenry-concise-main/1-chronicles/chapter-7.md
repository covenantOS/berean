---
title: "1 Chronicles 7 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "7"
description: "In this chapter: Genealogies. (1-40)."
weight: 7
---

# 1 Chronicles 7 

## Chapter Outline

- Genealogies. (1-40)

## Verses 1-40

Here is no account either of Zebulun or Dan. We can assign no reason why they only should be omitted; but it is the disgrace of the tribe of Dan, that idolatry began in that colony which fixed in Laish, and called it Dan, Jud 18 and there one of the golden calves was set up by Jeroboam. Dan is omitted, Re 7. Men become abominable when they forsake the worship of the true God, for any creature object.


