---
title: "Genesis 11 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "11"
description: "In this chapter: One language in the world, The building of Babel. (1–4). The confusion of tongues, The builders of Babel dispersed. (5–9). The descendants of Shem. (10–26). Terah, father of Abram, grandfather of Lot, they remove to Haran. (27–32)."
weight: 11
---

# Genesis 11 

## Chapter Outline

- One language in the world, The building of Babel. (1–4)
- The confusion of tongues, The builders of Babel dispersed. (5–9)
- The descendants of Shem. (10–26)
- Terah, father of Abram, grandfather of Lot, they remove to Haran. (27–32)

## Verses 1–4

How soon men forget the most tremendous judgments, and go back to their former crimes! Though the desolations of the deluge were before their eyes, though they sprang from the stock of righteous Noah, yet even during his life-time, wickedness increases exceedingly. Nothing but the sanctifying grace of the Holy Spirit can remove the sinful lusts of the human will, and the depravity of the human heart. God's purpose was, that mankind should form many nations, and people all lands. In contempt of the Divine will, and against the counsel of Noah, the bulk of mankind united to build a city and a tower to prevent their separating. Idolatry was begun, and Babel became one of its chief seats. They made one another more daring and resolute. Let us learn to provoke one another to love and to good works, as sinners stir up and encourage one another to wicked works.

## Verses 5–9

Here is an expression after the manner of men; The Lord came down to see the city. God is just and fair in all he does against sin and sinners, and condemns none unheard. Pious Eber is not found among this ungodly crew; for he and his are called the children of God; their souls joined not themselves to the assembly of these children of men. God suffered them to go on some way, that the works of their hands, from which they promised themselves lasting honour, might turn to their lasting reproach. God has wise and holy ends, in allowing the enemies of his glory to carry on their wicked projects a great way, and to prosper long. Observe the wisdom and mercy of God, in the methods taken for defeating this undertaking. And the mercy of God in not making the penalty equal to the offence; for he deals not with us according to our sins. The wisdom of God, in fixing upon a sure way to stop these proceedings. If they could not understand one another, they could not help one another; this would take them off from their building. God has various means, and effectual ones, to baffle and defeat the projects of proud men that set themselves against him, and particularly he divides them among themselves. Notwithstanding their union and obstinacy God was above them; for who ever hardened his heart against him, and prospered? Their language was confounded. We all suffer by it to this day: in all the pains and trouble used to learn the languages we have occasion for, we suffer for the rebellion of our ancestors at Babel. Nay, and those unhappy disputes, which are strifes of words, and arise from misunderstanding one another's words, for aught we know, are owing to this confusion of tongues. They left off to build the city. The confusion of their tongues not only unfitted them for helping one another, but they saw the hand of the Lord gone out against them. It is wisdom to leave off that which we see God fights against. God is able to blast and bring to nought all the devices and designs of Babel-builders: there is no wisdom nor counsel against the Lord. The builders departed according to their families, and the tongue they spake, to the countries and places allotted to them. The children of men never did, nor ever will, come all together again, till the great day, when the Son of man shall sit upon the throne of his glory, and all nations shall be gathered before him.

## Verses 10–26

Here is a genealogy, or list of names, ending in Abram, the friend of God, and thus leading towards Christ, the promised Seed, who was the son of Abram. Nothing is left upon record but their names and ages; the Holy Ghost seeming to hasten through them to the history of Abram. How little do we know of those that are gone before us in this world, even of those that lived in the same places where we live, as we likewise know little of those who now live in distant places! We have enough to do to mind our own work. When the earth began to be peopled, men's lives began to shorten; this was the wise disposal of Providence.

## Verses 27–32

Here begins the story of Abram, whose name is famous in both Testaments. Even the children of Eber had become worshippers of false gods. Those who are through grace, heirs of the land of promise, ought to remember what was the land of their birth; what was their corrupt and sinful state by nature. Abram's brethren were, Nahor, out of whose family both Isaac and Jacob had their wives; and Haran, the father of Lot, who died before his father. Children cannot be sure that they shall outlive their parents. Haran died in Ur, before the happy removal of the family out of that idolatrous country. It concerns us to hasten out of our natural state, lest death surprise us in it. We here read of Abram's departure out of Ur of the Chaldees, with his father Terah, his nephew Lot, and the rest of his family, in obedience to the call of God. This chapter leaves them about mid-way between Ur and Canaan, where they dwelt till Terah's death. Many reach to Charran, and yet fall short of Canaan; they are not far from the kingdom of God, and yet never come thither.

