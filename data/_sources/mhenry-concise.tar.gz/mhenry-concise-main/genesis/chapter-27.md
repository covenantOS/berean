---
title: "Genesis 27 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "27"
description: "In this chapter: Isaac sends Esau for venison. (1–5). Rebekah teaches Jacob to obtain the blessing. (6–17). Jacob, pretending to be Esau, obtains the blessing. (18–29). Isaac's fear, Esau's importunity. (30–40). Esau threatens Jacob's life, Rebekah sends Jacob away. (41–46)."
weight: 27
---

# Genesis 27 

## Chapter Outline

- Isaac sends Esau for venison. (1–5)
- Rebekah teaches Jacob to obtain the blessing. (6–17)
- Jacob, pretending to be Esau, obtains the blessing. (18–29)
- Isaac's fear, Esau's importunity. (30–40)
- Esau threatens Jacob's life, Rebekah sends Jacob away. (41–46)

## Verses 1–5

The promises of the Messiah, and of the land of Canaan, had come down to Isaac. Isaac being now about 135 years of age, and his sons about 75, and not duly considering the Divine word concerning his two sons, that the elder should serve the younger, resolved to put all the honour and power that were in the promise, upon Esau his eldest son. We are very apt to take measures rather from our own reason than from Divine revelation, and thereby often miss our way.

## Verses 6–17

Rebekah knew that the blessing was intended for Jacob, and expected he would have it. But she wronged Isaac by putting a cheat on him; she wronged Jacob by tempting him to wickedness. She put a stumbling-block in Esau's way, and gave him a pretext for hatred to Jacob and to religion. All were to be blamed. It was one of those crooked measures often adopted to further the Divine promises; as if the end would justify, or excuse wrong means. Thus many have acted wrong, under the idea of being useful in promoting the cause of Christ. The answer to all such things is that which God addressed to Abraham, I am God Almighty; walk before me and be thou perfect. And it was a very rash speech of Rebekah, “Upon me be thy curse, my son.” Christ has borne the curse of the law for all who take upon them the yoke of the command, the command of the gospel. But it is too daring for any creature to say, Upon me be thy curse.

## Verses 18–29

Jacob, with some difficulty, gained his point, and got the blessing. This blessing is in very general terms. No mention is made of the distinguishing mercies in the covenant with Abraham. This might be owing to Isaac having Esau in his mind, though it was Jacob who was before him. He could not be ignorant how Esau had despised the best things. Moreover, his attachment to Esau, so as to disregard the mind of God, must have greatly weakened his own faith in these things. It might therefore be expected, that leanness would attend his blessing, agreeing with the state of his mind.

## Verses 30–40

When Esau understood that Jacob had got the blessing, he cried with a great and exceeding bitter cry. The day is coming, when those that now make light of the blessings of the covenant, and sell their title to spiritual blessings for that which is of no value, will, in vain, ask urgently for them. Isaac, when made sensible of the deceit practised on him, trembled exceedingly. Those who follow the choice of their own affections, rather than the Divine will, get themselves into perplexity. But he soon recovers, and confirms the blessing he had given to Jacob, saying, I have blessed him, and he shall be blessed. Those who part with their wisdom and grace, their faith and a good conscience, for the honours, wealth, or pleasures of this world, however they feign a zeal for the blessing, have judged themselves unworthy of it, and their doom shall be accordingly. A common blessing was bestowed upon Esau. This he desired. Faint desires of happiness, without right choice of the end, and right use of the means, deceive many unto their own ruin. Multitudes go to hell with their mouths full of good wishes. The great difference is, that there is nothing in Esau's blessing which points at Christ; and without that, the fatness of the earth, and the plunder of the field, will stand in little stead. Thus Isaac, by faith, blessed both his sons, according as their lot should be.

## Verses 41–46

Esau bore malice to Jacob on account of the blessing he had obtained. Thus he went in the way of Cain, who slew his brother, because he gained that acceptance with God of which he had rendered himself unworthy. Esau aimed to prevent Jacob or his seed from having the dominion, by taking away his life. Men may fret at God's counsels, but cannot change them. To prevent mischief, Rebekah warned Jacob of his danger, and advised him to withdraw for his safety. We must not presume too far upon the wisdom and resolution, even of the most hopeful and promising children; but care must be taken to keep them out of the way of evil. When reading this chapter, we should not fail to observe, that we must not follow even the best of men further than they act according to the law of God. We must not do evil that good may come. And though God overruled the bad actions recorded in this chapter, to fulfil his purposes, yet we see his judgment of them, in the painful consequences to all the parties concerned. It was the peculiar privilege and advantage of Jacob to convey these spiritual blessings to all nations. The Christ, the Saviour of the world, was to be born of some one family; and Jacob's was preferred to Esau's, out of the good pleasure of Almighty God, who is certainly the best judge of what is fit, and has an undoubted right to dispense his favours as he sees proper, Ro 9:12–15.

