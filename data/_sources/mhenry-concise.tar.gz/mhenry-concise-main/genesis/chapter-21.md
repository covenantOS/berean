---
title: "Genesis 21 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "21"
description: "In this chapter: Birth of Isaac, Sarah's joy. (1–8). Ishmael mocks Isaac. (9–13). Hagar and Ishmael are cast forth, They are relieved and comforted by an angel. (14–21). Abimelech's covenant with Abraham. (22–34)."
weight: 21
---

# Genesis 21 

## Chapter Outline

- Birth of Isaac, Sarah's joy. (1–8)
- Ishmael mocks Isaac. (9–13)
- Hagar and Ishmael are cast forth, They are relieved and comforted by an angel. (14–21)
- Abimelech's covenant with Abraham. (22–34)

## Verses 1–8

Few under the Old Testament were brought into the world with such expectations as Isaac. He was in this a type of Christ, that Seed which the holy God so long promised, and holy men so long expected. He was born according to the promise, at the set time of which God had spoken. God's promised mercies will certainly come at the time which He sets, and that is the best time. Isaac means “laughter,” and there was good reason for the name, ch. 17:17; 18:13. When the Sun of comfort is risen upon the soul, it is good to remember how welcome the dawning of the day was. When Sarah received the promise, she laughed with distrust and doubt. When God gives us the mercies we began to despair of, we ought to remember with sorrow and shame our sinful distrust of his power and promise, when we were in pursuit of them. This mercy filled Sarah with joy and wonder. God's favours to his covenant people are such as surpass their own and others' thoughts and expectations: who could imagine that he should do so much for those that deserve so little, nay, for those that deserve so ill? Who would have said that God should send his Son to die for us, his Spirit to make us holy, his angels to attend us? Who would have said that such great sins should be pardoned, such mean services accepted, and such worthless worms taken into covenant? A short account of Isaac's infancy is given. God's blessing upon the nursing of children, and the preservation of them through the perils of the infant age, are to be acknowledged as signal instances of the care and tenderness of the Divine providence. See Ps 22:9, 10; Ho 11:1, 2.

## Verses 9–13

Let us not overlook the manner in which this family matter instructs us not to rest in outward privileges, or in our own doings. And let us seek the blessings of the new covenant by faith in its Divine Surety. Ishmael's conduct was persecution, being done in profane contempt of the covenant and promise, and with malice against Isaac. God takes notice of what children say and do in their play; and will reckon with them, if they say or do amiss, though their parents do not. Mocking is a great sin, and very provoking to God. And the children of promise must expect to be mocked. Abraham was grieved that Ishmael should misbehave, and Sarah demand so severe a punishment. But God showed him that Isaac must be the father of the promised Seed; therefore, send Ishmael away, lest he corrupt the manners, or try to take the rights of Isaac. The covenant seed of Abraham must be a people by themselves, not mingled with those who were out of covenant: Sarah little thought of this; but God turned aright what she said.

## Verses 14–21

If Hagar and Ishmael had behaved well in Abraham's family, they might have continued there; but they were justly punished. By abusing privileges, we forfeit them. Those who know not when they are well off, will be made to know the worth of mercies by the want of them. They were brought to distress in the wilderness. It is not said that the provisions were spent, or that Abraham sent them away without money. But the water was spent; and having lost their way, in that hot climate Ishmael was soon overcome with fatigue and thirst. God's readiness to help us when we are in trouble, must not slacken, but quicken our endeavours to help ourselves. The promise concerning her son is repeated, as a reason why Hagar should bestir herself to help him. It should engage our care and pains about children and young people, to consider that we know not what great use God has designed them for, and may make of them. The angel directs her to a present supply. Many who have reason to be comforted, go mourning from day to day, because they do not see the reason they have for comfort. There is a well of water near them in the covenant of grace, but they are not aware of it, till the same God that opened their eyes to see their wound, opens them to see their remedy. Paran was a wild place, fit for a wild man; such as Ishmael. Those who are born after the flesh, take up with the wilderness of this world, while the children of the promise aim at the heavenly Canaan, and cannot be at rest till they are there. Yet God was with the lad; his outward welfare was owing to this.

## Verses 22–34

Abimelech felt sure that the promises of God would be fulfilled to Abraham. It is wise to connect ourselves with those who are blessed of God; and we ought to requite kindness to those who have been kind to us. Wells of water are scarce and valuable in eastern countries. Abraham took care to have his title to the well allowed, to prevent disputes in future. No more can be expected from an honest man than that he be ready to do right, as soon as he knows he has done wrong. Abraham, being now in a good neighbourhood, stayed a great while there. There he made, not only a constant practice, but an open profession of his religion. There he called on the name of the Lord, as the everlasting God; probably in the grove he planted, which was his place of prayer. Abraham kept up public worship, in which his neighbours might join. Good men should do all they can to make others so. Wherever we sojourn, we must neither neglect nor be ashamed of the worship of Jehovah.

