---
title: "2 Corinthians 3 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "3"
description: "In this chapter: The preference of the gospel to the law given by Moses. (1–11). The preaching of the apostle was suitable to the excellency and evidence of the gospel, through the power of the Holy Ghost. (12–18)."
weight: 3
---

# 2 Corinthians 3 

## Chapter Outline

- The preference of the gospel to the law given by Moses. (1–11)
- The preaching of the apostle was suitable to the excellency and evidence of the gospel, through the power of the Holy Ghost. (12–18)

## Verses 1–11

Even the appearance of self-praise and courting human applause, is painful to the humble and spiritual mind. Nothing is more delightful to faithful ministers, or more to their praise, than the success of their ministry, as shown in the spirits and lives of those among whom they labour. The law of Christ was written in their hearts, and the love of Christ shed abroad there. Nor was it written in tables of stone, as the law of God given to Moses, but on the fleshy (not fleshly, as fleshliness denotes sensuality) tables of the heart, Eze 36:26. Their hearts were humbled and softened to receive this impression, by the new-creating power of the Holy Spirit. He ascribes all the glory to God. And remember, as our whole dependence is upon the Lord, so the whole glory belongs to him alone. The letter killeth: the letter of the law is the ministration of death; and if we rest only in the letter of the gospel, we shall not be the better for so doing: but the Holy Spirit gives life spiritual, and life eternal. The Old Testament dispensation was the ministration of death, but the New Testament of life. The law made known sin, and the wrath and curse of God; it showed us a God above us, and a God against us; but the gospel makes known grace, and Emmanuel, God with us. Therein the righteousness of God by faith is revealed; and this shows us that the just shall live by his faith; this makes known the grace and mercy of God through Jesus Christ, for obtaining the forgiveness of sins and eternal life. The gospel so much exceeds the law in glory, that it eclipses the glory of the legal dispensation. But even the New Testament will be a killing letter, if shown as a mere system or form, and without dependence on God the Holy Spirit, to give it a quickening power.

## Verses 12–18

It is the duty of the ministers of the gospel to use great plainness, or clearness, of speech. The Old Testament believers had only cloudy and passing glimpses of that glorious Saviour, and unbelievers looked no further than to the outward institution. But the great precepts of the gospel, believe, love, obey, are truths stated as clearly as possible. And the whole doctrine of Christ crucified, is made as plain as human language can make it. Those who lived under the law, had a veil upon their hearts. This veil is taken away by the doctrines of the Bible about Christ. When any person is converted to God, then the veil of ignorance is taken away. The condition of those who enjoy and believe the gospel is happy, for the heart is set at liberty to run the ways of God's commandments. They have light, and with open face they behold the glory of the Lord. Christians should prize and improve these privileges. We should not rest contented without knowing the transforming power of the gospel, by the working of the Spirit, bringing us to seek to be like the temper and tendency of the glorious gospel of our Lord and Saviour Jesus Christ, and into union with Him. We behold Christ, as in the glass of his word; and as the reflection from a mirror causes the face to shine, the faces of Christians shine also.

