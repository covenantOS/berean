---
title: "2 Corinthians 8 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "8"
description: "In this chapter: The apostle reminds them of charitable contributions for the poor saints. (1–6). Enforces this by their gifts, and by the love and grace of Christ. (7–9). By the willingness they had shown to this good work. (10–15). He recommends Titus to them. (16–24)."
weight: 8
---

# 2 Corinthians 8 

## Chapter Outline

- The apostle reminds them of charitable contributions for the poor saints. (1–6)
- Enforces this by their gifts, and by the love and grace of Christ. (7–9)
- By the willingness they had shown to this good work. (10–15)
- He recommends Titus to them. (16–24)

## Verses 1–6

The grace of God must be owned as the root and fountain of all the good in us, or done by us, at any time. It is great grace and favour from God, if we are made useful to others, and forward to any good work. He commends the charity of the Macedonians. So far from needing that Paul should urge them, they prayed him to receive the gift. Whatever we use or lay out for God, it is only giving him what is his own. All we give for charitable uses, will not be accepted of God, nor turn to our advantage, unless we first give ourselves to the Lord. By ascribing all really good works to the grace of God, we not only give the glory to him whose due it is, but also show men where their strength is. Abundant spiritual joy enlarges men's hearts in the work and labour of love. How different this from the conduct of those who will not join in any good work, unless urged into it!

## Verses 7–9

Faith is the root; and as without faith it is not possible to please God, Heb 11:6, so those who abound in faith, will abound in other graces and good works also; and this will work and show itself by love. Great talkers are not always the best doers; but these Corinthians were diligent to do, as well as to know and talk well. To all these good things the apostle desires them to add this grace also, to abound in charity to the poor. The best arguments for Christian duties, are drawn from the grace and love of Christ. Though he was rich, as being God, equal in power and glory with the Father, yet he not only became man for us, but became poor also. At length he emptied himself, as it were, to ransom their souls by his sacrifice on the cross. From what riches, blessed Lord, to what poverty didst thou descend for our sakes! and to what riches hast thou advanced us through thy poverty! It is our happiness to be wholly at thy disposal.

## Verses 10–15

Good purposes are like buds and blossoms, pleasant to behold, and give hopes of good fruit; but they are lost, and signify nothing without good deeds. Good beginnings are well; but we lose the benefit, unless there is perseverance. When men purpose that which is good, and endeavour, according to their ability, to perform also, God will not reject them for what it is not in their power to do. But this scripture will not justify those who think good meanings are enough, or that good purposes, and the mere profession of a willing mind, are enough to save. Providence gives to some more of the good things of this world, and to some less, that those who have abundance might supply others who are in want. It is the will of God, that by our mutual supplying one another, there should be some sort of equality; not such a levelling as would destroy property, for in such a case there could be no exercise of charity. All should think themselves concerned to relieve those in want. This is shown from the gathering and giving out the manna in the wilderness, Ex 16:18. Those who have most of this world, have no more than food and raiment; and those who have but little of this world, seldom are quite without them.

## Verses 16–24

The apostle commends the brethren sent to collect their charity, that it might be known who they were, and how safely they might be trusted. It is the duty of all Christians to act prudently; to hinder, as far as we can, all unjust suspicions. It is needful, in the first place, to act uprightly in the sight of God, but things honest in the sight of men should also be attended to. A clear character, as well as a pure conscience, is requisite for usefulness. They brought glory to Christ as instruments, and had obtained honour from Christ to be counted faithful, and employed in his service. The good opinion others have of us, should be an argument with us to do well.

