---
title: "2 Corinthians 4 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "4"
description: "In this chapter: The apostles laboured with much diligence, sincerity, and faithfulness. (1–7). Their sufferings for the gospel were great, yet with rich supports. (8–12). Prospects of eternal glory keep believers from fainting under troubles. (13–18)."
weight: 4
---

# 2 Corinthians 4 

## Chapter Outline

- The apostles laboured with much diligence, sincerity, and faithfulness. (1–7)
- Their sufferings for the gospel were great, yet with rich supports. (8–12)
- Prospects of eternal glory keep believers from fainting under troubles. (13–18)

## Verses 1–7

The best of men would faint, if they did not receive mercy from God. And that mercy which has helped us out, and helped us on, hitherto, we may rely upon to help us even to the end. The apostles had no base and wicked designs, covered with fair and specious pretences. They did not try to make their ministry serve a turn. Sincerity or uprightness will keep the favourable opinion of wise and good men. Christ by his gospel makes a glorious discovery to the minds of men. But the design of the devil is, to keep men in ignorance; and when he cannot keep the light of the gospel of Christ out of the world, he spares no pains to keep men from the gospel, or to set them against it. The rejection of the gospel is here traced to the wilful blindness and wickedness of the human heart. Self was not the matter or the end of the apostles' preaching; they preached Christ as Jesus, the Saviour and Deliverer, who saves to the uttermost all that come to God through him. Ministers are servants to the souls of men; they must avoid becoming servants to the humours or the lusts of men. It is pleasant to behold the sun in the firmament; but it is more pleasant and profitable for the gospel to shine in the heart. As light was the beginning of the first creation; so, in the new creation, the light of the Spirit is his first work upon the soul. The treasure of gospel light and grace is put into earthen vessels. The ministers of the gospel are subject to the same passions and weaknesses as other men. God could have sent angels to make known the glorious doctrine of the gospel, or could have sent the most admired sons of men to teach the nations, but he chose humbler, weaker vessels, that his power might be more glorified in upholding them, and in the blessed change wrought by their ministry.

## Verses 8–12

The apostles were great sufferers, yet they met with wonderful support. Believers may be forsaken of their friends, as well as persecuted by enemies; but their God will never leave them nor forsake them. There may be fears within, as well as fightings without; yet we are not destroyed. The apostle speaks of their sufferings as a counterpart of the sufferings of Christ, that people might see the power of Christ's resurrection, and of grace in and from the living Jesus. In comparison with them, other Christians were, even at that time, in prosperous circumstances.

## Verses 13–18

The grace of faith is an effectual remedy against fainting in times of trouble. They knew that Christ was raised, and that his resurrection was an earnest and assurance of theirs. The hope of this resurrection will encourage in a suffering day, and set us above the fear of death. Also, their sufferings were for the advantage of the church, and to God's glory. The sufferings of Christ's ministers, as well as their preaching and conversation, are for the good of the church and the glory of God. The prospect of eternal life and happiness was their support and comfort. What sense was ready to pronounce heavy and long, grievous and tedious, faith perceived to be light and short, and but for a moment. The weight of all temporal afflictions was lightness itself, while the glory to come was a substance, weighty, and lasting beyond description. If the apostle could call his heavy and long-continued trials light, and but for a moment, what must our trifling difficulties be! Faith enables to make this right judgment of things. There are unseen things, as well as things that are seen. And there is this vast difference between them; unseen things are eternal, seen things but temporal, or temporary only. Let us then look off from the things which are seen; let us cease to seek for worldly advantages, or to fear present distresses. Let us give diligence to make our future happiness sure.

