---
title: "2 Corinthians 5 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "5"
description: "In this chapter: The apostle's hope and desire of heavenly glory. (1–8). This excited to diligence. The reasons of his being affected with zeal for the Corinthians. (9–15). The necessity of regeneration, and of reconciliation with God through Christ. (16–21)."
weight: 5
---

# 2 Corinthians 5 

## Chapter Outline

- The apostle's hope and desire of heavenly glory. (1–8)
- This excited to diligence. The reasons of his being affected with zeal for the Corinthians. (9–15)
- The necessity of regeneration, and of reconciliation with God through Christ. (16–21)

## Verses 1–8

The believer not only is well assured by faith that there is another and a happy life after this is ended, but he has good hope, through grace, of heaven as a dwelling-place, a resting-place, a hiding-place. In our Father's house there are many mansions, whose Builder and Maker is God. The happiness of the future state is what God has prepared for those that love him: everlasting habitations, not like the earthly tabernacles, the poor cottages of clay, in which our souls now dwell; that are mouldering and decaying, whose foundations are in the dust. The body of flesh is a heavy burden, the calamities of life are a heavy load. But believers groan, being burdened with a body of sin, and because of the many corruptions remaining and raging within them. Death will strip us of the clothing of flesh, and all the comforts of life, as well as end all our troubles here below. But believing souls shall be clothed with garments of praise, with robes of righteousness and glory. The present graces and comforts of the Spirit are earnests of everlasting grace and comfort. And though God is with us here, by his Spirit, and in his ordinances, yet we are not with him as we hope to be. Faith is for this world, and sight is for the other world. It is our duty, and it will be our interest, to walk by faith, till we live by sight. This shows clearly the happiness to be enjoyed by the souls of believers when absent from the body, and where Jesus makes known his glorious presence. We are related to the body and to the Lord; each claims a part in us. But how much more powerfully the Lord pleads for having the soul of the believer closely united with himself! Thou art one of the souls I have loved and chosen; one of those given to me. What is death, as an object of fear, compared with being absent from the Lord!

## Verses 9–15

The apostle quickens himself and others to acts of duty. Well-grounded hopes of heaven will not encourage sloth and sinful security. Let all consider the judgment to come, which is called, The terror of the Lord. Knowing what terrible vengeance the Lord would execute upon the workers of iniquity, the apostle and his brethren used every argument and persuasion, to lead men to believe in the Lord Jesus, and to act as his disciples. Their zeal and diligence were for the glory of God and the good of the church. Christ's love to us will have a like effect upon us, if duly considered and rightly judged. All were lost and undone, dead and ruined, slaves to sin, having no power to deliver themselves, and must have remained thus miserable for ever, if Christ had not died. We should not make ourselves, but Christ, the end of our living and actions. A Christian's life should be devoted to Christ. Alas, how many show the worthlessness of their professed faith and love, by living to themselves and to the world!

## Verses 16–21

The renewed man acts upon new principles, by new rules, with new ends, and in new company. The believer is created anew; his heart is not merely set right, but a new heart is given him. He is the workmanship of God, created in Christ Jesus unto good works. Though the same as a man, he is changed in his character and conduct. These words must and do mean more than an outward reformation. The man who formerly saw no beauty in the Saviour that he should desire him, now loves him above all things. The heart of the unregenerate is filled with enmity against God, and God is justly offended with him. Yet there may be reconciliation. Our offended God has reconciled us to himself by Jesus Christ. By the inspiration of God, the Scriptures were written, which are the word of reconciliation; showing that peace has been made by the cross, and how we may be interested therein. Though God cannot lose by the quarrel, nor gain by the peace, yet he beseeches sinners to lay aside their enmity, and accept the salvation he offers. Christ knew no sin. He was made Sin; not a sinner, but Sin, a Sin-offering, a Sacrifice for sin. The end and design of all this was, that we might be made the righteousness of God in him, might be justified freely by the grace of God through the redemption which is in Christ Jesus. Can any lose, labour, or suffer too much for Him, who gave his beloved Son to be the Sacrifice for their sins, that they might be made the righteousness of God in him?

