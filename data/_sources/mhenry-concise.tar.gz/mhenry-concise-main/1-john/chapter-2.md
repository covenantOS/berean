---
title: "1 John 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: The apostle directs to the atonement of Christ for help against sinful infirmities. (1, 2). The effects of saving knowledge in producing obedience, and love to the brethren. (3–11). Christians addressed as little children, young men, and fathers. (12–14). All are cautioned against the love of this world, and against errors. (15–23). They are encouraged to stand fast in faith and holiness. (24–29)."
weight: 2
---

# 1 John 2 

## Chapter Outline

- The apostle directs to the atonement of Christ for help against sinful infirmities. (1, 2)
- The effects of saving knowledge in producing obedience, and love to the brethren. (3–11)
- Christians addressed as little children, young men, and fathers. (12–14)
- All are cautioned against the love of this world, and against errors. (15–23)
- They are encouraged to stand fast in faith and holiness. (24–29)

## Verses 1, 2

When have an Advocate with the Father; one who has undertaken, and is fully able, to plead in behalf of every one who applies for pardon and salvation in his name, depending on his pleading for them. He is “Jesus,” the Saviour, and “Christ,” the Messiah, the Anointed. He alone is “the Righteous One,” who received his nature pure from sin, and as our Surety perfectly obeyed the law of God, and so fulfilled all righteousness. All men, in every land, and through successive generations, are invited to come to God through this all-sufficient atonement, and by this new and living way. The gospel, when rightly understood and received, sets the heart against all sin, and stops the allowed practice of it; at the same time it gives blessed relief to the wounded consciences of those who have sinned.

## Verses 3–11

What knowledge of Christ can that be, which sees not that he is most worthy of our entire obedience? And a disobedient life shows there is neither religion nor honesty in the professor. The love of God is perfected in him that keeps his commandments. God's grace in him attains its true mark, and produces its sovereign effect as far as may be in this world, and this is man's regeneration; though never absolutely perfect here. Yet this observing Christ's commands, has holiness and excellency which, if universal, would make the earth resemble heaven itself. The command to love one another had been in force from the beginning of the world; but it might be called a new command as given to Christians. It was new in them, as their situation was new in respect of its motives, rules, and obligations. And those who walk in hatred and enmity to believers, remain in a dark state. Christian love teaches us to value our brother's soul, and to dread every thing hurtful to his purity and peace. Where spiritual darkness dwells, in mind, the judgment, and the conscience will be darkened, and will mistake the way to heavenly life. These things demand serious self-examination; and earnest prayer, that God would show us what we are, and whither we are going.

## Verses 12–14

As Christians have their peculiar states, so they have peculiar duties; but there are precepts and obedience common to all, particularly mutual love, and contempt of the world. The youngest sincere disciple is pardoned: the communion of saints is attended with the forgiveness of sins. Those of the longest standing in Christ's school need further advice and instruction. Even fathers must be written unto, and preached unto; none are too old to learn. But especially young men in Christ Jesus, though they are arrived at strength of spirit and sound sense, and have successfully resisted first trials and temptations, breaking off bad habits and connexions, and entered in at the strait gate of true conversion. The different descriptions of Christians are again addressed. Children in Christ know that God is their Father; it is wisdom. Those advanced believers, who know Him that was from the beginning, before this world was made, may well be led thereby to give up this world. It will be the glory of young persons to be strong in Christ, and his grace. By the word of God they overcome the wicked one.

## Verses 15–17

The things of the world may be desired and possessed for the uses and purposes which God intended, and they are to be used by his grace, and to his glory; but believers must not seek or value them for those purposes to which sin abuses them. The world draws the heart from God; and the more the love of the world prevails, the more the love of God decays. The things of the world are classed according to the three ruling inclinations of depraved nature. 1. The lust of the flesh, of the body: wrong desires of the heart, the appetite of indulging all things that excite and inflame sensual pleasures. 2. The lust of the eyes: the eyes are delighted with riches and rich possessions; this is the lust of covetousness. 3. The pride of life: a vain man craves the grandeur and pomp of a vain-glorious life; this includes thirst after honour and applause. The things of the world quickly fade and die away; desire itself will ere long fail and cease, but holy affection is not like the lust that passes away. The love of God shall never fail. Many vain efforts have been made to evade the force of this passage by limitations, distinctions, or exceptions. Many have tried to show how far we may be carnally-minded, and love the world; but the plain meaning of these verses cannot easily be mistaken. Unless this victory over the world is begun in the heart, a man has no root in himself, but will fall away, or at most remain an unfruitful professor. Yet these vanities are so alluring to the corruption in our hearts, that without constant watching and prayer, we cannot escape the world, or obtain victory over the god and prince of it.

## Verses 18–23

Every man is an antichrist, who denies the Person, or any of the offices of Christ; and in denying the Son, he denies the Father also, and has no part in his favour while he rejects his great salvation. Let this prophecy that seducers would rise in the Christian world, keep us from being seduced. The church knows not well who are its true members, and who are not, but thus true Christians were proved, and rendered more watchful and humble. True Christians are anointed ones; their names expresses this: they are anointed with grace, with gifts and spiritual privileges, by the Holy Spirit of grace. The great and most hurtful lies that the father of lies spreads in the world, usually are falsehoods and errors relating to the person of Christ. The unction from the Holy One, alone can keep us from delusions. While we judge favourably of all who trust in Christ as the Divine Saviour, and obey his word, and seek to live in union with them, let us pity and pray for those who deny the Godhead of Christ, or his atonement, and the new-creating work of the Holy Ghost. Let us protest against such antichristian doctrine, and keep from them as much as we may.

## Verses 24–29

The truth of Christ, abiding in us, is a means to sever from sin, and unites us to the Son of God, Joh 15:3, 4. What value should we put upon gospel truth! Thereby the promise of eternal life is made sure. The promise God makes, is suitable to his own greatness, power, and goodness; it is eternal life. The Spirit of truth will not lie; and he teaches all things in the present dispensation, all things necessary to our knowledge of God in Christ, and their glory in the gospel. The apostle repeats the kind words, “little children;” which denotes his affection. He would persuade by love. Gospel privileges oblige to gospel duties; and those anointed by the Lord Jesus abide with him. The new spiritual nature is from the Lord Christ. He that is constant to the practice of religion in trying times, shows that he is born from above, from the Lord Christ. Then, let us beware of holding the truth in unrighteousness, remembering that those only are born of God, who bear his holy image, and walk in his most righteous ways.

