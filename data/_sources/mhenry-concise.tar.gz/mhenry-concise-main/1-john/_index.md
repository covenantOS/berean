---
title: "1 John | Matthew Henry Concise Commentary"
linkTitle: "1 John"
weight: 62
description: >
  Read commentary notes on 1 John from Matthew Henry's Concise Commentary on the Bible online.
layout: single-section
---

# 1 John

This epistle is a discourse upon the principles of Christianity, in doctrine and practice. The design appears to be, to refute and guard against erroneous and unholy tenets, principles, and practices, especially such as would lower the Godhead of Christ, and the reality and power of his sufferings and death, as an atoning sacrifice; and against the assertion that believers being saved by grace, are not required to obey the commandments. This epistle also stirs up all who profess to know God, to have communion with him, and to believe in him, and that they walk in holiness, not in sin, showing that a mere outward profession is nothing, without the evidence of a holy life and conduct. It also helps forward and excites real Christians to communion with God and the Lord Jesus Christ, to constancy in the true faith, and to purity of life.

{{< cards >}}
{{< card link="./chapter-1" title="Chapter 1" icon="book-open" >}}
{{< card link="./chapter-2" title="Chapter 2" icon="book-open" >}}
{{< card link="./chapter-3" title="Chapter 3" icon="book-open" >}}
{{< card link="./chapter-4" title="Chapter 4" icon="book-open" >}}
{{< card link="./chapter-5" title="Chapter 5" icon="book-open" >}}
{{< /cards >}}
