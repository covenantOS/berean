---
title: "1 John 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: The apostle prefaces his epistle to believers in general, with evident testimonies to Christ, for promoting their happiness and joy. (1–4). The necessity of a life of holiness, in order to communion with God, is shown. (5–10)."
weight: 1
---

# 1 John 1 

## Chapter Outline

- The apostle prefaces his epistle to believers in general, with evident testimonies to Christ, for promoting their happiness and joy. (1–4)
- The necessity of a life of holiness, in order to communion with God, is shown. (5–10)

## Verses 1–4

That essential Good, that uncreated Excellence, which had been from the beginning, from eternity, as equal with the Father, and which at length appeared in human nature for the salvation of sinners, was the great subject concerning which the apostle wrote to his brethren. The apostles had seen Him while they witnessed his wisdom and holiness, his miracles, and love and mercy, during some years, till they saw him crucified for sinners, and afterwards risen from the dead. They touched him, so as to have full proof of his resurrection. This Divine Person, the Word of life, the Word of God, appeared in human nature, that he might be the Author and Giver of eternal life to mankind, through the redemption of his blood, and the influence of his new-creating Spirit. The apostles declared what they had seen and heard, that believers might share their comforts and everlasting advantages. They had free access to God the Father. They had a happy experience of the truth in their souls, and showed its excellence in their lives. This communion of believers with the Father and the Son, is begun and kept up by the influences of the Holy Spirit. The benefits Christ bestows, are not like the scanty possessions of the world, causing jealousies in others; but the joy and happiness of communion with God is all-sufficient, so that any number may partake of it; and all who are warranted to say, that truly their fellowship is with the Father, will desire to lead others to partake of the same blessedness.

## Verses 5–10

A message from the Lord Jesus, the Word of life, the eternal Word, we should all gladly receive. The great God should be represented to this dark world, as pure and perfect light. As this is the nature of God, his doctrines and precepts must be such. And as his perfect happiness cannot be separated from his perfect holiness, so our happiness will be in proportion to our being made holy. To walk in darkness, is to live and act against religion. God holds no heavenly fellowship or intercourse with unholy souls. There is no truth in their profession; their practice shows its folly and falsehood. The eternal Life, the eternal Son, put on flesh and blood, and died to wash us from our sins in his own blood, and procures for us the sacred influences by which sin is to be subdued more and more, till it is quite done away. While the necessity of a holy walk is insisted upon, as the effect and evidence of the knowledge of God in Christ Jesus, the opposite error of self-righteous pride is guarded against with equal care. All who walk near to God, in holiness and righteousness, are sensible that their best days and duties are mixed with sin. God has given testimony to the sinfulness of the world, by providing a sufficient, effectual Sacrifice for sin, needed in all ages; and the sinfulness of believers themselves is shown, by requiring them continually to confess their sins, and to apply by faith to the blood of that Sacrifice. Let us plead guilty before God, be humble, and willing to know the worst of our case. Let us honestly confess all our sins in their full extent, relying wholly on his mercy and truth through the righteousness of Christ, for a free and full forgiveness, and our deliverance from the power and practice of sin.

