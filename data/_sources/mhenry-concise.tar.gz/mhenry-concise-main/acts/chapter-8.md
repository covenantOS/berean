---
title: "Acts 8 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "8"
description: "In this chapter: Saul persecutes the church. (1–4). Philip's success at Samaria. Simon the sorcerer baptized. (5–13). The hypocrisy of Simon detected. (14–25). Philip and the Ethiopian. (26–40)."
weight: 8
---

# Acts 8 

## Chapter Outline

- Saul persecutes the church. (1–4)
- Philip's success at Samaria. Simon the sorcerer baptized. (5–13)
- The hypocrisy of Simon detected. (14–25)
- Philip and the Ethiopian. (26–40)

## Verses 1–4

Though persecution must not drive us from our work, yet it may send us to work elsewhere. Wherever the established believer is driven, he carries the knowledge of the gospel, and makes known the preciousness of Christ in every place. Where a simple desire of doing good influences the heart, it will be found impossible to shut a man out from all opportunities of usefulness.

## Verses 5–13

As far as the gospel prevails, evil spirits are dislodged, particularly unclean spirits. All inclinations to the lusts of the flesh which war against the soul are such. Distempers are here named, the most difficult to be cured by the course of nature, and most expressive of the disease of sin. Pride, ambition, and desire after grandeur have always caused abundance of mischief, both to the world and to the church. The people said of Simon, This man is the great power of God. See how ignorant and thoughtless people mistake. But how strong is the power of Divine grace, by which they were brought to Christ, who is Truth itself! The people not only gave heed to what Philip said, but were fully convinced that it was of God, and not of men, and gave up themselves to be directed thereby. Even bad men, and those whose hearts still go after covetousness, may come before God as his people come, and for a time continue with them. And many wonder at the proofs of Divine truths, who never experience their power. The gospel preached may have a common operation upon a soul, where it never produced inward holiness. All are not savingly converted who profess to believe the gospel.

## Verses 14–25

The Holy Ghost was as yet fallen upon none of these coverts, in the extraordinary powers conveyed by the descent of the Spirit upon the day of Pentecost. We may take encouragement from this example, in praying to God to give the renewing graces of the Holy Ghost to all for whose spiritual welfare we are concerned; for that includes all blessings. No man can give the Holy Spirit by the laying on of his hands; but we should use our best endeavours to instruct those for whom we pray. Simon Magus was ambitious to have the honour of an apostle, but cared not at all to have the spirit and disposition of a Christian. He was more desirous to gain honour to himself, than to do good to others. Peter shows him his crime. He esteemed the wealth of this world, as if it would answer for things relating to the other life, and would purchase the pardon of sin, the gift of the Holy Ghost, and eternal life. This was such a condemning error as could by no means consist with a state of grace. Our hearts are what they are in the sight of God, who cannot be deceived. And if they are not right in his sight, our religion is vain, and will stand us in no stead. A proud and covetous heart cannot be right with God. It is possible for a man to continue under the power of sin, yet to put on a form of godliness. When tempted with money to do evil, see what a perishing thing money is, and scorn it. Think not that Christianity is a trade to live by in this world. There is much wickedness in the thought of the heart, its false notions, and corrupt affections, and wicked projects, which must be repented of, or we are undone. But it shall be forgiven, upon our repentance. The doubt here is of the sincerity of Simon's repentance, not of his pardon, if his repentance was sincere. Grant us, Lord, another sort of faith than that which made Simon wonder only, and did not sanctify his heart. May we abhor all thoughts of making religion serve the purposes of pride or ambition. And keep us from that subtle poison of spiritual pride, which seeks glory to itself even from humility. May we seek only the honour which cometh from God.

## Verses 26–40

Philip was directed to go to a desert. Sometimes God opens a door of opportunity to his ministers in very unlikely places. We should study to do good to those we come into company with by travelling. We should not be so shy of all strangers as some affect to be. As to those of whom we know nothing else, we know this, that they have souls. It is wisdom for men of business to redeem time for holy duties; to fill up every minute with something which will turn to a good account. In reading the word of God, we should often pause, to inquire of whom and of what the sacred writers spake; but especially our thoughts should be employed about the Redeemer. The Ethiopian was convinced by the teaching of the Holy Spirit, of the exact fulfilment of the Scripture, was made to understand the nature of the Messiah's kingdom and salvation, and desired to be numbered among the disciples of Christ. Those who seek the truth, and employ their time in searching the Scriptures, will be sure to reap advantages. The avowal of the Ethiopian must be understood as expressing simple reliance on Christ for salvation, and unreserved devotion to Him. Let us not be satisfied till we get faith, as the Ethiopian did, by diligent study of the Holy Scriptures, and the teaching of the Spirit of God; let us not be satisfied till we get it fixed as a principle in our hearts. As soon as he was baptized, the Spirit of God took Philip from him, so that he saw him no more; but this tended to confirm his faith. When the inquirer after salvation becomes acquainted with Jesus and his gospel, he will go on his way rejoicing, and will fill up his station in society, and discharge his duties, from other motives, and in another manner than heretofore. Though baptized in the name of the Father, Son, and Holy Ghost, with water, it is not enough without the baptism of the Holy Ghost. Lord, grant this to every one of us; then shall we go on our way rejoicing.

