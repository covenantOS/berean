---
title: "Acts 13 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "13"
description: "In this chapter: The mission of Paul and Barnabas. (1–3). Elymas the sorcerer. (4–13). Paul's discourse at Antioch. (14–41). He preaches to the Gentiles, and is persecuted by the Jews. (42–52)."
weight: 13
---

# Acts 13 

## Chapter Outline

- The mission of Paul and Barnabas. (1–3)
- Elymas the sorcerer. (4–13)
- Paul's discourse at Antioch. (14–41)
- He preaches to the Gentiles, and is persecuted by the Jews. (42–52)

## Verses 1–3

What an assemblage was here! In these names we see that the Lord raises up instruments for his work, from various places and stations in life; and zeal for his glory induces men to give up flattering connexions and prospects to promote his cause. It is by the Spirit of Christ that his ministers are made both able and willing for his service, and taken from other cares that would hinder in it. Christ's ministers are to be employed in Christ's work, and, under the Spirit's guidance, to act for the glory of God the Father. They are separated to take pains, and not to take state. A blessing upon Barnabas and Saul in their present undertaking was sought for, and that they might be filled with the Holy Ghost in their work. Whatever means are used, or rules observed, the Holy Ghost alone can fit ministers for their important work, and call them to it.

## Verses 4–13

Satan is in a special manner busy with great men and men in power, to keep them from being religious, for their example will influence many. Saul is here for the first time called Paul, and never after Saul. Saul was his name as he was a Hebrew; Paul was his name as he was a citizen of Rome. Under the direct influence of the Holy Ghost, he gave Elymas his true character, but not in passion. A fulness of deceit and mischief together, make a man indeed a child of the devil. And those who are enemies to the doctrine of Jesus, are enemies to all righteousness; for in it all righteousness is fulfilled. The ways of the Lord Jesus are the only right ways to heaven and happiness. There are many who not only wander from these ways themselves, but set others against these ways. They commonly are so hardened, that they will not cease to do evil. The proconsul was astonished at the force of the doctrine upon his own heart and conscience, and at the power of God by which it was confirmed. The doctrine of Christ astonishes; and the more we know of it, the more reason we shall see to wonder at it. Those who put their hand to the plough and look back, are not fit for the kingdom of God. Those who are not prepared to face opposition, and to endure hardship, are not fitted for the work of the ministry.

## Verses 14–31

When we come together to worship God, we must do it, not only by prayer and praise, but by the reading and hearing of the word of God. The bare reading of the Scriptures in public assemblies is not enough; they should be expounded, and the people exhorted out of them. This is helping people in doing that which is necessary to make the word profitable, to apply it to themselves. Every thing is touched upon in this sermon, which might best prevail with Jews to receive and embrace Christ as the promised Messiah. And every view, however short or faint, of the Lord's dealings with his church, reminds us of his mercy and long-suffering, and of man's ingratitude and perverseness. Paul passes from David to the Son of David, and shows that this Jesus is his promised Seed; a Saviour to do that for them, which the judges of old could not do, to save them from their sins, their worst enemies. When the apostles preached Christ as the Saviour, they were so far from concealing his death, that they always preached Christ crucified. Our complete separation from sin, is represented by our being buried with Christ. But he rose again from the dead, and saw no corruption: this was the great truth to be preached.

## Verses 32–37

The resurrection of Christ was the great proof of his being the Son of God. It was not possible he should be held by death, because he was the Son of God, and therefore had life in himself, which he could not lay down but with a design to take it again. The sure mercies of David are that everlasting life, of which the resurrection was a sure pledge; and the blessings of redemption in Christ are a certain earnest, even in this world. David was a great blessing to the age wherein he lived. We were not born for ourselves, but there are those living around us, to whom we must study to be serviceable. Yet here is the difference; Christ was to serve all generations. May we look to Him who is declared to be the Son of God by his resurrection from the dead, that by faith in him we may walk with God, and serve our generation according to his will; and when death comes, may we fall asleep in him, with a joyful hope of a blessed resurrection.

## Verses 38–41

Let all that hear the gospel of Christ, know these two things: 1. That through this Man, who died and rose again, is preached unto you the forgiveness of sins. Your sins, though many and great, may be forgiven, and they may be so without any injury to God's honour. 2. It is by Christ only that those who believe in him, and none else, are justified from all things; from all the guilt and stain of sin, from which they could not be justified by the law of Moses. The great concern of convinced sinners is, to be justified, to be acquitted from all their guilt, and accepted as righteous in God's sight, for if any is left charged upon the sinner, he is undone. By Jesus Christ we obtain a complete justification; for by him a complete atonement was made for sin. We are justified, not only by him as our Judge but by him as the Lord our Righteousness. What the law could not do for us, in that it was weak, the gospel of Christ does. This is the most needful blessing, bringing in every other. The threatenings are warnings; what we are told will come upon impenitent sinners, is designed to awaken us to beware lest it come upon us. It ruins many, that they despise religion. Those that will not wonder and be saved, shall wonder and perish.

## Verses 42–52

The Jews opposed the doctrine the apostles preached; and when they could find no objection, they blasphemed Christ and his gospel. Commonly those who begin with contradicting, end with blaspheming. But when adversaries of Christ's cause are daring, its advocates should be the bolder. And while many judge themselves unworthy of eternal life, others, who appear less likely, desire to hear more of the glad tidings of salvation. This is according to what was foretold in the Old Testament. What light, what power, what a treasure does this gospel bring with it! How excellent are its truths, its precepts, its promises! Those came to Christ whom the Father drew, and to whom the Spirit made the gospel call effectual, Ro 8:30. As many as were disposed to eternal life, as many as had concern about their eternal state, and aimed to make sure of eternal life, believed in Christ, in whom God has treasured up that life, and who is the only Way to it; and it was the grace of God that wrought it in them. It is good to see honourable women devout; the less they have to do in the world, the more they should do for their own souls, and the souls of others: but it is sad, when, under colour of devotion to God, they try to show hatred to Christ. And the more we relish the comforts and encouragements we meet with in the power of godliness, and the fuller our hearts are of them, the better prepared we are to face difficulties in the profession of godliness.

