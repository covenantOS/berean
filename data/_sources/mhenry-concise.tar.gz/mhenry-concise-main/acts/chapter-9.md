---
title: "Acts 9 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "9"
description: "In this chapter: The conversion of Saul. (1–9). Saul converted preaches Christ. (10–22). Saul is persecuted at Damascus, and goes to Jerusalem. (23–31). Cure of Eneas. (32–35). Dorcas raised to life. (36–43)."
weight: 9
---

# Acts 9 

## Chapter Outline

- The conversion of Saul. (1–9)
- Saul converted preaches Christ. (10–22)
- Saul is persecuted at Damascus, and goes to Jerusalem. (23–31)
- Cure of Eneas. (32–35)
- Dorcas raised to life. (36–43)

## Verses 1–9

So ill informed was Saul, that he thought he ought to do all he could against the name of Christ, and that he did God service thereby; he seemed to breathe in this as in his element. Let us not despair of renewing grace for the conversion of the greatest sinners, nor let such despair of the pardoning mercy of God for the greatest sin. It is a signal token of Divine favour, if God, by the inward working of his grace, or the outward events of his providence, stops us from prosecuting or executing sinful purposes. Saul saw that Just One, ch. 22:14; 26:13. How near to us is the unseen world! It is but for God to draw aside the veil, and objects are presented to the view, compared with which, whatever is most admired on earth is mean and contemptible. Saul submitted without reserve, desirous to know what the Lord Jesus would have him to do. Christ's discoveries of himself to poor souls are humbling; they lay them very low, in mean thoughts of themselves. For three days Saul took no food, and it pleased God to leave him for that time without relief. His sins were now set in order before him; he was in the dark concerning his own spiritual state, and wounded in spirit for sin. When a sinner is brought to a proper sense of his own state and conduct, he will cast himself wholly on the mercy of the Saviour, asking what he would have him to do. God will direct the humbled sinner, and though he does not often bring transgressors to joy and peace in believing, without sorrows and distress of conscience, under which the soul is deeply engaged as to eternal things, yet happy are those who sow in tears, for they shall reap in joy.

## Verses 10–22

A good work was begun in Saul, when he was brought to Christ's feet with those words, Lord, what wilt thou have me to do? And never did Christ leave any who were brought to that. Behold, the proud Pharisee, the unmerciful oppressor, the daring blasphemer, prayeth! And thus it is even now, and with the proud infidel, or the abandoned sinner. What happy tidings are these to all who understand the nature and power of prayer, of such prayer as the humbled sinner presents for the blessings of free salvation! Now he began to pray after another manner than he had done; before, he said his prayers, now, he prayed them. Regenerating grace sets people on praying; you may as well find a living man without breath, as a living Christian without prayer. Yet even eminent disciples, like Ananias, sometimes stagger at the commands of the Lord. But it is the Lord's glory to surpass our scanty expectations, and show that those are vessels of his mercy whom we are apt to consider as objects of his vengeance. The teaching of the Holy Spirit takes away the scales of ignorance and pride from the understanding; then the sinner becomes a new creature, and endeavours to recommend the anointed Saviour, the Son of God, to his former companions.

## Verses 23–31

When we enter into the way of God, we must look for trials; but the Lord knows how to deliver the godly, and will, with the temptation, also make a way to escape. Though Saul's conversion was and is a proof of the truth of Christianity, yet it could not, of itself, convert one soul at enmity with the truth; for nothing can produce true faith, but that power which new-creates the heart. Believers are apt to be too suspicious of those against whom they have prejudices. The world is full of deceit, and it is necessary to be cautious, but we must exercise charity, 1Co 13:5. The Lord will clear up the characters of true believers; and he will bring them to his people, and often gives them opportunities of bearing testimony to his truth, before those who once witnessed their hatred to it. Christ now appeared to Saul, and ordered him to go quickly out of Jerusalem, for he must be sent to the Gentiles: see ch. 22:21. Christ's witnesses cannot be slain till they have finished their testimony. The persecutions were stayed. The professors of the gospel walked uprightly, and enjoyed much comfort from the Holy Ghost, in the hope and peace of the gospel, and others were won over to them. They lived upon the comfort of the Holy Ghost, not only in the days of trouble and affliction, but in days of rest and prosperity. Those are most likely to walk cheerfully, who walk circumspectly.

## Verses 32–35

Christians are saints, or holy people; not only the eminent ones, as Saint Peter and Saint Paul, but every sincere professor of the faith of Christ. Christ chose patients whose diseases were incurable in the course of nature, to show how desperate was the case of fallen mankind. When we were wholly without strength, as this poor man, he sent his word to heal us. Peter does not pretend to heal by any power of his own, but directs Eneas to look up to Christ for help. Let none say, that because it is Christ, who, by the power of his grace, works all our works in us, therefore we have no work, no duty to do; for though Jesus Christ makes thee whole, yet thou must arise, and use the power he gives thee.

## Verses 36–43

Many are full of good words, who are empty and barren in good works; but Tabitha was a great doer, no great talker. Christians who have not property to give in charity, may yet be able to do acts of charity, working with their hands, or walking with their feet, for the good of others. Those are certainly best praised whose own works praise them, whether the words of others do so or not. But such are ungrateful indeed, who have kindness shown them, and will not acknowledge it, by showing the kindness that is done them. While we live upon the fulness of Christ for our whole salvation, we should desire to be full of good works, for the honour of his name, and for the benefit of his saints. Such characters as Dorcas are useful where they dwell, as showing the excellency of the word of truth by their lives. How mean then the cares of the numerous females who seek no distinction but outward decoration, and who waste their lives in the trifling pursuits of dress and vanity! Power went along with the word, and Dorcas came to life. Thus in the raising of dead souls to spiritual life, the first sign of life is the opening of the eyes of the mind. Here we see that the Lord can make up every loss; that he overrules every event for the good of those who trust in him, and for the glory of his name.

