---
title: "Acts 22 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "22"
description: "In this chapter: Paul's account of his conversion. (1–11). Paul directed to preach to the Gentiles. (12–21). The rage of the Jews Paul pleads that he is a Roman citizen. (22–30)."
weight: 22
---

# Acts 22 

## Chapter Outline

- Paul's account of his conversion. (1–11)
- Paul directed to preach to the Gentiles. (12–21)
- The rage of the Jews Paul pleads that he is a Roman citizen. (22–30)

## Verses 1–11

The apostle addressed the enraged multitude, in the customary style of respect and good-will. Paul relates the history of his early life very particularly; he notices that his conversion was wholly the act of God. Condemned sinners are struck blind by the power of darkness, and it is a lasting blindness, like that of the unbelieving Jews. Convinced sinners are struck blind as Paul was, not by darkness, but by light. They are for a time brought to be at a loss within themselves, but it is in order to their being enlightened. A simple relation of the Lord's dealings with us, in bringing us, from opposing, to profess and promote his gospel, when delivered in a right spirit and manner, will sometimes make more impression that laboured speeches, even though it amounts not to the full proof of the truth, such as was shown in the change wrought in the apostle.

## Verses 12–21

The apostle goes on to relate how he was confirmed in the change he had made. The Lord having chosen the sinner, that he should know his will, he is humbled, enlightened, and brought to the knowledge of Christ and his blessed gospel. Christ is here called that Just One; for he is Jesus Christ the righteous. Those whom God has chosen to know his will, must look to Jesus, for by him God has made known his good-will to us. The great gospel privilege, sealed to us by baptism, is the pardon of sins. Be baptized, and wash away thy sins; that is, receive the comfort of the pardon of thy sins in and through Jesus Christ, and lay hold on his righteousness for that purpose; and receive power against sin, for the mortifying of thy corruptions. Be baptized, and rest not in the sign, but make sure of the thing signified, the putting away of the filth of sin. The great gospel duty, to which by our baptism we are bound, is, to seek for the pardon of our sins in Christ's name, and in dependence on him and his righteousness. God appoints his labourers their day and their place, and it is fit they should follow his appointment, though it may cross their own will. Providence contrives better for us than we do for ourselves; we must refer ourselves to God's guidance. If Christ send any one, his Spirit shall go along with him, and give him to see the fruit of his labours. But nothing can reconcile man's heart to the gospel, except the special grace of God.

## Verses 22–30

The Jews listened to Paul's account of his conversion, but the mention of his being sent to the Gentiles, was so contrary to all their national prejudices, that they would hear no more. Their frantic conduct astonished the Roman officer, who supposed that Paul must have committed some great crime. Paul pleaded his privilege as a Roman citizen, by which he was exempted from all trials and punishments which might force him to confess himself guilty. The manner of his speaking plainly shows what holy security and serenity of mind he enjoyed. As Paul was a Jew, in low circumstances, the Roman officer questioned how he obtained so valuable a distinction; but the apostle told him he was free born. Let us value that freedom to which all the children of God are born; which no sum of money, however large, can purchase for those who remain unregenerate. This at once put a stop to his trouble. Thus many are kept from evil practices by the fear of man, who would not be held back from them by the fear of God. The apostle asks, simply, Is it lawful? He knew that the God whom he served would support him under all sufferings for his name's sake. But if it were not lawful, the apostle's religion directed him, if possible, to avoid it. He never shrunk from a cross which his Divine Master laid upon his onward road; and he never stept aside out of that road to take one up.

