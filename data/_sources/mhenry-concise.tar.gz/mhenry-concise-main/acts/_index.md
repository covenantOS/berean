---
title: "Acts | Matthew Henry Concise Commentary"
linkTitle: "Acts"
weight: 44
description: >
  Read commentary notes on Acts from Matthew Henry's Concise Commentary on the Bible online.
layout: single-section
---

# Acts

This book unites the Gospels to the Epistles. It contains many particulars concerning the apostles Peter and Paul, and of the Christian church from the ascension of our Saviour to the arrival of St. Paul at Rome, a space of about thirty years. St. Luke was the writer of this book; he was present at many of the events he relates, and attended Paul to Rome. But the narrative does not afford a complete history of the church during the time to which it refers, nor even of St. Paul's life. The object of the book has been considered to be, 1. To relate in what manner the gifts of the Holy Spirit were communicated on the day of Pentecost, and the miracles performed by the apostles, to confirm the truth of Christianity, as showing that Christ's declarations were really fulfilled. 2. To prove the claim of the Gentiles to be admitted into the church of Christ. This is shown by much of the contents of the book. A large portion of the Acts is occupied by the discourses or sermons of various persons, the language and manner of which differ, and all of which will be found according to the persons by whom they were delivered, and the occasions on which they were spoken. It seems that most of these discourses are only the substance of what was actually delivered. They relate nevertheless fully to Jesus as the Christ, the anointed Messiah.

{{< cards >}}
{{< card link="./chapter-1" title="Chapter 1" icon="book-open" >}}
{{< card link="./chapter-2" title="Chapter 2" icon="book-open" >}}
{{< card link="./chapter-3" title="Chapter 3" icon="book-open" >}}
{{< card link="./chapter-4" title="Chapter 4" icon="book-open" >}}
{{< card link="./chapter-5" title="Chapter 5" icon="book-open" >}}
{{< card link="./chapter-6" title="Chapter 6" icon="book-open" >}}
{{< card link="./chapter-7" title="Chapter 7" icon="book-open" >}}
{{< card link="./chapter-8" title="Chapter 8" icon="book-open" >}}
{{< card link="./chapter-9" title="Chapter 9" icon="book-open" >}}
{{< card link="./chapter-10" title="Chapter 10" icon="book-open" >}}
{{< card link="./chapter-11" title="Chapter 11" icon="book-open" >}}
{{< card link="./chapter-12" title="Chapter 12" icon="book-open" >}}
{{< card link="./chapter-13" title="Chapter 13" icon="book-open" >}}
{{< card link="./chapter-14" title="Chapter 14" icon="book-open" >}}
{{< card link="./chapter-15" title="Chapter 15" icon="book-open" >}}
{{< card link="./chapter-16" title="Chapter 16" icon="book-open" >}}
{{< card link="./chapter-17" title="Chapter 17" icon="book-open" >}}
{{< card link="./chapter-18" title="Chapter 18" icon="book-open" >}}
{{< card link="./chapter-19" title="Chapter 19" icon="book-open" >}}
{{< card link="./chapter-20" title="Chapter 20" icon="book-open" >}}
{{< card link="./chapter-21" title="Chapter 21" icon="book-open" >}}
{{< card link="./chapter-22" title="Chapter 22" icon="book-open" >}}
{{< card link="./chapter-23" title="Chapter 23" icon="book-open" >}}
{{< card link="./chapter-24" title="Chapter 24" icon="book-open" >}}
{{< card link="./chapter-25" title="Chapter 25" icon="book-open" >}}
{{< card link="./chapter-26" title="Chapter 26" icon="book-open" >}}
{{< card link="./chapter-27" title="Chapter 27" icon="book-open" >}}
{{< card link="./chapter-28" title="Chapter 28" icon="book-open" >}}
{{< /cards >}}
