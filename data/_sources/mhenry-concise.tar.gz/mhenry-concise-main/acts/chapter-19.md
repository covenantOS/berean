---
title: "Acts 19 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "19"
description: "In this chapter: Paul instructs the disciples of John at Ephesus. (1–7). He teaches there. (8–12). The Jewish exorcists disgraced. Some Ephesians burn their evil books. (13–20). The tumult at Ephesus. (21–31). The tumult appeased. (32–41)."
weight: 19
---

# Acts 19 

## Chapter Outline

- Paul instructs the disciples of John at Ephesus. (1–7)
- He teaches there. (8–12)
- The Jewish exorcists disgraced. Some Ephesians burn their evil books. (13–20)
- The tumult at Ephesus. (21–31)
- The tumult appeased. (32–41)

## Verses 1–7

Paul, at Ephesus, found some religious persons, who looked to Jesus as the Messiah. They had not been led to expect the miraculous powers of the Holy Ghost, nor were they informed that the gospel was especially the ministration of the Spirit. But they spake as ready to welcome the notice of it. Paul shows them that John never design that those he baptized should rest there, but told them that they should believe on Him who should come after him, that is, on Christ Jesus. They thankfully accepted the discovery, and were baptized in the name of the Lord Jesus. The Holy Ghost came upon them in a surprising, overpowering manner; they spake with tongues, and prophesied, as the apostles and the first Gentile coverts did. Though we do not now expect miraculous powers, yet all who profess to be disciples of Christ, should be called on to examine whether they have received the seal of the Holy Ghost, in his sanctifying influences, to the sincerity of their faith. Many seem not to have heard that there is a Holy Ghost, and many deem all that is spoken concerning his graces and comforts, to be delusion. Of such it may properly be inquired, “Unto what, then, were ye baptized?” for they evidently know not the meaning of that outward sign on which they place great dependence.

## Verses 8–12

When arguments and persuasions only harden men in unbelief and blasphemy, we must separate ourselves and others from such unholy company. God was pleased to confirm the teaching of these holy men of old, that if their hearers believed them not, they might believe the works.

## Verses 13–20

It was common, especially among the Jews, for persons to profess or to try to cast out evil spirits. If we resist the devil by faith in Christ, he will flee from us; but if we think to resist him by the using of Christ's name, or his works, as a spell or charm, Satan will prevail against us. Where there is true sorrow for sin, there will be free confession of sin to God in every prayer and to man whom we have offended, when the case requires it. Surely if the word of God prevailed among us, many lewd, infidel, and wicked books would be burned by their possessors. Will not these Ephesian converts rise up in judgement against professors, who traffic in such works for the sake of gain, or allow themselves to possess them? If we desire to be in earnest in the great work of salvation, every pursuit and enjoyment must be given up which hinders the effect of the gospel upon the mind, or loosens its hold upon the heart.

## Verses 21–31

Persons who came from afar to pay their devotions at the temple of Ephesus, bought little silver shrines, or models of the temple, to carry home with them. See how craftsmen make advantage to themselves of people's superstition, and serve their worldly ends by it. Men are jealous for that by which they get their wealth; and many set themselves against the gospel of Christ, because it calls men from all unlawful crafts, however much wealth is to be gotten by them. There are persons who will stickle for what is most grossly absurd, unreasonable, and false; as this, that those are gods which are made with hands, if it has but worldly interest on its side. The whole city was full of confusion, the common and natural effect of zeal for false religion. Zeal for the honour of Christ, and love to the brethren, encourage zealous believers to venture into danger. Friends will often be raised up among those who are strangers to true religion, but have observed the honest and consistent behaviour of Christians.

## Verses 32–41

The Jews came forward in this tumult. Those who are thus careful to distinguish themselves from the servants of Christ now, and are afraid of being taken for them, shall have their doom accordingly in the great day. One, having authority, at length stilled the noise. It is a very good rule at all times, both in private and public affairs, not to be hasty and rash in our motions, but to take time to consider; and always to keep our passions under check. We ought to be quiet, and to do nothing rashly; to do nothing in haste, of which we may repent at leisure. The regular methods of the law ought always to stop popular tumults, and in well-governed nations will do so. Most people stand in awe of men's judgments more than of the judgement of God. How well it were if we would thus quiet our disorderly appetites and passions, by considering the account we must shortly give to the Judge of heaven and earth! And see how the overruling providence of God keeps the public peace, by an unaccountable power over the spirits of men. Thus the world is kept in some order, and men are held back from devouring each other. We can scarcely look around but we see men act like Demetrius and the workmen. It is as safe to contend with wild beasts as with men enraged by party zeal and disappointed covetousness, who think that all arguments are answered, when they have shown that they grow rich by the practices which are opposed. Whatever side in religious disputes, or whatever name this spirit assumes, it is worldly, and should be discountenanced by all who regard truth and piety. And let us not be dismayed; the Lord on high is mightier than the noise of many waters; he can still the rage of the people.

