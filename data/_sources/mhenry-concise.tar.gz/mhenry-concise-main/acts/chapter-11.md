---
title: "Acts 11 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "11"
description: "In this chapter: Peter's defence. (1–18). The success of the gospel at Antioch. (19–24). The disciples named Christians, Relief sent to Judea. (25–30)."
weight: 11
---

# Acts 11 

## Chapter Outline

- Peter's defence. (1–18)
- The success of the gospel at Antioch. (19–24)
- The disciples named Christians, Relief sent to Judea. (25–30)

## Verses 1–18

The imperfect state of human nature strongly appears, when godly persons are displeased even to hear that the word of God has been received, because their own system has not been attended to. And we are too apt to despair of doing good to those who yet, when tried, prove very teachable. It is the bane and damage of the church, to shut out those from it, and from the benefit of the means of grace, who are not in every thing as we are. Peter stated the whole affair. We should at all times bear with the infirmities of our brethren; and instead of taking offence, or answering with warmth, we should explain our motives, and show the nature of our proceedings. That preaching is certainly right, with which the Holy Ghost is given. While men are very zealous for their own regulations, they should take care that they do not withstand God; and those who love the Lord will glorify him, when made sure that he has given repentance to life to any fellow-sinners. Repentance is God's gift; not only his free grace accepts it, but his mighty grace works it in us, grace takes away the heart of stone, and gives us a heart of flesh. The sacrifice of God is a broken spirit.

## Verses 19–24

The first preachers of the gospel at Antioch, were dispersed from Jerusalem by persecution; thus what was meant to hurt the church, was made to work for its good. The wrath of man is made to praise God. What should the ministers of Christ preach, but Christ? Christ, and him crucified? Christ, and him glorified? And their preaching was accompanied with the Divine power. The hand of the Lord was with them, to bring that home to the hearts and consciences of men, which they could but speak to the outward ear. They believed; they were convinced of the truth of the gospel. They turned from a careless, carnal way of living, to live a holy, heavenly, spiritual life. They turned from worshipping God in show and ceremony, to worship him in the Spirit and in truth. They turned to the Lord Jesus, and he became all in all with them. This was the work of conversion wrought upon them, and it must be wrought upon every one of us. It was the fruit of their faith; all who sincerely believe, will turn to the Lord, When the Lord Jesus is preached in simplicity, and according to the Scriptures, he will give success; and when sinners are thus brought to the Lord, really good men, who are full of faith and of the Holy Ghost, will admire and rejoice in the grace of God bestowed on them. Barnabas was full of faith; full of the grace of faith, and full of the fruits of the faith that works by love.

## Verses 25–30

Hitherto the followers of Christ were called disciples, that is, learners, scholars; but from that time they were called Christians. The proper meaning of this name is, a follower of Christ; it denotes one who, from serious thought, embraces the religion of Christ, believes his promises, and makes it his chief care to shape his life by Christ's precepts and example. Hence it is plain that multitudes take the name of Christian to whom it does not rightly belong. But the name without the reality will only add to our guilt. While the bare profession will bestow neither profit nor delight, the possession of it will give both the promise of the life that now is, and of that which is to come. Grant, Lord, that Christians may forget other names and distinctions, and love one another as the followers of Christ ought to do. True Christians will feel for their brethren under afflictions. Thus will fruit be brought forth to the praise and glory of God. If all mankind were true Christians, how cheerfully would they help one another! The whole earth would be like one large family, every member of which would strive to be dutiful and kind.

