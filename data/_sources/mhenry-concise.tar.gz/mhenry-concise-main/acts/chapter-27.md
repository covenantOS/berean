---
title: "Acts 27 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "27"
description: "In this chapter: Paul's voyage towards Rome. (1–11). Paul and his companions endangered by a tempest. (12–20). He receives a Divine assurance of safety. (21–29). Paul encourages those with him. (30–38). They are shipwrecked. (39–44)."
weight: 27
---

# Acts 27 

## Chapter Outline

- Paul's voyage towards Rome. (1–11)
- Paul and his companions endangered by a tempest. (12–20)
- He receives a Divine assurance of safety. (21–29)
- Paul encourages those with him. (30–38)
- They are shipwrecked. (39–44)

## Verses 1–11

It was determined by the counsel of God, before it was determined by the counsel of Festus, that Paul should go to Rome; for God had work for him to do there. The course they steered, and the places they touched at, are here set down. And God here encourages those who suffer for him, to trust in him; for he can put it into the hearts of those to befriend them, from whom they least expect it. Sailors must make the best of the wind: and so must we all in our passage over the ocean of this world. When the winds are contrary, yet we must be getting forward as well as we can. Many who are not driven backward by cross providences, do not get forward by favourable providences. And many real Christians complain as to the concerns of their souls, that they have much ado to keep their ground. Every fair haven is not a safe haven. Many show respect to good ministers, who will not take their advice. But the event will convince sinners of the vanity of their hopes, and the folly of their conduct.

## Verses 12–20

Those who launch forth on the ocean of this world, with a fair gale, know not what storms they may meet with; and therefore must not easily take it for granted that they have obtained their purpose. Let us never expect to be quite safe till we enter heaven. They saw neither sun nor stars for many days. Thus melancholy sometimes is the condition of the people of God as to their spiritual matters; they walk in darkness, and have no light. See what the wealth of this world is: though coveted as a blessing, the time may come when it will be a burden; not only too heavy to be carried safely, but heavy enough to sink him that has it. The children of this world can be prodigal of their goods for the saving their lives, yet are sparing of them in works of piety and charity, and in suffering for Christ. Any man will rather make shipwreck of his goods than of his life; but many rather make shipwreck of faith and a good conscience, than of their goods. The means the sailors used did not succeed; but when sinners give up all hope of saving themselves, they are prepared to understand God's word, and to trust in his mercy through Jesus Christ.

## Verses 21–29

They did not hearken to the apostle when he warned them of their danger; yet if they acknowledge their folly, and repent of it, he will speak comfort and relief to them when in danger. Most people bring themselves into trouble, because they do not know when they are well off; they come to harm and loss by aiming to mend their condition, often against advice. Observe the solemn profession Paul made of relation to God. No storms or tempests can hinder God's favour to his people, for he is a Help always at hand. It is a comfort to the faithful servants of God when in difficulties, that as long as the Lord has any work for them to do, their lives shall be prolonged. If Paul had thrust himself needlessly into bad company, he might justly have been cast away with them; but God calling him into it, they are preserved with him. They are given thee; there is no greater satisfaction to a good man than to know he is a public blessing. He comforts them with the same comforts wherewith he himself was comforted. God is ever faithful, therefore let all who have an interest in his promises be ever cheerful. As, with God, saying and doing are not two things, believing and enjoying should not be so with us. Hope is an anchor of the soul, sure and stedfast, entering into that within the veil. Let those who are in spiritual darkness hold fast by that, and think not of putting to sea again, but abide by Christ, and wait till the day break, and the shadows flee away.

## Verses 30–38

God, who appointed the end, that they should be saved, appointed the means, that they should be saved by the help of these shipmen. Duty is ours, events are God's; we do not trust God, but tempt him, when we say we put ourselves under his protection, if we do not use proper means, such as are within our power, for our safety. But how selfish are men in general, often even ready to seek their own safety by the destruction of others! Happy those who have such a one as Paul in their company, who not only had intercourse with Heaven, but was of an enlivening spirit to those about him. The sorrow of the world works death, while joy in God is life and peace in the greatest distresses and dangers. The comfort of God's promises can only be ours by believing dependence on him, to fulfil his word to us; and the salvation he reveals must be waited for in use of the means he appoints. If God has chosen us to salvation, he has also appointed that we shall obtain it by repentance, faith, prayer, and persevering obedience; it is fatal presumption to expect it in any other way. It is an encouragement to people to commit themselves to Christ as their Saviour, when those who invite them, clearly show that they do so themselves.

## Verses 39–44

The ship that had weathered the storm in the open sea, where it had room, is dashed to pieces when it sticks fast. Thus, if the heart fixes in the world in affection, and cleaving to it, it is lost. Satan's temptations beat against it, and it is gone; but as long as it keeps above the world, though tossed with cares and tumults, there is hope for it. They had the shore in view, yet suffered shipwreck in the harbour; thus we are taught never to be secure. Though there is great difficulty in the way of the promised salvation, it shall, without fail, be brought to pass. It will come to pass that whatever the trials and dangers may be, in due time all believers will get safely to heaven. Lord Jesus, thou hast assured us that none of thine shall perish. Thou wilt bring them all safe to the heavenly shore. And what a pleasing landing will that be! Thou wilt present them to thy Father, and give thy Holy Spirit full possession of them for ever.

