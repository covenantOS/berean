---
title: "Acts 24 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "24"
description: "In this chapter: The speech of Tertullus against Paul. (1–9). Paul's defence before Felix. (10–21). Felix trembles at the reasoning of Paul. (22–27)."
weight: 24
---

# Acts 24 

## Chapter Outline

- The speech of Tertullus against Paul. (1–9)
- Paul's defence before Felix. (10–21)
- Felix trembles at the reasoning of Paul. (22–27)

## Verses 1–9

See here the unhappiness of great men, and a great unhappiness it is, to have their services praised beyond measure, and never to be faithfully told of their faults; hereby they are hardened and encouraged in evil, like Felix. God's prophets were charged with being troublers of the land, and our Lord Jesus Christ, that he perverted the nation; the very same charges were brought against Paul. The selfish and evil passions of men urge them forward, and the graces and power of speech, too often have been used to mislead and prejudice men against the truth. How different will the characters of Paul and Felix appear at the day of judgement, from what they are represented in the speech of Tertullus! Let not Christians value the applause, or be troubled at the revilings of ungodly men, who represent the vilest of the human race almost as gods, and the excellent of the earth as pestilences and movers of sedition.

## Verses 10–21

Paul gives a just account of himself, which clears him from crime, and likewise shows the true reason of the violence against him. Let us never be driven from any good way by its having an ill name. It is very comfortable, in worshipping God, to look to him as the God of our fathers, and to set up no other rule of faith or practice but the Scriptures. This shows there will be a resurrection to a final judgment. Prophets and their doctrines were to be tried by their fruits. Paul's aim was to have a conscience void of offence. His care and endeavour was to abstain from many things, and to abound in the exercises of religion at all times; both towards God. and towards man. If blamed for being more earnest in the things of God than our neighbours, what is our reply? Do we shrink from the accusation? How many in the world would rather be accused of any weakness, nay, even of wickedness, than of an earnest, fervent feeling of love to the Lord Jesus Christ, and of devotedness to his service! Can such think that He will confess them when he comes in his glory, and before the angels of God? If there is any sight pleasing to the God of our salvation, and a sight at which the angels rejoice, it is, to behold a devoted follower of the Lord, here upon earth, acknowledging that he is guilty, if it be a crime, of loving the Lord who died for him, with all his heart, and soul, and mind, and strength. And that he will not in silence see God's word despised, or hear his name profaned; he will rather risk the ridicule and the hatred of the world, than one frown from that gracious Being whose love is better than life.

## Verses 22–27

The apostle reasoned concerning the nature and obligations of righteousness, temperance, and of a judgment to come; thus showing the oppressive judge and his profligate mistress, their need of repentance, forgiveness, and of the grace of the gospel. Justice respects our conduct in life, particularly in reference to others; temperance, the state and government of our souls, in reference to God. He who does not exercise himself in these, has neither the form nor the power of godliness, and must be overwhelmed with the Divine wrath in the day of God's appearing. A prospect of the judgment to come, is enough to make the stoutest heart to tremble. Felix trembled, but that was all. Many are startled by the word of God, who are not changed by it. Many fear the consequences of sin, yet continue in the love and practice of sin. In the affairs of our souls, delays are dangerous. Felix put off this matter to a more convenient season, but we do not find that the more convenient season ever came. Behold now is the accepted time; hear the voice of the Lord to-day. He was in haste to turn from hearing the truth. Was any business more urgent than for him to reform his conduct, or more important than the salvation of his soul! Sinners often start up like a man roused from his sleep by a loud noise, but soon sink again into their usual drowsiness. Be not deceived by occasional appearances of religion in ourselves or in others. Above all, let us not trifle with the word of God. Do we expect that as we advance in life our hearts will grow softer, or that the influence of the world will decline? Are we not at this moment in danger of being lost for ever? Now is the day of salvation; tomorrow may be too late.

