---
title: "Acts 10 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "10"
description: "In this chapter: Cornelius directed to send for Peter. (1–8). Peter's vision. (9–18). He goes to Cornelius. (19–33). His discourse to Cornelius. (34–43). The gifts of the Holy Spirit poured out. (44–48)."
weight: 10
---

# Acts 10 

## Chapter Outline

- Cornelius directed to send for Peter. (1–8)
- Peter's vision. (9–18)
- He goes to Cornelius. (19–33)
- His discourse to Cornelius. (34–43)
- The gifts of the Holy Spirit poured out. (44–48)

## Verses 1–8

Hitherto none had been baptized into the Christian church but Jews, Samaritans, and those converts who had been circumcised and observed the ceremonial law; but now the Gentiles were to be called to partake all the privileges of God's people, without first becoming Jews. Pure and undefiled religion is sometimes found where we least expect it. Wherever the fear of God rules in the heart, it will appear both in works of charity and of piety, neither will excuse from the other. Doubtless Cornelius had true faith in God's word, as far as he understood it, though not as yet clear faith in Christ. This was the work of the Spirit of God, through the mediation of Jesus, even before Cornelius knew him, as is the case with us all when we, who before were dead in sin, are made alive. Through Christ also his prayers and alms were accepted, which otherwise would have been rejected. Without dispute or delay Cornelius was obedient to the heavenly vision. In the affairs of our souls, let us not lose time.

## Verses 9–18

The prejudices of Peter against the Gentiles, would have prevented his going to Cornelius, unless the Lord had prepared him for this service. To tell a Jew that God had directed those animals to be reckoned clean which were hitherto deemed unclean, was in effect saying, that the law of Moses was done away. Peter was soon made to know the meaning of it. God knows what services are before us, and how to prepare us; and we know the meaning of what he has taught us, when we find what occasion we have to make use of it.

## Verses 19–33

When we see our call clear to any service, we should not be perplexed with doubts and scruples arising from prejudices or former ideas. Cornelius had called together his friends, to partake with him of the heavenly wisdom he expected from Peter. We should not covet to eat our spiritual morsels alone. It ought to be both given and taken as kindness and respect to our kindred and friends, to invite them to join us in religious exercises. Cornelius declared the direction God gave him to send for Peter. We are right in our aims in attending a gospel ministry, when we do it with regard to the Divine appointment requiring us to make use of that ordinance. How seldom ministers are called to speak to such companies, however small, in which it may be said that they are all present in the sight of God, to hear all things that are commanded of God! But these were ready to hear what Peter was commanded of God to say.

## Verses 34–43

Acceptance cannot be obtained on any other ground than that of the covenant of mercy, through the atonement of Christ; but wherever true religion is found, God will accept it without regarding names or sects. The fear of God and works of righteousness are the substance of true religion, the effects of special grace. Though these are not the cause of a man's acceptance, yet they show it; and whatever may be wanting in knowledge or faith, will in due time be given by Him who has begun it. They knew in general the word, that is, the gospel, which God sent to the children of Israel. The purport of this word was, that God by it published the good tidings of peace by Jesus Christ. They knew the several matters of fact relating to the gospel. They knew the baptism of repentance which John preached. Let them know that this Jesus Christ, by whom peace is made between God and man, is Lord of all; not only as over all, God blessed for evermore, but as Mediator. All power, both in heaven and in earth, is put into his hand, and all judgment committed to him. God will go with those whom he anoints; he will be with those to whom he has given his Spirit. Peter then declares Christ's resurrection from the dead, and the proofs of it. Faith has reference to a testimony, and the Christian faith is built upon the foundation of the apostles and prophets, on the testimony given by them. See what must be believed concerning him. That we are all accountable to Christ as our Judge; so every one must seek his favour, and to have him as our Friend. And if we believe in him, we shall all be justified by him as our Righteousness. The remission of sins lays a foundation for all other favours and blessings, by taking that out of the way which hinders the bestowing of them. If sin be pardoned, all is well, and shall end well for ever.

## Verses 44–48

The Holy Ghost fell upon others after they were baptized, to confirm them in the faith; but upon these Gentiles before they were baptized, to show that God does not confine himself to outward signs. The Holy Ghost fell upon those who were neither circumcised nor baptized; it is the Spirit that quickeneth, the flesh profiteth nothing. They magnified God, and spake of Christ and the benefits of redemption. Whatever gift we are endued with, we ought to honour God with it. The believing Jews who were present, were astonished that the gift of the Holy Ghost was poured out upon the Gentiles also. By mistaken notions of things, we make difficult for ourselves as to the methods of Divine providence and grace. As they were undeniably baptized with the Holy Ghost, Peter concluded they were not to be refused the baptism of water, and the ordinance was administered. The argument is conclusive; can we deny the sign to those who have received the things signified? Those who have some acquaintance with Christ, cannot but desire more. Even those who have received the Holy Ghost, must see their need of daily learning more of the truth.

