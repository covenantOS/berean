---
title: "Acts 17 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "17"
description: "In this chapter: Paul at Thessalonica. (1–9). The noble conduct of the Bereans. (10–15). Paul at Athens. (16–21). He preaches there. (22–31). The scornful conduct of the Athenians. (32–34)."
weight: 17
---

# Acts 17 

## Chapter Outline

- Paul at Thessalonica. (1–9)
- The noble conduct of the Bereans. (10–15)
- Paul at Athens. (16–21)
- He preaches there. (22–31)
- The scornful conduct of the Athenians. (32–34)

## Verses 1–9

The drift and scope of Paul's preaching and arguing, was to prove that Jesus is the Christ. He must needs suffer for us, because he could not otherwise purchase our redemption for us; and he must needs have risen again, because he could not otherwise apply the redemption to us. We are to preach concerning Jesus that he is Christ; therefore we may hope to be saved by him, and are bound to be ruled by him. The unbelieving Jews were angry, because the apostles preached to the Gentiles, that they might be saved. How strange it is, that men should grudge others the privileges they will not themselves accept! Neither rulers nor people need be troubled at the increase of real Christians, even though turbulent spirits should make religion the pretext for evil designs. Of such let us beware, from such let us withdraw, that we may show a desire to act aright in society, while we claim our right to worship God according to our consciences.

## Verses 10–15

The Jews in Berea applied seriously to the study of the word preached unto them. They not only heard Paul preach on the sabbath, but daily searched the Scriptures, and compared what they read with the facts related to them. The doctrine of Christ does not fear inquiry; advocates for his cause desire no more than that people will fully and fairly examine whether things are so or not. Those are truly noble, and likely to be more and more so, who make the Scriptures their rule, and consult them accordingly. May all the hearers of the gospel become like those of Berea, receiving the word with readiness of mind, and searching the Scriptures daily, whether the things preached to them are so.

## Verses 16–21

Athens was then famed for polite learning, philosophy, and the fine arts; but none are more childish and superstitious, more impious, or more credulous, than some persons, deemed eminent for learning and ability. It was wholly given to idolatry. The zealous advocate for the cause of Christ will be ready to plead for it in all companies, as occasion offers. Most of these learned men took no notice of Paul; but some, whose principles were the most directly contrary to Christianity, made remarks upon him. The apostle ever dwelt upon two points, which are indeed the principal doctrines of Christianity, Christ and a future state; Christ our way, and heaven our end. They looked on this as very different from the knowledge for many ages taught and professed at Athens; they desire to know more of it, but only because it was new and strange. They led him to the place where judges sat who inquired into such matters. They asked about Paul's doctrine, not because it was good, but because it was new. Great talkers are always busy-bodies. They spend their time in nothing else, and a very uncomfortable account they have to give of their time who thus spend it. Time is precious, and we are concerned to employ it well, because eternity depends upon it, but much is wasted in unprofitable conversation.

## Verses 22–31

Here we have a sermon to heathens, who worshipped false gods, and were without the true God in the world; and to them the scope of the discourse was different from what the apostle preached to the Jews. In the latter case, his business was to lead his hearers by prophecies and miracles to the knowledge of the Redeemer, and faith in him; in the former, it was to lead them, by the common works of providence, to know the Creator, and worship Him. The apostle spoke of an altar he had seen, with the inscription, “TO THE UNKNOWN GOD.” This fact is stated by many writers. After multiplying their idols to the utmost, some at Athens thought there was another god of whom they had no knowledge. And are there not many now called Christians, who are zealous in their devotions, yet the great object of their worship is to them an unknown God? Observe what glorious things Paul here says of that God whom he served, and would have them to serve. The Lord had long borne with idolatry, but the times of this ignorance were now ending, and by his servants he now commanded all men every where to repent of their idolatry. Each sect of the learned men would feel themselves powerfully affected by the apostle's discourse, which tended to show the emptiness or falsity of their doctrines.

## Verses 32–34

The apostle was treated with more outward civility at Athens than in some other places; but none more despised his doctrine, or treated it with more indifference. Of all subjects, that which deserves the most attention gains the least. But those who scorn, will have to bear the consequences, and the word will never be useless. Some will be found, who cleave to the Lord, and listen to his faithful servants. Considering the judgement to come, and Christ as our Judge, should urge all to repent of sin, and turn to Him. Whatever matter is used, all discourses must lead to Him, and show his authority; our salvation, and resurrection, come from and by Him.

