---
title: "Ecclesiastes 7 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "7"
description: "In this chapter: The benefit of a good name; of death above life; of sorrow above vain mirth. (1-6). Concerning oppression, anger, and discontent. (7-10). Advantages of wisdom. (11-22). Experience of the evil of sin. (23-29)."
weight: 7
---

# Ecclesiastes 7 

## Chapter Outline

- The benefit of a good name; of death above life; of sorrow above vain mirth. (1-6)
- Concerning oppression, anger, and discontent. (7-10)
- Advantages of wisdom. (11-22)
- Experience of the evil of sin. (23-29)

## Verses 1-6

Reputation for piety and honesty is more desirable than all the wealth and pleasure in this world. It will do more good to go to a funeral than to a feast. We may lawfully go to both, as there is occasion; our Saviour both feasted at the wedding of his friend in Cana, and wept at the grave of his friend in Bethany. But, considering how apt we are to be vain and indulge the flesh, it is best to go to the house of mourning, to learn the end of man as to this world. Seriousness is better than mirth and jollity. That is best for us which is best for our souls, though it be unpleasing to sense. It is better to have our corruptions mortified by the rebuke of the wise, than to have them gratified by the song of fools. The laughter of a fool is soon gone, the end of his mirth is heaviness.

## Verses 7-10

The event of our trials and difficulties is often better than at first we thought. Surely it is better to be patient in spirit, than to be proud and hasty. Be not soon angry, nor quick in resenting an affront. Be not long angry; though anger may come into the bosom of a wise man, it passes through it as a way-faring man; it dwells only in the bosom of fools. It is folly to cry out upon the badness of our times, when we have more reason to cry out for the badness of our own hearts; and even in these times we enjoy many mercies. It is folly to cry up the goodness of former times; as if former ages had not the like things to complain of that we have: this arises from discontent, and aptness to quarrel with God himself.

## Verses 11-22

Wisdom is as good as an inheritance, yea better. It shelters from the storms and scorching heat of trouble. Wealth will not lengthen out the natural life; but true wisdom will give spiritual life, and strengthen men for services under their sufferings. Let us look upon the disposal of our condition as the work of God, and at last all will appear to have been for the best. In acts of righteousness, be not carried into heats or passions, no, not by a zeal for God. Be not conceited of thine own abilities; nor find fault with every thing, nor busy thyself in other men's matters. Many who will not be wrought upon by the fear of God, and the dread of hell, will avoid sins which ruin their health and estate, and expose to public justice. But those that truly fear God, have but one end to serve, therefore act steadily. If we say we have not sinned, we deceive ourselves. Every true believer is ready to say, God be merciful to me a sinner. Forget not at the same time, that personal righteousness, walking in newness of life, is the only real evidence of an interest by faith in the righteousness of the Redeemer. Wisdom teaches us not to be quick in resenting affronts. Be not desirous to know what people say; if they speak well of thee, it will feed thy pride, if ill, it will stir up thy passion. See that thou approve thyself to God and thine own conscience, and then heed not what men say of thee; it is easier to pass by twenty affronts than to avenge one. When any harm is done to us, examine whether we have not done as bad to others.

## Verses 23-29

Solomon, in his search into the nature and reason of things, had been miserably deluded. But he here speaks with godly sorrow. He alone who constantly aims to please God, can expect to escape; the careless sinner probably will fall to rise no more. He now discovered more than ever the evil of the great sin of which he had been guilty, the loving many strange women, I Kin. 11:1. A woman thoroughly upright and godly, he had not found. How was he likely to find such a one among those he had collected? If any of them had been well disposed, their situation would tend to render them all nearly of the same character. He here warns others against the sins into which he had been betrayed. Many a godly man can with thankfulness acknowledge that he has found a prudent, virtuous woman in the wife of his bosom; but those men who have gone in Solomon's track, cannot expect to find one. He traces up all the streams of actual transgression to the fountain. It is clear that man is corrupted and revolted, and not as he was made. It is lamentable that man, whom God made upright, has found out so many ways to render himself wicked and miserable. Let us bless Him for Jesus Christ, and seek his grace, that we may be numbered with his chosen people.


