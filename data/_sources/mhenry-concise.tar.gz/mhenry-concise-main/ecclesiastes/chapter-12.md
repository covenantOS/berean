---
title: "Ecclesiastes 12 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "12"
description: "In this chapter: A description of the infirmities of age. (1-7). All is vanity: also a warning of the judgment to come. (8-14)."
weight: 12
---

# Ecclesiastes 12 

## Chapter Outline

- A description of the infirmities of age. (1-7)
- All is vanity: also a warning of the judgment to come. (8-14)

## Verses 1-7

We should remember our sins against our Creator, repent, and seek forgiveness. We should remember our duties, and set about them, looking to him for grace and strength. This should be done early, while the body is strong, and the spirits active. When a man has the pain of reviewing a misspent life, his not having given up sin and worldly vanities till he is forced to say, I have no pleasure in them, renders his sincerity very questionable. Then follows a figurative description of old age and its infirmities, which has some difficulties; but the meaning is plain, to show how uncomfortable, generally, the days of old age are. As the four verses, 2-5, are a figurative description of the infirmities that usually accompany old age, 6 notices the circumstances which take place in the hour of death. If sin had not entered into the world, these infirmities would not have been known. Surely then the aged should reflect on the evil of sin.

## Verses 8-14

Solomon repeats his text, VANITY OF VANITIES, ALL IS VANITY. These are the words of one that could speak by dear-bought experience of the vanity of the world, which can do nothing to ease men of the burden of sin. As he considered the worth of souls, he gave good heed to what he spake and wrote; words of truth will always be acceptable words. The truths of God are as goads to such as are dull and draw back, and nails to such as are wandering and draw aside; means to establish the heart, that we may never sit loose to our duty, nor be taken from it. The Shepherd of Israel is the Giver of inspired wisdom. Teachers and guides all receive their communications from him. The title is applied in Scripture to the Lord Jesus Christ, the Son of God. The prophets sought diligently, what, or what manner of time, the Spirit of Christ in them did signify, when it testified beforehand the sufferings of Christ, and the glory that should follow. To write many books was not suited to the shortness of human life, and would be weariness to the writer, and to the reader; and then was much more so to both than it is now. All things would be vanity and vexation, except they led to this conclusion, That to fear God, and keep his commandments, is the whole of man. The fear of God includes in it all the affections of the soul towards him, which are produced by the Holy Spirit. There may be terror where there is no love, nay, where there is hatred. But this is different from the gracious fear of God, as the feelings of an affectionate child. The fear of God, is often put for the whole of true religion in the heart, and includes its practical results in the life. Let us attend to the one thing needful, and now come to him as a merciful Saviour, who will soon come as an almighty Judge, when he will bring to light the things of darkness, and manifest the counsels of all hearts. Why does God record in his word, that ALL IS VANITY, but to keep us from deceiving ourselves to our ruin? He makes our duty to be our interest. May it be graven in all our hearts. Fear God, and keep his commandments, for this is all that concerns man.


