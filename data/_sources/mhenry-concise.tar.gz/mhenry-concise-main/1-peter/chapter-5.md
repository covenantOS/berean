---
title: "1 Peter 5 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "5"
description: "In this chapter: Elders exhorted and encouraged. (1–4). Younger Christians are to submit to their elders, and to yield with humility and patience to God, and to be sober, watchful, and stedfast in faith. (5–9). Prayers for their growth and establishment. (10–14)."
weight: 5
---

# 1 Peter 5 

## Chapter Outline

- Elders exhorted and encouraged. (1–4)
- Younger Christians are to submit to their elders, and to yield with humility and patience to God, and to be sober, watchful, and stedfast in faith. (5–9)
- Prayers for their growth and establishment. (10–14)

## Verses 1–4

The apostle Peter does not command, but exhorts. He does not claim power to rule over all pastors and churches. It was the peculiar honour of Peter and a few more, to be witnesses of Christ's sufferings; but it is the privilege of all true Christians to partake of the glory that shall be revealed. These poor, dispersed, suffering Christians, were the flock of God, redeemed to God by the great Shepherd, living in holy love and communion, according to the will of God. They are also dignified with the title of God's heritage or clergy; his peculiar lot, chosen for his own people, to enjoy his special favour, and to do him special service. Christ is the chief Shepherd of the whole flock and heritage of God. And all faithful ministers will receive a crown of unfading glory, infinitely better and more honourable than all the authority, wealth, and pleasure of the world.

## Verses 5–9

Humility preserves peace and order in all Christian churches and societies; pride disturbs them. Where God gives grace to be humble, he will give wisdom, faith, and holiness. To be humble, and subject to our reconciled God, will bring greater comfort to the soul than the gratification of pride and ambition. But it is to be in due time; not in thy fancied time, but God's own wisely appointed time. Does he wait, and wilt not thou? What difficulties will not the firm belief of his wisdom, power, and goodness get over! Then be humble under his hand. Cast “all you care;” personal cares, family cares, cares for the present, and cares for the future, for yourselves, for others, for the church, on God. These are burdensome, and often very sinful, when they arise from unbelief and distrust, when they torture and distract the mind, unfit us for duties, and hinder our delight in the service of God. The remedy is, to cast our care upon God, and leave every event to his wise and gracious disposal. Firm belief that the Divine will and counsels are right, calms the spirit of a man. Truly the godly too often forget this, and fret themselves to no purpose. Refer all to God's disposal. The golden mines of all spiritual comfort and good are wholly his, and the Spirit itself. Then, will he not furnish what is fit for us, if we humbly attend on him, and lay the care of providing for us, upon his wisdom and love? The whole design of Satan is to devour and destroy souls. He always is contriving whom he may insnare to eternal ruin. Our duty plainly is, to be sober; to govern both the outward and the inward man by the rules of temperance. To be vigilant; suspicious of constant danger from this spiritual enemy, watchful and diligent to prevent his designs. Be stedfast, or solid, by faith. A man cannot fight upon a quagmire, there is no standing without firm ground to tread upon; this faith alone furnishes. It lifts the soul to the firm advanced ground of the promises, and fixes it there. The consideration of what others suffer, is proper to encourage us to bear our share in any affliction; and in whatever form Satan assaults us, or by whatever means, we may know that our brethren experience the same.

## Verses 10–14

In conclusion, the apostle prays to God for them, as the God of all grace. Perfect implies their progress towards perfection. Stablish imports the curing of our natural lightness and inconstancy. Strengthen has respect to the growth of graces, especially where weakest and lowest. Settle signifies to fix upon a sure foundation, and may refer to Him who is the Foundation and Strength of believers. These expressions show that perseverance and progress in grace are first to be sought after by every Christian. The power of these doctrines on the hearts, and the fruits in the lives, showed who are partakers of the grace of God. The cherishing and increase of Christian love, and of affection one to another, is no matter of empty compliment, but the stamp and badge of Jesus Christ on his followers. Others may have a false peace for a time, and wicked men may wish for it to themselves and to one another; but theirs is a vain hope, and will come to nought. All solid peace is founded on Christ, and flows from him.

