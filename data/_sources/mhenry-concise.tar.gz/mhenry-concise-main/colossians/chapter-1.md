---
title: "Colossians 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: The apostle Paul salutes the Colossians, and blesses God for their faith, love, and hope. (1–8). Prays for their fruitfulness in spiritual knowledge. (9–14). Gives a glorious view of Christ. (15–23). And sets out his own character, as the apostle of the Gentiles. (24–29)."
weight: 1
---

# Colossians 1 

## Chapter Outline

- The apostle Paul salutes the Colossians, and blesses God for their faith, love, and hope. (1–8)
- Prays for their fruitfulness in spiritual knowledge. (9–14)
- Gives a glorious view of Christ. (15–23)
- And sets out his own character, as the apostle of the Gentiles. (24–29)

## Verses 1–8

All true Christians are brethren one to another. Faithfulness runs through every character and relation of the Christian life. Faith, hope, and love, are the three principal graces in the Christian life, and proper matter for prayer and thanksgiving. The more we fix our hopes on the reward in the other world, the more free shall we be in doing good with our earthly treasure. It was treasured up for them, no enemy could deprive them of it. The gospel is the word of truth, and we may safely venture our souls upon it. And all who hear the word of the gospel, ought to bring forth the fruit of the gospel, obey it, and have their principles and lives formed according to it. Worldly love arises, either from views of interest or from likeness in manners; carnal love, from the appetite for pleasure. To these, something corrupt, selfish, and base always cleaves. But Christian love arises from the Holy Spirit, and is full of holiness. (Col 1:9-14)

## Verses 9–14

The apostle was constant in prayer, that the believers might be filled with the knowledge of God's will, in all wisdom. Good words will not do without good works. He who undertakes to give strength to his people, is a God of power, and of glorious power. The blessed Spirit is the author of this. In praying for spiritual strength, we are not straitened, or confined in the promises, and should not be so in our hopes and desires. The grace of God in the hearts of believers is the power of God; and there is glory in this power. The special use of this strength was for sufferings. There is work to be done, even when we are suffering. Amidst all their trials they gave thanks to the Father of our Lord Jesus, whose special grace fitted them to partake of the inheritance provided for the saints. To bring about this change, those were made willing subjects of Christ, who were slaves of Satan. All who are designed for heaven hereafter, are prepared for heaven now. Those who have the inheritance of sons, have the education of sons, and the disposition of sons. By faith in Christ they enjoyed this redemption, as the purchase of his atoning blood, whereby forgiveness of sins, and all other spiritual blessings were bestowed. Surely then we shall deem it a favour to be delivered from Satan's kingdom and brought into that of Christ, knowing that all trials will soon end, and that every believer will be found among those who come out of great tribulation.

## Verses 15–23

Christ in his human nature, is the visible discovery of the invisible God, and he that hath seen Him hath seen the Father. Let us adore these mysteries in humble faith, and behold the glory of the Lord in Christ Jesus. He was born or begotten before all the creation, before any creature was made; which is the Scripture way of representing eternity, and by which the eternity of God is represented to us. All things being created by Him, were created for him; being made by his power, they were made according to his pleasure, and for his praise and glory. He not only created them all at first, but it is by the word of his power that they are upheld. Christ as Mediator is the Head of the body, the church; all grace and strength are from him; and the church is his body. All fulness dwells in him; a fulness of merit and righteousness, of strength and grace for us. God showed his justice in requiring full satisfaction. This mode of redeeming mankind by the death of Christ was most suitable. Here is presented to our view the method of being reconciled. And that, notwithstanding the hatred of sin on God's part, it pleased God to reconcile fallen man to himself. If convinced that we were enemies in our minds by wicked works, and that we are now reconciled to God by the sacrifice and death of Christ in our nature, we shall not attempt to explain away, nor yet think fully to comprehend these mysteries; but we shall see the glory of this plan of redemption, and rejoice in the hope set before us. If this be so, that God's love is so great to us, what shall we do now for God? Be frequent in prayer, and abound in holy duties; and live no more to yourselves, but to Christ. Christ died for us. But wherefore? That we should still live in sin? No; but that we should die to sin, and live henceforth not to ourselves, but to Him.

## Verses 24–29

Both the sufferings of the Head and of the members are called the sufferings of Christ, and make up, as it were, one body of sufferings. But He suffered for the redemption of the church; we suffer on other accounts; for we do but slightly taste that cup of afflictions of which Christ first drank deeply. A Christian may be said to fill up that which remains of the sufferings of Christ, when he takes up his cross, and after the pattern of Christ, bears patiently the afflictions God allots to him. Let us be thankful that God has made known to us mysteries hidden from ages and generations, and has showed the riches of his glory among us. As Christ is preached among us, let us seriously inquire, whether he dwells and reigns in us; for this alone can warrant our assured hope of his glory. We must be faithful to death, through all trials, that we may receive the crown of life, and obtain the end of our faith, the salvation of our souls.

