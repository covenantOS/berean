---
title: "Colossians 3 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "3"
description: "In this chapter: The Colossians exhorted to be heavenly-minded; (1–4). to mortify all corrupt affections; (5–11). to live in mutual love, forbearance, and forgiveness; (12–17). and to practise the duties of wives and husbands, children, parents, and servants. (18–25)."
weight: 3
---

# Colossians 3 

## Chapter Outline

- The Colossians exhorted to be heavenly-minded; (1–4)
- to mortify all corrupt affections; (5–11)
- to live in mutual love, forbearance, and forgiveness; (12–17)
- and to practise the duties of wives and husbands, children, parents, and servants. (18–25)

## Verses 1–4

As Christians are freed from the ceremonial law, they must walk the more closely with God in gospel obedience. As heaven and earth are contrary one to the other, both cannot be followed together; and affection to the one will weaken and abate affection to the other. Those that are born again are dead to sin, because its dominion is broken, its power gradually subdued by the operation of grace, and it shall at length be extinguished by the perfection of glory. To be dead, then, means this, that those who have the Holy Spirit, mortifying within them the lusts of the flesh, are able to despise earthly things, and to desire those that are heavenly. Christ is, at present, one whom we have not seen; but our comfort is, that our life is safe with him. The streams of this living water flow into the soul by the influences of the Holy Spirit, through faith. Christ lives in the believer by his Spirit, and the believer lives to him in all he does. At the second coming of Christ, there will be a general assembling of all the redeemed; and those whose life is now hid with Christ, shall then appear with him in his glory. Do we look for such happiness, and should we not set our affections upon that world, and live above this?

## Verses 5–11

It is our duty to mortify our members which incline to the things of the world. Mortify them, kill them, suppress them, as weeds or vermin which spread and destroy all about them. Continual opposition must be made to all corrupt workings, and no provision made for carnal indulgences. Occasions of sin must be avoided: the lusts of the flesh, and the love of the world; and covetousness, which is idolatry; love of present good, and of outward enjoyments. It is necessary to mortify sins, because if we do not kill them, they will kill us. The gospel changes the higher as well as the lower powers of the soul, and supports the rule of right reason and conscience, over appetite and passion. There is now no difference from country, or conditions and circumstances of life. It is the duty of every one to be holy, because Christ is a Christian's All, his only Lord and Saviour, and all his hope and happiness.

## Verses 12–17

We must not only do no hurt to any, but do what good we can to all. Those who are the elect of God, holy and beloved, ought to be lowly and compassionate towards all. While in this world, where there is so much corruption in our hearts, quarrels will sometimes arise. But it is our duty to forgive one another, imitating the forgiveness through which we are saved. Let the peace of God rule in your hearts; it is of his working in all who are his. Thanksgiving to God, helps to make us agreeable to all men. The gospel is the word of Christ. Many have the word, but it dwells in them poorly; it has no power over them. The soul prospers, when we are full of the Scriptures and of the grace of Christ. But when we sing psalms, we must be affected with what we sing. Whatever we are employed about, let us do every thing in the name of the Lord Jesus, and in believing dependence on him. Those who do all in Christ's name, will never want matter of thanksgiving to God, even the Father.

## Verses 18–25

The epistles most taken up in displaying the glory of the Divine grace, and magnifying the Lord Jesus, are the most particular in pressing the duties of the Christian life. We must never separate the privileges and duties of the gospel. Submission is the duty of wives. But it is submission, not to a severe lord or stern tyrant, but to her own husband, who is engaged to affectionate duty. And husbands must love their wives with tender and faithful affection. Dutiful children are the most likely to prosper. And parents must be tender, as well as children obedient. Servants are to do their duty, and obey their masters' commands, in all things consistent with duty to God their heavenly Master. They must be both just and diligent; without selfish designs, or hypocrisy and disguise. Those who fear God, will be just and faithful when from under their master's eye, because they know they are under the eye of God. And do all with diligence, not idly and slothfully; cheerfully, not discontented at the providence of God which put them in that relation. And for servants' encouragement, let them know, that in serving their masters according to the command of Christ, they serve Christ, and he will give them a glorious reward at last. But, on the other hand, he who doeth wrong, shall receive for the wrong which he hath done. God will punish the unjust, as well as reward the faithful servant; and the same if masters wrong their servants. For the righteous Judge of the earth will deal justly between master and servant. Both will stand upon a level at his tribunal. How happy would true religion make the world, if it every where prevailed, influenced every state of things, and every relation of life! But the profession of those persons who are regardless of duties, and give just cause for complaint to those they are connected with, deceives themselves, as well as brings reproach on the gospel.

