---
title: "1 Timothy 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: Prayer to be made for all persons, since the grace of the gospel makes no difference of ranks or stations. (1–7). How men and women ought to behave, both in their religious and common life. (8–15)."
weight: 2
---

# 1 Timothy 2 

## Chapter Outline

- Prayer to be made for all persons, since the grace of the gospel makes no difference of ranks or stations. (1–7)
- How men and women ought to behave, both in their religious and common life. (8–15)

## Verses 1–7

The disciples of Christ must be praying people; all, without distinction of nation, sect, rank, or party. Our duty as Christians, is summed up in two words; godliness, that is, the right worshipping of God; and honesty, that is, good conduct toward all men. These must go together: we are not truly honest, if we are not godly, and do not render to God his due; and we are not truly godly, if not honest. What is acceptable in the sight of God our Saviour, we should abound in. There is one Mediator, and that Mediator gave himself a ransom for all. And this appointment has been made for the benefit of the Jews and the Gentiles of every nation; that all who are willing may come in this way, to the mercy-seat of a pardoning God, to seek reconciliation with him. Sin had made a quarrel between us and God; Jesus Christ is the Mediator who makes peace. He is a ransom that was to be known in due time. In the Old Testament times, his sufferings, and the glory that should follow, were spoken of as things to be revealed in the last times. Those who are saved must come to the knowledge of the truth, for that is God's appointed way to save sinners: if we do not know the truth, we cannot be ruled by it.

## Verses 8–15

Under the gospel, prayer is not to be confined to any one particular house of prayer, but men must pray every where. We must pray in our closets, pray in our families, pray at our meals, pray when we are on journeys, and pray in the solemn assemblies, whether more public or private. We must pray in charity; without wrath, or malice, or anger at any person. We must pray in faith, without doubting, and without disputing. Women who profess the Christian religion, must be modest in apparel, not affecting gaudiness, gaiety, or costliness. Good works are the best ornament; these are, in the sight of God, of great price. Modesty and neatness are more to be consulted in garments than elegance and fashion. And it would be well if the professors of serious godliness were wholly free from vanity in dress. They should spend more time and money in relieving the sick and distressed, than in decorating themselves and their children. To do this in a manner unsuitable to their rank in life, and their profession of godliness, is sinful. These are not trifles, but Divine commands. The best ornaments for professors of godliness, are good works. According to St. Paul, women are not allowed to be public teachers in the church; for teaching is an office of authority. But good women may and ought to teach their children at home the principles of true religion. Also, women must not think themselves excused from learning what is necessary to salvation, though they must not usurp authority. As woman was last in the creation, which is one reason for her subjection, so she was first in the transgression. But there is a word of comfort; that those who continue in sobriety, shall be saved in child-bearing, or with child-bearing, by the Messiah, who was born of a woman. And the especial sorrow to which the female sex is subject, should cause men to exercise their authority with much gentleness, tenderness, and affection.

