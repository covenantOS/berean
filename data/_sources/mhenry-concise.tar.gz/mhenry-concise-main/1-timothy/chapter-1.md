---
title: "1 Timothy 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: The apostle salutes Timothy. (1–4). The design of the law as given by Moses. (5–11). Of his own conversion and call to the apostleship. (12–17). The obligation to maintain faith and a good conscience. (18–20)."
weight: 1
---

# 1 Timothy 1 

## Chapter Outline

- The apostle salutes Timothy. (1–4)
- The design of the law as given by Moses. (5–11)
- Of his own conversion and call to the apostleship. (12–17)
- The obligation to maintain faith and a good conscience. (18–20)

## Verses 1–4

Jesus Christ is a Christian's hope; all our hopes of eternal life are built upon him; and Christ is in us the hope of glory. The apostle seems to have been the means of Timothy's conversion; who served with him in his ministry, as a dutiful son with a loving father. That which raises questions, is not for edifying; that which gives occasion for doubtful disputes, pulls down the church rather than builds it up. Godliness of heart and life can only be kept up and increased, by the exercise of faith in the truths and promises of God, through Jesus Christ.

## Verses 5–11

Whatever tends to weaken love to God, or love to the brethren, tends to defeat the end of the commandment. The design of the gospel is answered, when sinners, through repentance towards God and faith in Jesus Christ, are brought to exercise Christian love. And as believers were righteous persons in God's appointed way, the law was not against them. But unless we are made righteous by faith in Christ, really repenting and forsaking sin, we are yet under the curse of the law, even according to the gospel of the blessed God, and are unfit to share the holy happiness of heaven.

## Verses 12–17

The apostle knew that he would justly have perished, if the Lord had been extreme to mark what was amiss; and also if his grace and mercy had not been abundant to him when dead in sin, working faith and love to Christ in his heart. This is a faithful saying; these are true and faithful words, which may be depended on, That the Son of God came into the world, willingly and purposely to save sinners. No man, with Paul's example before him, can question the love and power of Christ to save him, if he really desires to trust in him as the Son of God, who once died on the cross, and now reigns upon the throne of glory, to save all that come to God through him. Let us then admire and praise the grace of God our Saviour; and ascribe to the Father, Son, and Holy Ghost, three Persons in the unity of the Godhead, the glory of all done in, by, and for us.

## Verses 18–20

The ministry is a warfare against sin and Satan; carried on under the Lord Jesus, who is the Captain of our salvation. The good hopes others have had of us, should stir us up to duty. And let us be upright in our conduct in all things. The design of the highest censures in the primitive church, was, to prevent further sin, and to reclaim the sinner. May all who are tempted to put away a good conscience, and to abuse the gospel, remember that this is the way to make shipwreck of faith also.

