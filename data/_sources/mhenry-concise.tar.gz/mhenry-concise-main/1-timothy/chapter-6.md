---
title: "1 Timothy 6 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "6"
description: "In this chapter: The duty of Christians towards believing, as well as other masters. (1–5). The advantage of godliness with contentment. (6–10). A solemn charge to Timothy to be faithful. (11–16). The apostle repeats his warning to the rich, and closes with a blessing. (17–21)."
weight: 6
---

# 1 Timothy 6 

## Chapter Outline

- The duty of Christians towards believing, as well as other masters. (1–5)
- The advantage of godliness with contentment. (6–10)
- A solemn charge to Timothy to be faithful. (11–16)
- The apostle repeats his warning to the rich, and closes with a blessing. (17–21)

## Verses 1–5

Christians were not to suppose that religious knowledge, or Christian privileges, gave them any right to despise heathen masters, or to disobey lawful commands, or to expose their faults to others. And such as enjoyed the privilege of living with believing masters, were not to withhold due respect and reverence, because they were equal in respect to religious privileges, but were to serve with double diligence and cheerfulness, because of their faith in Christ, and as partakers of his free salvation. We are not to consent to any words as wholesome, except the words of our Lord Jesus Christ; to these we must give unfeigned consent. Commonly those are most proud who know least; for they do not know themselves. Hence come envy, strife, railings, evil-surmisings, disputes that are all subtlety, and of no solidity, between men of corrupt and carnal minds, ignorant of the truth and its sanctifying power, and seeking their worldly advantage. (1Ti 6:6-10)

## Verses 6–10

Those that make a trade of Christianity to serve their turn for this world, will be disappointed; but those who mind it as their calling, will find it has the promise of the life that now is, as well as of that which is to come. He that is godly, is sure to be happy in another world; and if contented with his condition in this world, he has enough; and all truly godly people are content. When brought into the greatest straits, we cannot be poorer than when we came into this world; a shroud, a coffin, and a grave, are all that the richest man in the world can have from all his wealth. If nature should be content with a little, grace should be content with less. The necessaries of life bound a true Christian's desires, and with these he will endeavour to be content. We see here the evil of covetousness. It is not said, they that are rich, but they will be rich; who place their happiness in wealth, and are eager and determined in the pursuit. Those that are such, give to Satan the opportunity of tempting them, leading them to use dishonest means, and other bad practices, to add to their gains. Also, leading into so many employments, and such a hurry of business, as leave no time or inclination for spiritual religion; leading to connexions that draw into sin and folly. What sins will not men be drawn into by the love of money! People may have money, and yet not love it; but if they love it, this will push them on to all evil. Every sort of wickedness and vice, in one way or another, grows from the love of money. We cannot look around without perceiving many proofs of this, especially in a day of outward prosperity, great expenses, and loose profession.

## Verses 11–16

It ill becomes any men, but especially men of God, to set their hearts upon the things of this world; men of God should be taken up with the things of God. There must be a conflict with corruption, and temptations, and the powers of darkness. Eternal life is the crown proposed for our encouragement. We are called to lay hold thereon. To the rich must especially be pointed out their dangers and duties, as to the proper use of wealth. But who can give such a charge, that is not himself above the love of things that wealth can buy? The appearing of Christ is certain, but it is not for us to know the time. Mortal eyes cannot bear the brightness of the Divine glory. None can approach him except as he is made known unto sinners in and by Christ. The Godhead is here adored without distinction of Persons, as all these things are properly spoken, whether of the Father, the Son, or the Holy Ghost. God is revealed to us, only in and through the human nature of Christ, as the only begotten Son of the Father.

## Verses 17–21

Being rich in this world is wholly different from being rich towards God. Nothing is more uncertain than worldly wealth. Those who are rich, must see that God gives them their riches; and he only can give to enjoy them richly; for many have riches, but enjoy them poorly, not having a heart to use them. What is the best estate worth, more than as it gives opportunity of doing the more good? Showing faith in Christ by fruits of love, let us lay hold on eternal life, when the self-indulgent, covetous, and ungodly around, lift up their eyes in torment. That learning which opposes the truth of the gospel, is not true science, or real knowledge, or it would approve the gospel, and consent to it. Those who advance reason above faith, are in danger of leaving faith. Grace includes all that is good, and grace is an earnest, a beginning of glory; wherever God gives grace, he will give glory.

