---
title: "Ephesians | Matthew Henry Concise Commentary"
linkTitle: "Ephesians"
weight: 49
description: >
  Read commentary notes on Ephesians from Matthew Henry's Concise Commentary on the Bible online.
layout: single-section
---

# Ephesians

This epistle was written when St. Paul was a prisoner at Rome. The design appears to be to strengthen the Ephesians in the faith of Christ, and to give exalted views of the love of God, and of the dignity and excellence of Christ, fortifying their minds against the scandal of the cross. He shows that they were saved by grace, and that however wretched they once were, they now had equal privileges with the Jews. He encourages them to persevere in their Christian calling, and urges them to walk in a manner becoming their profession, faithfully discharging the general and common duties of religion, and the special duties of particular relations.

{{< cards >}}
{{< card link="./chapter-1" title="Chapter 1" icon="book-open" >}}
{{< card link="./chapter-2" title="Chapter 2" icon="book-open" >}}
{{< card link="./chapter-3" title="Chapter 3" icon="book-open" >}}
{{< card link="./chapter-4" title="Chapter 4" icon="book-open" >}}
{{< card link="./chapter-5" title="Chapter 5" icon="book-open" >}}
{{< card link="./chapter-6" title="Chapter 6" icon="book-open" >}}
{{< /cards >}}
