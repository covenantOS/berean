---
title: "Ephesians 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: The riches of God's grace towards men, shown from their deplorable state by nature, and the happy change Divine grace makes in them. (1–10). The Ephesians called to reflect on their state of heathenism. (11–13). And the privileges and blessings of the gospel. (14–22)."
weight: 2
---

# Ephesians 2 

## Chapter Outline

- The riches of God's grace towards men, shown from their deplorable state by nature, and the happy change Divine grace makes in them. (1–10)
- The Ephesians called to reflect on their state of heathenism. (11–13)
- And the privileges and blessings of the gospel. (14–22)

## Verses 1–10

Sin is the death of the soul. A man dead in trespasses and sins has no desire for spiritual pleasures. When we look upon a corpse, it gives an awful feeling. A never-dying spirit is now fled, and has left nothing but the ruins of a man. But if we viewed things aright, we should be far more affected by the thought of a dead soul, a lost, fallen spirit. A state of sin is a state of conformity to this world. Wicked men are slaves to Satan. Satan is the author of that proud, carnal disposition which there is in ungodly men; he rules in the hearts of men. From Scripture it is clear, that whether men have been most prone to sensual or to spiritual wickedness, all men, being naturally children of disobedience, are also by nature children of wrath. What reason have sinners, then, to seek earnestly for that grace which will make them, of children of wrath, children of God and heirs of glory! God's eternal love or good-will toward his creatures, is the fountain whence all his mercies flow to us; and that love of God is great love, and that mercy is rich mercy. And every converted sinner is a saved sinner; delivered from sin and wrath. The grace that saves is the free, undeserved goodness and favour of God; and he saves, not by the works of the law, but through faith in Christ Jesus. Grace in the soul is a new life in the soul. A regenerated sinner becomes a living soul; he lives a life of holiness, being born of God: he lives, being delivered from the guilt of sin, by pardoning and justifying grace. Sinners roll themselves in the dust; sanctified souls sit in heavenly places, are raised above this world, by Christ's grace. The goodness of God in converting and saving sinners heretofore, encourages others in after-time, to hope in his grace and mercy. Our faith, our conversion, and our eternal salvation, are not of works, lest any man should boast. These things are not brought to pass by any thing done by us, therefore all boasting is shut out. All is the free gift of God, and the effect of being quickened by his power. It was his purpose, to which he prepared us, by blessing us with the knowledge of his will, and his Holy Spirit producing such a change in us, that we should glorify God by our good conversation, and perseverance in holiness. None can from Scripture abuse this doctrine, or accuse it of any tendency to evil. All who do so, are without excuse.

## Verses 11–13

Christ and his covenant are the foundation of all the Christian's hopes. A sad and terrible description is here; but who is able to remove himself out of it? Would that this were not a true description of many baptized in the name of Christ. Who can, without trembling, reflect upon the misery of a person, separated for ever from the people of God, cut off from the body of Christ, fallen from the covenant of promise, having no hope, no Saviour, and without any God but a God of vengeance, to all eternity? To have no part in Christ! What true Christian can hear this without horror? Salvation is far from the wicked; but God is a help at hand to his people; and this is by the sufferings and death of Christ.

## Verses 14–18

Jesus Christ made peace by the sacrifice of himself; in every sense Christ was their Peace, the author, centre, and substance of their being at peace with God, and of their union with the Jewish believers in one church. Through the person, sacrifice, and mediation of Christ, sinners are allowed to draw near to God as a Father, and are brought with acceptance into his presence, with their worship and services, under the teaching of the Holy Spirit, as one with the Father and the Son. Christ purchased leave for us to come to God; and the Spirit gives a heart to come, and strength to come, and then grace to serve God acceptably.

## Verses 19–22

The church is compared to a city, and every converted sinner is free of it. It is also compared to a house, and every converted sinner is one of the family; a servant, and a child in God's house. The church is also compared to a building, founded on the doctrine of Christ; delivered by the prophets of the Old Testament, and the apostles of the New. God dwells in all believers now; they become the temple of God through the working of the blessed Spirit. Let us then ask if our hopes are fixed on Christ, according to the doctrine of his word? Have we devoted ourselves as holy temples to God through him? Are we habitations of God by the Spirit, are we spiritually-minded, and do we bring forth the fruits of the Spirit? Let us take heed not to grieve the holy Comforter. Let us desire his gracious presence, and his influences upon our hearts. Let us seek to discharge the duties allotted to us, to the glory of God.

