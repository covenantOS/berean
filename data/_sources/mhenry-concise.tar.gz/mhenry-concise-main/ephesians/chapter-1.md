---
title: "Ephesians 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: A salutation, and an account of saving blessings, as prepared in God's eternal election, as purchased by Christ's blood. (1–8). And as conveyed in effectual calling: this is applied to the believing Jews, and to the believing Gentiles. (9–14). The apostle thanks God for their faith and love, and prays for the continuance of their knowledge and hope, with respect to the heavenly inheritance, and to God's powerful working in them. (15–23)."
weight: 1
---

# Ephesians 1 

## Chapter Outline

- A salutation, and an account of saving blessings, as prepared in God's eternal election, as purchased by Christ's blood. (1–8)
- And as conveyed in effectual calling: this is applied to the believing Jews, and to the believing Gentiles. (9–14)
- The apostle thanks God for their faith and love, and prays for the continuance of their knowledge and hope, with respect to the heavenly inheritance, and to God's powerful working in them. (15–23)

## Verses 1, 2

All Christians must be saints; if they come not under that character on earth, they will never be saints in glory. Those are not saints, who are not faithful, believing in Christ, and true to the profession they make of relation to their Lord. By grace, understand the free and undeserved love and favour of God, and those graces of the Spirit which come from it; by peace, all other blessings, spiritual and temporal, the fruits of the former. No peace without grace. No peace, nor grace, but from God the Father, and from the Lord Jesus Christ; and the best saints need fresh supplies of the graces of the Spirit, and desire to grow.

## Verses 3–8

Spiritual and heavenly blessings are the best blessings; with which we cannot be miserable, and without which we cannot but be so. This was from the choice of them in Christ, before the foundation of the world, that they should be made holy by separation from sin, being set apart to God, and sanctified by the Holy Spirit, in consequence of their election in Christ. All who are chosen to happiness as the end, are chosen to holiness as the means. In love they were predestinated, or fore-ordained, to be adopted as children of God by faith in Christ Jesus, and to be openly admitted to the privileges of that high relation to himself. The reconciled and adopted believer, the pardoned sinner, gives all the praise of his salvation to his gracious Father. His love appointed this method of redemption, spared not his own Son, and brought believers to hear and embrace this salvation. It was rich grace to provide such a surety as his own Son, and freely to deliver him up. This method of grace gives no encouragement to evil, but shows sin in all its hatefulness, and how it deserves vengeance. The believer's actions, as well as his words, declare the praises of Divine mercy.

## Verses 9–14

Blessings were made known to believers, by the Lord's showing to them the mystery of his sovereign will, and the method of redemption and salvation. But these must have been for ever hidden from us, if God had not made them known by his written word, preached gospel, and Spirit of truth. Christ united the two differing parties, God and man, in his own person, and satisfied for that wrong which caused the separation. He wrought, by his Spirit, those graces of faith and love, whereby we are made one with God, and among ourselves. He dispenses all his blessings, according to his good pleasure. His Divine teaching led whom he pleased to see the glory of those truths, which others were left to blaspheme. What a gracious promise that is, which secures the gift of the Holy Ghost to those who ask him! The sanctifying and comforting influences of the Holy Spirit seal believers as the children of God, and heirs of heaven. These are the first-fruits of holy happiness. For this we were made, and for this we were redeemed; this is the great design of God in all that he has done for us; let all be ascribed unto the praise of his glory.

## Verses 15–23

God has laid up spiritual blessings for us in his Son the Lord Jesus; but requires us to draw them out and fetch them in by prayer. Even the best Christians need to be prayed for: and while we hear of the welfare of Christian friends, we should pray for them. Even true believers greatly want heavenly wisdom. Are not the best of us unwilling to come under God's yoke, though there is no other way to find rest for the soul? Do we not for a little pleasure often part with our peace? And if we dispute less, and prayed more with and for each other, we should daily see more and more what is the hope of our calling, and the riches of the Divine glory in this inheritance. It is desirable to feel the mighty power of Divine grace, beginning and carrying on the work of faith in our souls. But it is difficult to bring a soul to believe fully in Christ, and to venture its all, and the hope of eternal life, upon his righteousness. Nothing less than Almighty power will work this in us. Here is signified that it is Christ the Saviour, who supplies all the necessities of those who trust in him, and gives them all blessings in the richest abundance. And by being partakers of Christ himself, we come to be filled with the fulness of grace and glory in him. How then do those forget themselves who seek for righteousness out of him! This teaches us to come to Christ. And did we know what we are called to, and what we might find in him, surely we should come and be suitors to him. When feeling our weakness and the power of our enemies, we most perceive the greatness of that mighty power which effects the conversion of the believer, and is engaged to perfect his salvation. Surely this will constrain us by love to live to our Redeemer's glory.

