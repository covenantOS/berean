---
title: "Daniel 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: Nebuchadnezzar's dream. (1-13). It is revealed to Daniel. (14-23). He obtains admission to the king. (24-30). The dream and the interpretation. (31-45). Honours to Daniel and his friends. (46-49)."
weight: 2
---

# Daniel 2 

## Chapter Outline

- Nebuchadnezzar's dream. (1-13)
- It is revealed to Daniel. (14-23)
- He obtains admission to the king. (24-30)
- The dream and the interpretation. (31-45)
- Honours to Daniel and his friends. (46-49)

## Verses 1-13

The greatest men are most open to cares and troubles of mind, which disturb their repose in the night, while the sleep of the labouring man is sweet and sound. We know not the uneasiness of many who live in great pomp, and, as others vainly think, in pleasure also. The king said that his learned men must tell him the dream itself, or they should all be put to death as deceivers. Men are more eager to ask as to future events, than to learn the way of salvation or the path of duty; yet foreknowledge of future events increases anxiety and trouble. Those who deceived, by pretending to do what they could not do, were sentenced to death, for not being able to do what they did not pretend to.

## Verses 14-23

Daniel humbly prayed that God would discover to him the king's dream, and the meaning of it. Praying friends are valuable friends; and it well becomes the greatest and best men to desire the prayers of others. Let us show that we value our friends, and their prayers. They were particular in prayer. And whatever we pray for, we can expect nothing but as the gift of God's mercies. God gives us leave in prayer to tell our wants and burdens. Their plea with God was, the peril they were in. The mercy Daniel and his fellows prayed for, was bestowed. The fervent prayers of righteous men avail much. Daniel was thankful to God for making known that to him, which saved the lives of himself and his fellows. How much more should we be thankful to God, for making known the great salvation of the soul to those who are not among the worldly wise and prudent!

## Verses 24-30

Daniel takes away the king's opinion of his magicians and soothsayers. The insufficiency of creatures should drive us to the all-sufficiency of the Creator. There is One who can do that for us, and make known that to us, which none on earth can, particularly the work of redemption, and the secret designs of God's love to us therein. Daniel confirmed the king in his opinion, that the dream was of great consequence, relating to the affairs and changes of this lower world. Let those whom God has highly favoured and honoured, lay aside all opinion of their own wisdom and worthiness, that the Lord alone may be praised for the good they have and do.

## Verses 31-45

This image represented the kingdoms of the earth, that should successively rule the nations, and influence the affairs of the Jewish church. 1. The head of gold signified the Chaldean empire, then in being. 2. The breast and arms of silver signified the empire of the Medes and Persians. 3. The belly and thighs of brass signified the Grecian empire, founded by Alexander. 4. The legs and feet of iron signified the Roman empire. The Roman empire branched into ten kingdoms, as the toes of these feet. Some were weak as clay, others strong as iron. Endeavours have often been used to unite them, for strengthening the empire, but in vain. The stone cut out without hands, represented the kingdom of our Lord Jesus Christ, which should be set up in the kingdoms of the world, upon the ruins of Satan's kingdom in them. This was the Stone which the builders refused, because it was not cut out by their hands, but it is become the head stone of the corner. Of the increase of Christ's government and peace there shall be no end. The Lord shall reign, not only to the end of time, but when time and days shall be no more. As far as events have gone, the fulfilling this prophetic vision has been most exact and undeniable; future ages shall witness this Stone destroying the image, and filling the whole earth.

## Verses 46-49

It is our business to direct attention to the Lord, as the Author and Giver of every good gift. Many have thoughts of the Divine power and majesty, who do not think of serving God themselves. But all should strive, that God may be glorified, and the best interests of mankind furthered.


