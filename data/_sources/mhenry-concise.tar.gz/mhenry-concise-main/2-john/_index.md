---
title: "2 John | Matthew Henry Concise Commentary"
linkTitle: "2 John"
weight: 63
description: >
  Read commentary notes on 2 John from Matthew Henry's Concise Commentary on the Bible online.
layout: single-section
---

# 2 John

This epistle is like an abridgement of the first; it touches, in few words, on the same points. The Lady Electa is commended for her virtuous and religious education of her children; is exhorted to abide in the doctrine of Christ, to persevere in the truth, and carefully to avoid the delusions of false teachers. But chiefly the apostle beseeches her to practise the great commandment of Christian love and charity.

{{< cards >}}
{{< card link="./chapter-1" title="Chapter 1" icon="book-open" >}}
{{< /cards >}}
