---
title: "2 John 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: The apostle salutes the elect lady and her children. (1–3). Express his joy in their faith and love. (4–6). Cautions them against deceivers. (7–11). And concludes. (12, 13)."
weight: 1
---

# 2 John 1 

## Chapter Outline

- The apostle salutes the elect lady and her children. (1–3)
- Express his joy in their faith and love. (4–6)
- Cautions them against deceivers. (7–11)
- And concludes. (12, 13)

## Verses 1–3

Religion turns compliments into real expressions of respect and love. And old disciple is honourable; an old apostle and leader of disciples is more so. The letter is to a noble Christian matron, and her children; it is well that the gospel should get among such: some noble persons are called. Families are to be encouraged and directed in their love and duties at home. Those who love truth and piety in themselves, should love it in others; and the Christians loved this lady, not for her rank, but for her holiness. And where religion truly dwells, it will abide for ever. From the Divine Persons of the Godhead, the apostle craves grace, Divine favour, and good-will, the spring of all good things. It is grace indeed that any spiritual blessing should be given to sinful mortals. Mercy, free pardon, and forgiveness; for those already rich in grace, need continual forgiveness. Peace, quietness of spirit, and a clear conscience, in assured reconciliation with God, together with all outward prosperity that is really for good: these are desired in truth and love.

## Verses 4–6

It is good to be trained to early religion; and children may be beloved for their parents' sake. It gave great joy to the apostle to see children treading in their parents' steps, and likely in their turn to support the gospel. May God bless such families more and more, and raise up many to copy their example. How pleasing the contrast to numbers who spread irreligion, infidelity, and vice, among their children! Our walk is true, our converse right, when according to the word of God. This commandment of mutual Christian love, may be said to be a new one, in respect of its being declared by the Lord Christ; yet, as to the matter, it is old. And this is love to our own souls, that we obey the Divine commands. The foresight of the decay of this love, as well as of other apostacies, or fallings away, might engage the apostle to urge this duty, and this command, frequently and earnestly.

## Verses 7–11

The deceiver and his deceit are described: he brings some error concerning the person or office of the Lord Jesus. Such a one is a deceiver and an antichrist; he deludes souls, and undermines the glory and kingdom of the Lord Christ. Let us not think it strange, that there are deceivers and opposers of the Lord Christ's name and dignity now, for there were such, even in the apostles' times. The more deceivers and deceits abound, the more watchful the disciples must be. Sad it is, that splendid attainments in the school of Christ, should ever be lost. The way to gain the full reward is, to abide true to Christ, and constant in religion to the end. Firm cleaving to Christian truth unites us to Christ, and thereby to the Father also; for they are one. Let us equally disregard such as abide not in the doctrine of Christ, and those who transgress his commands. Any who did not profess and preach the doctrine of Christ, respecting him as the Son of God, and salvation by him from guilt and sin, were not to be noticed and countenanced. Yet in obeying this command, we must show kindness and a good spirit to those who differ from us in lesser matters, but hold firmly the all-important doctrines of Christ's person, atonement, and holy salvation.

## Verses 12, 13

The apostle refers many things to a personal meeting. Pen and ink were means of strengthening and comforting others; but to see each other is more so. The communion of saints should be maintained by all methods; and should tend to mutual joy. In communion with them we find much of our present joy, and look forward to happiness for ever.

