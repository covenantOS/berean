---
title: "1 Kings 15 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "15"
description: "In this chapter: Wicked reign of Abijam, king of Judah. (1–8). Good reign of Asa, king of Judah. (9–24). The evil reigns of Nadab and Baasha in Israel. (25–34)."
weight: 15
---

# 1 Kings 15 

## Chapter Outline

- Wicked reign of Abijam, king of Judah. (1–8)
- Good reign of Asa, king of Judah. (9–24)
- The evil reigns of Nadab and Baasha in Israel. (25–34)

## Verses 1–8

Abijam's heart was not perfect with the Lord his God; he wanted sincerity; he began well, but he fell off, and walked in all the sins of his father, following his bad example, though he had seen the bad consequences of it. David's family was continued as a lamp in Jerusalem, to maintain the true worship of God there, when the light of Divine truth was extinguished in all other places. The Lord has still taken care of his cause, while those who ought to have been serviceable thereto have lived and perished in their sins. The Son of David will still continue a light to his church, to establish it in truth and righteousness to the end of time. There are two kinds of fulfilling the law, one legal, the other by the gospel. Legal is, when men do all things required in the law, and that by themselves. None ever thus fulfilled the law but Christ, and Adam before his fall. The gospel manner of fulfilling the law is, to believe in Christ who fulfilled the law for us, and to endeavour in the whole man to obey God in all his precepts. And this is accepted of God, as to all those that are in Christ. Thus David and others are said to fulfil the law.

## Verses 9–24

Asa did what was right in the eyes of the Lord. That is right indeed which is so in God's eyes. Asa's times were times of reformation. He removed that which was evil; there reformation begins, and a great deal he found to do. When Asa found idolatry in the court, he rooted it out thence. Reformation must begin at home. Asa honours and respects his mother; he loves her well, but he loves God better. Those that have power are happy when thus they have hearts to use it well. We must not only cease to do evil, but learn to do well; not only cast away the idols of our iniquity, but dedicate ourselves and our all to God's honour and glory. Asa was cordially devoted to the service of God, his sins not arising from presumption. But his league with Benhadad arose from unbelief. Even true believers find it hard, in times of urgent danger, to trust in the Lord with all their heart. Unbelief makes way for carnal policy, and thus for one sin after another. Unbelief has often led Christians to call in the help of the Lord's enemies in their contests with their brethren; and some who once shone brightly, have thus been covered with a dark cloud towards the end of their days.

## Verses 25–34

During the single reign of Asa in Judah, the government of Israel was in six or seven different hands. Observe the ruin of the family of Jeroboam; no word of God shall fall to the ground. Divine threatenings are not designed merely to terrify. Ungodly men execute the just judgments of God upon each other. But in the midst of dreadful sins and this apparent confusion, the Lord carries on his own plan: when it is fully completed, the glorious justice, wisdom, truth, and mercy therein displayed, shall be admired and adored through all the ages of eternity.

