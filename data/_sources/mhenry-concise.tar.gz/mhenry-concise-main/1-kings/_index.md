---
title: "1 Kings | Matthew Henry Concise Commentary"
linkTitle: "1 Kings"
weight: 11
description: >
  Read commentary notes on 1 Kings from Matthew Henry's Concise Commentary on the Bible online.
layout: single-section
---

# 1 Kings

The history now before us accounts for the affairs of the kingdoms of Judah and Israel, yet with special regard to the kingdom of God among them; for it is a sacred history. It is earlier as to time, teaches much more, and is more interesting than any common histories.

{{< cards >}}
{{< card link="./chapter-1" title="Chapter 1" icon="book-open" >}}
{{< card link="./chapter-2" title="Chapter 2" icon="book-open" >}}
{{< card link="./chapter-3" title="Chapter 3" icon="book-open" >}}
{{< card link="./chapter-4" title="Chapter 4" icon="book-open" >}}
{{< card link="./chapter-5" title="Chapter 5" icon="book-open" >}}
{{< card link="./chapter-6" title="Chapter 6" icon="book-open" >}}
{{< card link="./chapter-7" title="Chapter 7" icon="book-open" >}}
{{< card link="./chapter-8" title="Chapter 8" icon="book-open" >}}
{{< card link="./chapter-9" title="Chapter 9" icon="book-open" >}}
{{< card link="./chapter-10" title="Chapter 10" icon="book-open" >}}
{{< card link="./chapter-11" title="Chapter 11" icon="book-open" >}}
{{< card link="./chapter-12" title="Chapter 12" icon="book-open" >}}
{{< card link="./chapter-13" title="Chapter 13" icon="book-open" >}}
{{< card link="./chapter-14" title="Chapter 14" icon="book-open" >}}
{{< card link="./chapter-15" title="Chapter 15" icon="book-open" >}}
{{< card link="./chapter-16" title="Chapter 16" icon="book-open" >}}
{{< card link="./chapter-17" title="Chapter 17" icon="book-open" >}}
{{< card link="./chapter-18" title="Chapter 18" icon="book-open" >}}
{{< card link="./chapter-19" title="Chapter 19" icon="book-open" >}}
{{< card link="./chapter-20" title="Chapter 20" icon="book-open" >}}
{{< card link="./chapter-21" title="Chapter 21" icon="book-open" >}}
{{< card link="./chapter-22" title="Chapter 22" icon="book-open" >}}
{{< /cards >}}
