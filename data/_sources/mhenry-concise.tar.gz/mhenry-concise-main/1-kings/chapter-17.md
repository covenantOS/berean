---
title: "1 Kings 17 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "17"
description: "In this chapter: Elijah fed by ravens. (1–7). Elijah sent to Zarephath. (8–16). Elijah raises the widow's son to life. (17–24)."
weight: 17
---

# 1 Kings 17 

## Chapter Outline

- Elijah fed by ravens. (1–7)
- Elijah sent to Zarephath. (8–16)
- Elijah raises the widow's son to life. (17–24)

## Verses 1–7

God wonderfully suits men to the work he designs them for. The times were fit for an Elijah; an Elijah was fit for them. The Spirit of the Lord knows how to fit men for the occasions. Elijah let Ahab know that God was displeased with the idolaters, and would chastise them by the want of rain, which it was not in the power of the gods they served to bestow. Elijah was commanded to hide himself. If Providence calls us to solitude and retirement, it becomes us to go: when we cannot be useful, we must be patient; and when we cannot work for God, we must sit still quietly for him. The ravens were appointed to bring him meat, and did so. Let those who have but from hand to mouth, learn to live upon Providence, and trust it for the bread of the day, in the day. God could have sent angels to minister to him; but he chose to show that he can serve his own purposes by the meanest creatures, as effectually as by the mightiest. Elijah seems to have continued thus above a year. The natural supply of water, which came by common providence, failed; but the miraculous supply of food, made sure to him by promise, failed not. If the heavens fail, the earth fails of course; such are all our creature-comforts: we lose them when we most need them, like brooks in summer. But there is a river which makes glad the city of God, that never runs dry, a well of water that springs up to eternal life. Lord, give us that living water! (1Ki 17:8-16)

## Verses 8–16

Many widows were in Israel in the days of Elias, and some, it is likely, would have bidden him welcome to their houses; yet he is sent to honour and bless with his presence a city of Sidon, a Gentile city, and so becomes the first prophet of the Gentiles. Jezebel was Elijah's greatest enemy; yet, to show her how powerless was her malice, God will find a hiding-place for him even in her own country. The person appointed to entertain Elijah is not one of the rich or great men of Sidon; but a poor widow woman, in want, and desolate, is made both able and willing to sustain him. It is God's way, and it is his glory, to make use of, and put honour upon, the weak and foolish things of the world. O woman, great was thy faith; one has not found the like, no not in Israel. She took the prophet's word, that she should not lose by it. Those who can venture upon the promise of God, will make no difficulty to expose and empty themselves in his service, by giving him his part first. Surely the increase of this widow's faith, so as to enable her thus readily to deny herself, and to depend upon the Divine promise, was as great a miracle in the kingdom of grace, as the increase of her meal and oil in the kingdom of providence. Happy are all who can thus, against hope, believe and obey in hope. One poor meal's meat this poor widow gave the prophet; in recompence of it, she and her son did eat above two years, in a time of famine. To have food from God's special favour, and in such good company as Elijah, made it more than doubly sweet. It is promised to those who trust in God, that they shall not be ashamed in evil time; in days of famine they shall be satisfied.

## Verses 17–24

Neither faith nor obedience shut out afflictions and death. The child being dead, the mother spake to the prophet, rather to give vent to her sorrow, than in hope of relief. When God removes our comforts from us, he remembers our sins against us, perhaps the sins of our youth, though long since past. When God remembers our sins against us, he designs to teach us to remember them against ourselves, and to repent of them. Elijah's prayer was doubtless directed by the Holy Spirit. The child revived. See the power of prayer, and the power of Him who hears prayer.

