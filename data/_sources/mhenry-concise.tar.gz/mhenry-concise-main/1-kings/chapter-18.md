---
title: "1 Kings 18 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "18"
description: "In this chapter: Elijah sends Ahab notice of his coming. (1–16). Elijah meets Ahab. (17–20). Elijah's trial of the false prophets. (21–40). Elijah, by prayer, obtains rain. (41–46)."
weight: 18
---

# 1 Kings 18 

## Chapter Outline

- Elijah sends Ahab notice of his coming. (1–16)
- Elijah meets Ahab. (17–20)
- Elijah's trial of the false prophets. (21–40)
- Elijah, by prayer, obtains rain. (41–46)

## Verses 1–16

The severest judgments, of themselves, will not humble or change the hearts of sinners; nothing, except the blood of Jesus Christ, can atone for the guilt of sin; nothing, except the sanctifying Spirit of God, can purge away its pollution. The priests and the Levites were gone to Judah and Jerusalem, 2Ch 11:13, 14, but instead of them God raised up prophets, who read and expounded the word. They probably were from the schools of the prophets, first set up by Samuel. They had not the spirit of prophecy as Elijah, but taught the people to keep close to the God of Israel. These Jezebel sought to destroy. The few that escaped death were forced to hide themselves. God has his remnant among all sorts, high and low; and that faith, fear, and love of his name, which are the fruits of the Holy Spirit, will be accepted through the Redeemer. See how wonderfully God raises up friends for his ministers and people, for their shelter in difficult times. Bread and water were now scarce, yet Obadiah will find enough for God's prophets, to keep them alive. Ahab's care was not to lose all the beasts; but he took no care about his soul, not to lose that. He took pains to seek grass, but none to seek the favour of God; fencing against the effect, but not inquiring how to remove the cause. But it bodes well with a people, when God calls his ministers to stand forth, and show themselves. And we may the better endure the bread of affliction, while our eyes see our teachers.

## Verses 17–20

One may guess how people stand affected to God, by observing how they stand affected to his people and ministers. It has been the lot of the best and most useful men, like Elijah, to be called and counted the troublers of the land. But those who cause God's judgments do the mischief, not he that foretells them, and warns the nation to repent.

## Verses 21–40

Many of the people wavered in their judgment, and varied in their practice. Elijah called upon them to determine whether Jehovah or Baal was the self-existent, supreme God, the Creator, Governor, and Judge of the world, and to follow him alone. It is dangerous to halt between the service of God and the service of sin, the dominion of Christ and the dominion of our lusts. If Jesus be the only Saviour, let us cleave to him alone for every thing; if the Bible be the world of God, let us reverence and receive the whole of it, and submit our understanding to the Divine teaching it contains. Elijah proposed to bring the matter to a trial. Baal had all the outward advantages, but the event encourages all God's witnesses and advocates never to fear the face of man. The God that answers by fire, let him be God: the atonement was to be made by sacrifice, before the judgment could be removed in mercy. The God therefore that has power to pardon sin, and to signify it by consuming the sin-offering, must needs be the God that can relieve from the calamity. God never required his worshippers to honour him in the manner of the worshippers of Baal; but the service of the devil, though sometimes it pleases and pampers the body, yet, in other things, really is cruel to it, as in envy and drunkenness. God requires that we mortify our lusts and corruptions; but bodily penances and severities are no pleasure to him. Who has required these things at your hands? A few words uttered in assured faith, and with fervent affection for the glory of God, and love to the souls of men, or thirstings after the Lord's image and his favour, form the effectual, fervent prayer of the righteous man, which availeth much. Elijah sought not his own glory, but that of God, for the good of the people. The people are all agreed, convinced, and satisfied; Jehovah, he is the God. Some, we hope, had their hearts turned, but most of them were convinced only, not converted. Blessed are they that have not seen what these saw, yet have believed, and have been wrought upon by it, more than they that saw it.

## Verses 41–46

Israel, being so far reformed as to acknowledge the Lord to be God, and to consent to the execution of Baal's prophets, was so far accepted, that God poured out blessing upon the land. Elijah long continued praying. Though the answer of our fervent and believing supplications does not come quickly, we must continue earnest in prayer, and not faint or give over. A little cloud at length appeared, which soon overspread the heavens, and watered the earth. Great blessings often arise from small beginnings, showers of plenty from a cloud of span long. Let us never despise the day of small things, but hope and wait for great things from it. From what small beginnings have great matters arisen! It is thus in all the gracious proceedings of God with the soul. Scarcely to be perceived are the first workings of his Spirit in the heart, which grow up at last to the wonder of men, and applause of angels. Elijah hastened Ahab home, and attended him. God will strengthen his people for every service to which his commandments and providence call them. The awful displays of Divine justice and holiness dismay the sinner, extort confessions, and dispose to outward obedience while the impression lasts; but the view of these, with mercy, love, and truth in Christ Jesus, is needful to draw the soul to self-abasement, trust, and love. The Holy Spirit employs both in the conversion of sinners; when sinners are impressed with Divine truths, they should be exhorted to set about the duties to which the Saviour calls his disciples.

