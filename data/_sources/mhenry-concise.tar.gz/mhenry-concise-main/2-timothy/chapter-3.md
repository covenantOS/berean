---
title: "2 Timothy 3 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "3"
description: "In this chapter: The apostle foretells the rise of dangerous enemies to the gospel. (1–9). Proposes his own example to Timothy. (10–13). And exhorts him to continue in the doctrine he had learned from the Holy Scriptures. (14–17)."
weight: 3
---

# 2 Timothy 3 

## Chapter Outline

- The apostle foretells the rise of dangerous enemies to the gospel. (1–9)
- Proposes his own example to Timothy. (10–13)
- And exhorts him to continue in the doctrine he had learned from the Holy Scriptures. (14–17)

## Verses 1–9

Even in gospel times there would be perilous times; on account of persecution from without, still more on account of corruptions within. Men love to gratify their own lusts, more than to please God and do their duty. When every man is eager for what he can get, and anxious to keep what he has, this makes men dangerous to one another. When men do not fear God, they will not regard man. When children are disobedient to their parents, that makes the times perilous. Men are unholy and without the fear of God, because unthankful for the mercies of God. We abuse God's gifts, if we make them the food and fuel of our lusts. Times are perilous also, when parents are without natural affection to children. And when men have no rule over their own spirits, but despise that which is good and to be honoured. God is to be loved above all; but a carnal mind, full of enmity against him, prefers any thing before him, especially carnal pleasure. A form of godliness is very different from the power; from such as are found to be hypocrites, real Christians must withdraw. Such persons have been found within the outward church, in every place, and at all times. There ever have been artful men, who, by pretences and flatteries, creep into the favour and confidence of those who are too easy of belief, ignorant, and fanciful. All must be ever learning to know the Lord; but these follow every new notion, yet never seek the truth as it is in Jesus. Like the Egyptian magicians, these were men of corrupt minds, prejudiced against the truth, and found to be quite without faith. Yet though the spirit of error may be let loose for a time, Satan can deceive the nations and the churches no further, and no longer, than God will permit.

## Verses 10–13

The more fully we know the doctrine of Christ, as taught by the apostles, the more closely we shall cleave to it. When we know the afflictions of believers only in part, they tempt us to decline the cause for which they suffer. A form of godliness, a profession of Christian faith without a godly life, often is allowed to pass, while open profession of the truth as it is in Jesus, and resolute attention to the duties of godliness, stir up the scorn and enmity of the world. As good men, by the grace of God, grow better, so bad men, through the craft of Satan, and the power of their own corruptions, grow worse. The way of sin is down-hill; such go on from bad to worse, deceiving and being deceived. Those who deceive others, deceive themselves, as they will find at last, to their cost. The history of the outward church, awfully shows that the apostle spake this as he was moved by the Holy Ghost.

## Verses 14–17

Those who would learn the things of God, and be assured of them, must know the Holy Scriptures, for they are the Divine revelation. The age of children is the age to learn; and those who would get true learning, must get it out of the Scriptures. They must not lie by us neglected, seldom or never looked into. The Bible is a sure guide to eternal life. The prophets and apostles did not speak from themselves, but delivered what they received of God, 2Pe 1:21. It is profitable for all purposes of the Christian life. It is of use to all, for all need to be taught, corrected, and reproved. There is something in the Scriptures suitable for every case. Oh that we may love our Bibles more, and keep closer to them! then shall we find benefit, and at last gain the happiness therein promised by faith in our Lord Jesus Christ, who is the main subject of both Testaments. We best oppose error by promoting a solid knowledge of the word of truth; and the greatest kindness we can do to children, is to make them early to know the Bible.

