---
title: "Amos 8 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "8"
description: "In this chapter: The near approach of the ruin of Israel. (1–3). Oppression reproved. (4–10). A famine of the word of God. (11–14)."
weight: 8
---

# Amos 8 

## Chapter Outline

- The near approach of the ruin of Israel. (1–3)
- Oppression reproved. (4–10)
- A famine of the word of God. (11–14)

## Verses 1–3

Amos saw a basket of summer fruit gathered, and ready to be eaten; which signified, that the people were ripe for destruction, that the year of God's patience was drawing towards a conclusion. Such summer fruits will not keep till winter, but must be used at once. Yet these judgments shall not draw from them any acknowledgement, either of God's righteousness or their own unrighteousness. Sinners put off repentance from day to day, because they think the Lord thus delays his judgments.

## Verses 4–10

The rich and powerful of the land were the most guilty of oppression, as well as the foremost in idolatry. They were weary of the restraints of the sabbaths and the new moons, and wished them over, because no common work might be done therein. This is the character of many who are called Christians. The sabbath day and sabbath work are a burden to carnal hearts. It will either be profaned or be accounted a dull day. But can we spend our time better than in communion with God? When employed in religious services, they were thinking of marketings. They were weary of holy duties, because their worldly business stood still the while. Those are strangers to God, and enemies to themselves, who love market days better than sabbath days, who would rather be selling corn than worshipping God. They have no regard to man: those who have lost the savour of piety, will not long keep the sense of common honesty. They cheat those they deal with. They take advantage of their neighbour's ignorance or necessity, in a traffic which nearly concerns the labouring poor. Could we witness the fraud and covetousness, which, in such numerous forms, render trading an abomination to the Lord, we should not wonder to see many dealers backward in the service of God. But he who thus despises the poor, reproaches his Maker; as it regards Him, rich and poor meet together. Riches that are got by the ruin of the poor, will bring ruin on those that get them. God will remember their sin against them. This speaks the case of such unjust, unmerciful men, to be miserable indeed, miserable for ever. There shall be terror and desolation every where. It shall come upon them when they little think of it. Thus uncertain are all our creature-comforts and enjoyments, even life itself; in the midst of life we are in death. What will be the wailing in the bitter day which follows sinful and sensual pleasures!

## Verses 11–14

Here was a token of God's highest displeasure. At any time, and most in a time of trouble, a famine of the word of God is the heaviest judgment. To many this is no affliction, yet some will feel it very much, and will travel far to hear a good sermon; they feel the loss of the mercies others foolishly sin away. But when God visits a backsliding church, their own plans and endeavours to find out a way of salvation, will stand them in no stead. And the most amiable and zealous would perish, for want of the water of life, which Christ only can bestow. Let us value our advantages, seek to profit by them, and fear sinning them away.

